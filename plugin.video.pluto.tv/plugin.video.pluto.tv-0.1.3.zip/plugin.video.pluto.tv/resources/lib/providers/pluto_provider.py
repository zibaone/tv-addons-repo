"""Pluto TV Provider."""

import urllib.parse
from datetime import datetime, timedelta, timezone
from typing import Dict, List, Union

import xbmc
from tv_common.abstract_provider import AbstractProvider
from tv_common.utils.cache import cached
from tv_common.utils.kodi import build_addon_url, log
from tv_common.utils.routing import dispatch_by_depth, to_json_streams

try:
    from tv_common.utils.request import request_json  # type: ignore[attr-defined]
except ImportError:
    # Fallback si tv_common ancien

    def request_json(url, headers=None, default=None):  # type: ignore[no-redef]  # noqa: D103
        import requests

        try:
            r = requests.get(url, headers=headers or {}, timeout=15)
            r.raise_for_status()
            return r.json()
        except Exception:
            return default


# Endpoints:
# - https://service-channels.clusters.pluto.tv/v2/guide/channels -> 138+ channels (Bearer token)
# - https://service-channels.clusters.pluto.tv/v2/guide/categories -> category mapping
# - https://service-channels.clusters.pluto.tv/v2/guide/timelines -> EPG timeline data
# - Legacy fallback: https://api.pluto.tv/v2/channels
_CHANNELS_URL = "https://api.pluto.tv/v2/channels"
_CHANNELS_FALLBACK_URL = "https://service-channels.clusters.pluto.tv/v2/channels"
_GUIDE_CHANNELS_URL = (
    "https://service-channels.clusters.pluto.tv/v2/guide/channels"
    "?channelIds=&offset=0&limit=1000&sort=number:asc"
)
_GUIDE_CATEGORIES_URL = "https://service-channels.clusters.pluto.tv/v2/guide/categories"
_GUIDE_TIMELINES_URL = "https://service-channels.clusters.pluto.tv/v2/guide/timelines"

_PLUTO_BOOT_URL = (
    "https://boot.pluto.tv/v4/start?appName=web&appVersion=1.0.0&deviceVersion=122.0.0"
    "&deviceModel=web&deviceMake=chrome&deviceType=web"
    "&clientID=12345678-1234-1234-1234-123456789abc&clientModelNumber=1.0.0"
    "&serverSideAds=false&drmCapabilities=widevine%3AL3"
)
_FALLBACK_STITCHER_PARAMS = (
    "deviceModel=web&deviceMake=chrome&deviceType=web&deviceVersion=122.0.0"
    "&deviceDNT=0&appVersion=1.0.0&clientID=12345678-1234-1234-1234-123456789abc"
)
_USER_AGENT = (
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
    "AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36"
)


def _get_boot_data() -> dict:
    """Fetch boot configuration from Pluto boot API."""
    data = request_json(_PLUTO_BOOT_URL, headers={"User-Agent": _USER_AGENT}, default=None)
    return data if isinstance(data, dict) else {}


def _get_session_token() -> str:
    """Get Pluto session JWT."""
    boot = _get_boot_data()
    return boot.get("sessionToken", "")


def _get_stitcher_params() -> str:
    """Fetch stitcher parameters from Pluto boot API."""
    boot = _get_boot_data()
    params = boot.get("stitcherParams", "")
    return params if params else _FALLBACK_STITCHER_PARAMS


def _sign_stitcher_url(raw_url: str) -> str:
    """Ensure Pluto HLS URL has valid device, session and JWT parameters."""
    if not raw_url or "pluto.tv" not in raw_url:
        return raw_url
    base_url = raw_url.split("?")[0]
    if "cfd-v4-service-channel-stitcher" in base_url and "/stitch/" in base_url and "/v2/stitch/" not in base_url:
        base_url = base_url.replace("/stitch/", "/v2/stitch/")
    token = _get_session_token()
    params = _get_stitcher_params()
    jwt_extra = (
        f"&jwt={token}&masterJWTPassthrough=true&includeExtendedEvents=true"
        if token
        else "&masterJWTPassthrough=true"
    )
    return f"{base_url}?{params}{jwt_extra}"


def _extract_logo(channel: dict) -> str:
    """Extract best logo URL from channel."""
    # Order: solidLogoPNG > colorLogoPNG > logo > thumbnail
    for key in ("solidLogoPNG", "colorLogoPNG", "logo"):
        val = channel.get(key)
        if isinstance(val, dict) and val.get("path"):
            url = val["path"]
            if url and "missing.png" not in url:
                return url
        elif isinstance(val, str) and val and "missing.png" not in val:
            return val
    # New boot format uses images list
    for img in channel.get("images") or []:
        if (
            img.get("type") in ("solidLogoPNG", "colorLogoPNG", "logo")
            and img.get("url")
            and "missing.png" not in img["url"]
        ):
            return img["url"]
    return channel.get("logo", {}).get("path", "") if isinstance(channel.get("logo"), dict) else ""


def _extract_stitcher_url(channel: dict) -> str:
    """Extract HLS stitcher URL."""
    stitched = channel.get("stitched") or {}
    # guide/channels format: stitched.paths[0].path
    for p in stitched.get("paths") or []:
        if (p.get("type") == "hls" or not p.get("type")) and p.get("path"):
            path = p["path"]
            if not path.startswith("/v2") and path.startswith("/stitch"):
                path = f"/v2{path}"
            return f"https://cfd-v4-service-channel-stitcher-use1-1.prd.pluto.tv{path}"
    # v2 format: stitched.urls[0].url
    urls = stitched.get("urls") or []
    for u in urls:
        if u.get("type") == "hls" and u.get("url"):
            url = u["url"]
            if "cfd-v4-service-channel-stitcher" in url and "/stitch/" in url and "/v2/stitch/" not in url:
                url = url.replace("/stitch/", "/v2/stitch/")
            return url
    # boot format: stitched.path (relative)
    path = stitched.get("path")
    if path:
        if not path.startswith("/v2") and path.startswith("/stitch"):
            path = f"/v2{path}"
        return f"https://cfd-v4-service-channel-stitcher-use1-1.prd.pluto.tv{path}"
    return ""


class PlutoProvider(AbstractProvider):
    """Pluto TV FAST provider (gratuit, HLS clair)."""

    name = "Pluto TV"

    def __init__(self) -> None:  # noqa: D107
        self._channels_cache: List[dict] | None = None

    # ------------------------------------------------------------------
    # Internal fetch (cached 6h comme IPTVManager)
    # ------------------------------------------------------------------
    @cached("pluto_channels", expire_sec=6 * 60 * 60)
    def _fetch_channels_raw(self) -> list:
        """Fetch raw channel list (cached 6h)."""
        token = _get_session_token()
        if token:
            cat_map = {}
            cats_data = request_json(
                _GUIDE_CATEGORIES_URL,
                headers={"User-Agent": _USER_AGENT, "Authorization": f"Bearer {token}"},
                default=None,
            )
            if isinstance(cats_data, dict) and "data" in cats_data:
                for cat in cats_data.get("data", []):
                    cname = cat.get("name")
                    for cid in cat.get("channelIDs", []):
                        if cid not in cat_map:
                            cat_map[cid] = cname

            guide_data = request_json(
                _GUIDE_CHANNELS_URL,
                headers={
                    "User-Agent": _USER_AGENT,
                    "Authorization": f"Bearer {token}",
                    "Origin": "https://pluto.tv",
                    "Referer": "https://pluto.tv/",
                },
                default=None,
            )
            if isinstance(guide_data, dict) and guide_data.get("data"):
                channels = guide_data["data"]
                for ch in channels:
                    cid = ch.get("id") or ch.get("_id")
                    ch["_id"] = cid
                    if not ch.get("category"):
                        ch["category"] = cat_map.get(cid, "Pluto TV")
                return channels

        data = request_json(_CHANNELS_URL, headers={"User-Agent": _USER_AGENT}, default=None)
        if isinstance(data, list) and data:
            return data
        log(f"primary Pluto API empty, trying fallback {_CHANNELS_FALLBACK_URL}", xbmc.LOGWARNING)
        data = request_json(_CHANNELS_FALLBACK_URL, headers={"User-Agent": _USER_AGENT}, default=[])
        if isinstance(data, list):
            return data
        return []

    def _get_channels(self) -> List[dict]:
        """Return channels (uses cache decorator)."""
        return self._fetch_channels_raw()

    @cached("pluto_epg", expire_sec=6 * 60 * 60)
    def _fetch_epg_raw(self, start: str, stop: str) -> list:
        """Fetch channels with timelines for EPG window (cached 6h)."""
        token = _get_session_token()
        if token:
            url = f"{_GUIDE_TIMELINES_URL}?start={start}&duration=240"
            data = request_json(
                url,
                headers={"User-Agent": _USER_AGENT, "Authorization": f"Bearer {token}"},
                default=None,
            )
            if isinstance(data, dict) and data.get("data"):
                raw_list = data["data"]
                for item in raw_list:
                    cid = item.get("channelId") or item.get("id") or item.get("_id")
                    item["_id"] = cid
                return raw_list

        url = f"{_CHANNELS_URL}?includeTimelines=true&start={start}&stop={stop}"
        data = request_json(url, headers={"User-Agent": _USER_AGENT}, default=None)
        if isinstance(data, list) and data:
            return data
        url2 = f"{_CHANNELS_FALLBACK_URL}?includeTimelines=true&start={start}&stop={stop}"
        data = request_json(url2, headers={"User-Agent": _USER_AGENT}, default=[])
        return data if isinstance(data, list) else []

    def _channel_map(self) -> Dict[str, dict]:
        """Map channel _id -> channel dict."""
        m = {}
        for c in self._get_channels():
            cid = c.get("_id") or c.get("id")
            if cid:
                m[cid] = c
        return m

    # ------------------------------------------------------------------
    # AbstractProvider 5 méthodes
    # ------------------------------------------------------------------
    def get_live_stream_info(self, stream_id: str) -> dict:
        """Get live stream info (HLS clair)."""
        channel = self._channel_map().get(stream_id)
        if not channel:
            # try refresh once
            for ch in self._get_channels():
                if ch.get("_id") == stream_id or ch.get("id") == stream_id:
                    channel = ch
                    break
        if not channel:
            raise ValueError(f"Channel {stream_id} not found")
        url = _extract_stitcher_url(channel)
        if not url:
            raise ValueError(f"No HLS URL for channel {stream_id}")
        signed_url = _sign_stitcher_url(url)
        return {
            "path": signed_url,
            "protocol": "hls",
            "mime_type": "application/x-mpegURL",
            "headers": {"User-Agent": _USER_AGENT} if "pluto.tv" in signed_url else {},
        }

    def get_catchup_stream_info(self, stream_id: str) -> dict:
        """Catchup = même HLS (Pluto est linéaire, pas de replay VOD)."""
        return self.get_live_stream_info(stream_id)

    def get_streams(self) -> list:
        """Return JSON-STREAMS pour IPTV Manager."""
        channels = self._get_channels()
        log(f"{len(channels)} Pluto channels found", xbmc.LOGINFO)
        playable = [c for c in channels if _extract_stitcher_url(c)]
        if len(playable) != len(channels):
            log(f"{len(channels) - len(playable)} channels sans HLS, ignorés", xbmc.LOGINFO)
        return to_json_streams(
            playable,
            {
                "id": lambda c: c.get("_id") or c.get("id", ""),
                "name": lambda c: c.get("name", "Pluto"),
                "preset": lambda c: str(c.get("number", 0)),
                "logo": lambda c: _extract_logo(c),
                "stream": lambda c: build_addon_url(f"/stream/live/{c.get('_id') or c.get('id', '')}"),
                "group": lambda c: [c.get("category") or "Pluto TV"],
            },
        )

    def get_epg(self) -> Union[str, dict]:
        """Return JSON-EPG (dict channel_id -> programmes)."""
        now = datetime.now(timezone.utc)
        start_dt = (now - timedelta(days=1)).replace(microsecond=0)
        stop_dt = (now + timedelta(days=3)).replace(microsecond=0)
        start = start_dt.strftime("%Y-%m-%dT%H:%M:%S.000Z")
        stop = stop_dt.strftime("%Y-%m-%dT%H:%M:%S.000Z")
        channels = self._fetch_epg_raw(start, stop)
        epg: Dict[str, list] = {}
        for ch in channels:
            cid = ch.get("_id") or ch.get("channelId") or ch.get("id") or ""
            if not cid:
                continue
            for tl in ch.get("timelines") or []:
                try:
                    start_iso = tl.get("start", "")
                    stop_iso = tl.get("stop", "")
                    title = tl.get("title") or tl.get("name") or ch.get("name", "")
                    ep = tl.get("episode") or {}
                    desc = ep.get("description") or ep.get("summary") or ch.get("summary") or ""
                    subtitle = ep.get("name") if ep.get("name") != title else None
                    genre = ep.get("genre")
                    image = None
                    for k in ("poster", "thumbnail", "featuredImage"):
                        v = ep.get(k)
                        if isinstance(v, dict) and v.get("path"):
                            image = v["path"]
                            break
                        elif isinstance(v, str) and v:
                            image = v
                            break
                    entry: dict = {
                        "start": start_iso,
                        "stop": stop_iso,
                        "title": title,
                        "description": desc,
                    }
                    if subtitle:
                        entry["subtitle"] = subtitle
                    if genre:
                        entry["genre"] = genre
                    if image:
                        entry["image"] = image
                    epg.setdefault(cid, []).append(entry)
                except Exception:
                    continue
        log(f"Pluto EPG: {len(epg)} channels, {sum(len(v) for v in epg.values())} programmes", xbmc.LOGINFO)
        return epg

    def get_catchup_items(self, levels: List[str]) -> list:
        """2 niveaux: catégories -> channels."""
        getters = [
            self._get_catchup_categories,
            self._get_catchup_channels_in_category,
        ]
        return dispatch_by_depth(getters, levels)

    # ------------------------------------------------------------------
    # Catchup helpers
    # ------------------------------------------------------------------
    def _get_catchup_categories(self) -> list:
        """Niveau 0: catégories (group)."""
        cats: Dict[str, int] = {}
        for ch in self._get_channels():
            cat = ch.get("category") or "Pluto TV"
            cats[cat] = cats.get(cat, 0) + 1
        items = []
        for cat in sorted(cats):
            items.append(
                {
                    "is_folder": True,
                    "label": f"{cat} ({cats[cat]})",
                    "path": build_addon_url(f"/catchup/{urllib.parse.quote(cat)}"),
                }
            )
        return items

    def _get_catchup_channels_in_category(self, category: str) -> list:
        """Niveau 1: channels d'une catégorie."""
        category = urllib.parse.unquote(category)
        items = []
        for ch in self._get_channels():
            cat = ch.get("category") or "Pluto TV"
            if cat != category:
                continue
            items.append(
                {
                    "is_folder": False,
                    "label": ch.get("name", "Sans nom"),
                    "path": build_addon_url(f"/stream/live/{ch.get('_id') or ch.get('id', '')}"),
                    "art": {"thumb": _extract_logo(ch)},
                    "info": {
                        "title": ch.get("name", ""),
                        "plot": ch.get("summary") or ch.get("onDemandDescription") or "",
                        "mediatype": "video",
                    },
                }
            )
        return items
