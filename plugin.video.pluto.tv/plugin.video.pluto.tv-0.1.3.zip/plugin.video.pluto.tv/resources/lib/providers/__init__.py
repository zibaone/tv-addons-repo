"""Pluto provider selection."""

from tv_common.abstract_provider import AbstractProvider

from .pluto_provider import PlutoProvider

_PROVIDER = PlutoProvider()


def get_provider() -> AbstractProvider:
    """Return the Pluto provider."""
    return _PROVIDER
