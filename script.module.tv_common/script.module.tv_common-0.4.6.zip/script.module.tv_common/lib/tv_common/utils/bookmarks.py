"""Kodi video bookmarks / resume points lookup utility."""

import glob
import os
import sqlite3
from typing import Dict, Tuple

import xbmc
import xbmcvfs

from tv_common.utils.kodi import log


def normalize_path(path: str) -> str:
    """Return the stable lookup key for a media path.

    Playback paths gained a ``title`` query parameter over time (and
    catalogue-side renames change its value), and film paths were once
    recorded with ``stream_type=movie`` before switching to ``vod``, so a
    bookmark recorded under an older shape would never match the current
    listing. Dropping ``title`` and aliasing ``stream_type=movie`` to
    ``stream_type=vod`` on both sides keeps old bookmarks resolvable and
    makes lookups immune to renames; the stream id keeps the key unambiguous.
    """
    if "?" not in path:
        return path
    base, _, query = path.partition("?")
    kept = []
    for kv in query.split("&"):
        if not kv or kv.startswith("title="):
            continue
        if kv == "stream_type=movie":
            kv = "stream_type=vod"
        kept.append(kv)
    return f"{base}?{'&'.join(kept)}" if kept else base


def get_kodi_bookmarks() -> Dict[str, Tuple[float, float]]:
    """Return a mapping of normalized media URL -> (time_in_seconds, total_time_in_seconds).

    Reads the latest Kodi video database (MyVideos*.db) in read-only mode.
    Keys are normalized with :func:`normalize_path`; when several bookmark
    rows normalize to the same key (same stream recorded under different
    titles), the most recently created bookmark wins.
    Returns an empty dict if the database cannot be found or read.
    """
    try:
        db_dir = xbmcvfs.translatePath("special://database")
        if not db_dir or not os.path.exists(db_dir):
            return {}

        dbs = sorted(glob.glob(os.path.join(db_dir, "MyVideos*.db")))
        if not dbs:
            return {}

        latest_db = dbs[-1]
        uri_path = f"file:{os.path.abspath(latest_db)}?mode=ro"
        with sqlite3.connect(uri_path, uri=True, timeout=1.0) as conn:
            cursor = conn.cursor()
            cursor.execute(
                "SELECT files.strFilename, bookmark.timeInSeconds, bookmark.totalTimeInSeconds "
                "FROM bookmark "
                "JOIN files ON bookmark.idFile = files.idFile "
                "WHERE bookmark.timeInSeconds > 0 "
                "ORDER BY bookmark.idBookmark"
            )
            bookmarks: Dict[str, Tuple[float, float]] = {}
            for row in cursor.fetchall():
                bookmarks[normalize_path(row[0])] = (float(row[1]), float(row[2]))
            return bookmarks
    except Exception as e:
        log(f"Bookmark lookup failed (non-fatal): {e}", xbmc.LOGDEBUG)
        return {}
