"""Kodi sources.xml manager."""

import contextlib
import os
import xml.etree.ElementTree as ET
from typing import Callable, Dict, List, Optional

try:
    import xbmcvfs
except ImportError:
    xbmcvfs = None

try:
    import xbmc
except ImportError:
    xbmc = None


def get_sources_file_path() -> str:
    """Return the absolute path to Kodi's sources.xml."""
    if xbmcvfs and hasattr(xbmcvfs, "translatePath"):
        path = xbmcvfs.translatePath("special://profile/sources.xml")
        if path:
            return path
    home = os.path.expanduser("~")
    return os.path.join(home, ".kodi", "userdata", "sources.xml")


_DEFAULT_SOURCES_XML = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<sources>
    <programs>
        <default pathversion="1"></default>
    </programs>
    <video>
        <default pathversion="1"></default>
    </video>
    <music>
        <default pathversion="1"></default>
    </music>
    <pictures>
        <default pathversion="1"></default>
    </pictures>
    <files>
        <default pathversion="1"></default>
    </files>
    <games>
        <default pathversion="1"></default>
    </games>
</sources>
"""


def ensure_sources_file(path: Optional[str] = None) -> str:
    """Ensure that sources.xml exists on disk with a valid skeleton."""
    filepath = path or get_sources_file_path()
    if not os.path.exists(filepath):
        parent_dir = os.path.dirname(filepath)
        if parent_dir and not os.path.exists(parent_dir):
            os.makedirs(parent_dir, exist_ok=True)
        with open(filepath, "w", encoding="utf-8") as f:
            f.write(_DEFAULT_SOURCES_XML)
    return filepath


def get_video_sources(path: Optional[str] = None) -> List[Dict[str, str]]:
    """Return the list of existing video sources from sources.xml."""
    filepath = ensure_sources_file(path)
    try:
        tree = ET.parse(filepath)
    except Exception:
        return []
    root = tree.getroot()
    video = root.find("video")
    if video is None:
        return []

    sources = []
    for source in video.findall("source"):
        name_elem = source.find("name")
        path_elem = source.find("path")
        if name_elem is not None and path_elem is not None:
            sources.append(
                {
                    "name": (name_elem.text or "").strip(),
                    "path": (path_elem.text or "").strip(),
                }
            )
    return sources


def add_video_source(
    name: str,
    path: str,
    xml_path: Optional[str] = None,
    allow_sharing: bool = True,
) -> bool:
    """Add a single video source if it does not already exist.

    Returns True if added, False if already present.
    """
    added = add_video_sources(
        [{"name": name, "path": path, "allowsharing": str(allow_sharing).lower()}],
        xml_path=xml_path,
    )
    return added > 0


def add_video_sources(
    sources: List[Dict[str, str]],
    xml_path: Optional[str] = None,
) -> int:
    """Add multiple video sources to sources.xml without duplicating paths.

    Returns the number of sources newly added.
    """
    if not sources:
        return 0

    filepath = ensure_sources_file(xml_path)
    try:
        tree = ET.parse(filepath)
        root = tree.getroot()
    except Exception:
        root = ET.fromstring(_DEFAULT_SOURCES_XML)
        tree = ET.ElementTree(root)

    video = root.find("video")
    if video is None:
        video = ET.SubElement(root, "video")
        default = ET.SubElement(video, "default")
        default.set("pathversion", "1")

    # Collect existing paths (normalize trailing slashes)
    existing_paths = set()
    for s in video.findall("source"):
        p_elem = s.find("path")
        if p_elem is not None and p_elem.text:
            existing_paths.add(p_elem.text.strip().rstrip("/"))

    added_count = 0
    for src in sources:
        raw_path = src.get("path", "").strip()
        norm_path = raw_path.rstrip("/")
        if not norm_path or norm_path in existing_paths:
            continue

        source_elem = ET.SubElement(video, "source")
        name_elem = ET.SubElement(source_elem, "name")
        name_elem.text = src.get("name", "Source")

        path_elem = ET.SubElement(source_elem, "path")
        path_elem.set("pathversion", "1")
        path_elem.text = raw_path

        allow_sharing = src.get("allowsharing", "true")
        allow_elem = ET.SubElement(source_elem, "allowsharing")
        allow_elem.text = str(allow_sharing).lower()

        thumbnail = src.get("thumbnail")
        if thumbnail:
            thumb_elem = ET.SubElement(source_elem, "thumbnail")
            thumb_elem.set("pathversion", "1")
            thumb_elem.text = thumbnail

        existing_paths.add(norm_path)
        added_count += 1

    if added_count > 0:
        if hasattr(ET, "indent"):
            ET.indent(tree, space="    ")
        tree.write(filepath, encoding="utf-8", xml_declaration=True)

    return added_count


def remove_video_sources(
    paths: List[str],
    xml_path: Optional[str] = None,
) -> int:
    """Remove video sources matching any of the specified paths.

    Returns the number of sources removed.
    """
    if not paths:
        return 0

    filepath = ensure_sources_file(xml_path)
    try:
        tree = ET.parse(filepath)
        root = tree.getroot()
    except Exception:
        return 0

    video = root.find("video")
    if video is None:
        return 0

    targets = {p.strip().rstrip("/") for p in paths if p}
    removed_count = 0
    for s in list(video.findall("source")):
        p_elem = s.find("path")
        if p_elem is not None and p_elem.text and p_elem.text.strip().rstrip("/") in targets:
            video.remove(s)
            removed_count += 1

    if removed_count > 0:
        if hasattr(ET, "indent"):
            ET.indent(tree, space="    ")
        tree.write(filepath, encoding="utf-8", xml_declaration=True)

    return removed_count


def remove_addon_video_sources(
    addon_id: str,
    xml_path: Optional[str] = None,
) -> int:
    """Remove all video sources originating from a specific addon.

    Returns the number of sources removed.
    """
    filepath = ensure_sources_file(xml_path)
    try:
        tree = ET.parse(filepath)
        root = tree.getroot()
    except Exception:
        return 0

    video = root.find("video")
    if video is None:
        return 0

    prefix = f"plugin://{addon_id}"
    removed_count = 0
    for s in list(video.findall("source")):
        p_elem = s.find("path")
        if p_elem is not None and p_elem.text:
            path_val = p_elem.text.strip()
            if path_val.startswith(prefix) or f"://{addon_id}" in path_val:
                video.remove(s)
                removed_count += 1

    if removed_count > 0:
        if hasattr(ET, "indent"):
            ET.indent(tree, space="    ")
        tree.write(filepath, encoding="utf-8", xml_declaration=True)

    return removed_count


def sync_addon_video_sources(
    addon_id: str,
    new_sources: List[Dict[str, str]],
    xml_path: Optional[str] = None,
) -> int:
    """Replace all existing video sources for an addon with the new set.

    Guarantees no stale or duplicate sources remain when switching modes.
    Returns the number of sources written.
    """
    remove_addon_video_sources(addon_id, xml_path=xml_path)
    if new_sources:
        return add_video_sources(new_sources, xml_path=xml_path)
    return 0


def sync_sources_from_mode(
    addon_id: str,
    addon_name: str,
    get_sources_fn: Callable[[int], List[Dict[str, str]]],
    is_disabled_fn: Optional[Callable[[int], bool]] = None,
    mode_names: Optional[List[str]] = None,
    xml_path: Optional[str] = None,
) -> int:
    """Read sources.mode setting, build the sources list, sync sources.xml, and notify user.

    If the mode is disabled, removes all sources for this addon and notifies the user.
    """
    import xbmcgui

    from tv_common.utils.kodi import get_addon_setting

    mode_idx = 0
    try:
        val = get_addon_setting("sources.mode", int, addon_id=addon_id)
        if val is not None:
            mode_idx = val
    except Exception:
        mode_idx = 0

    disabled = is_disabled_fn(mode_idx) if is_disabled_fn else (mode_idx == 3)
    if disabled:
        remove_addon_video_sources(addon_id, xml_path=xml_path)
        dialog = xbmcgui.Dialog()
        dialog.notification(
            addon_name,
            "Sources vidéo désactivées (sources supprimées)",
            xbmcgui.NOTIFICATION_INFO,
            4000,
        )
        return 0

    sources = get_sources_fn(mode_idx)
    sync_addon_video_sources(addon_id, sources, xml_path=xml_path)

    default_mode_names = ["Navigation", "Médiathèque", "Développeur"]
    labels = mode_names or default_mode_names
    mode_label = labels[mode_idx] if 0 <= mode_idx < len(labels) else f"Mode {mode_idx}"

    dialog = xbmcgui.Dialog()
    dialog.notification(
        addon_name,
        f"{len(sources)} source(s) synchronisée(s) ({mode_label})",
        xbmcgui.NOTIFICATION_INFO,
        4000,
    )
    if xbmc and hasattr(xbmc, "executebuiltin"):
        with contextlib.suppress(Exception):
            xbmc.executebuiltin("Container.Refresh")
    return len(sources)



