"""TV Common utils."""

from tv_common.utils.kodi import (
    DRM,
    build_addon_url,
    get_addon_info,
    get_addon_setting,
    get_drm,
    get_global_setting,
    localize,
    log,
    ok_dialog,
    set_addon_setting,
)
from tv_common.utils.library import clean_library_title
from tv_common.utils.request import get_random_ua, request, request_json
from tv_common.utils.sources import (
    add_video_source,
    add_video_sources,
    get_sources_file_path,
    get_video_sources,
    remove_addon_video_sources,
    remove_video_sources,
    sync_addon_video_sources,
    sync_sources_from_mode,
)

__all__ = [
    "DRM",
    "add_video_source",
    "add_video_sources",
    "build_addon_url",
    "clean_library_title",
    "get_addon_info",
    "get_addon_setting",
    "get_drm",
    "get_global_setting",
    "get_random_ua",
    "get_sources_file_path",
    "get_video_sources",
    "localize",
    "log",
    "ok_dialog",
    "remove_addon_video_sources",
    "remove_video_sources",
    "request",
    "request_json",
    "set_addon_setting",
    "sync_addon_video_sources",
    "sync_sources_from_mode",
]