"""Shared helpers for addon routers and providers."""

from typing import Any, Callable, Dict, List, Mapping

import xbmc
from routing import Plugin as Router

from tv_common.utils.kodi import log, ok_dialog


def init_router(router: Router) -> None:
    """Run the addon router, catching any route exception.

    Wraps the dispatch so any exception in a view function is caught,
    logged and surfaced to the user instead of leaving a raw Kodi error.
    """
    try:
        from tv_common.utils.gui import sync_addon_icon

        sync_addon_icon(notify_gui=False)
    except Exception as e:
        log(f"Failed to sync addon icon during init_router: {e}", xbmc.LOGDEBUG)

    try:
        router.run()
    except Exception as e:
        import traceback
        log(f"Unhandled error in route: {e}\n{traceback.format_exc()}", xbmc.LOGERROR)
        ok_dialog(str(e))


def dispatch_by_depth(getters: List[Callable], levels: List[str]):
    """Dispatch catchup navigation to the getter matching the URL depth.

    ``getters`` is ordered from shallowest (e.g. channel list) to deepest
    (e.g. episodes). Levels deeper than the available getters return an
    empty list (defensive: never call a getter with wrong arity).
    """
    depth = len(levels)
    if not getters or depth >= len(getters):
        return []
    return getters[depth](*levels[:depth])


def to_json_streams(channels: List[Dict], mapping: Mapping[str, Callable[[Dict], Any]]) -> List[Dict]:
    """Convert provider channels to the JSON-STREAMS format of IPTV Manager.

    ``mapping`` maps the output keys (id, name, preset, logo, stream, group)
    to callables extracting the value from a raw channel dict.
    """
    return [
        {
            "id": str(mapping["id"](channel)),
            "name": mapping["name"](channel),
            "preset": str(mapping["preset"](channel)),
            "logo": mapping["logo"](channel),
            "stream": mapping["stream"](channel),
            "group": mapping["group"](channel),
        }
        for channel in channels
    ]
