"""Library (.strm) helpers — expose addon VOD content in the Kodi video library."""

import hashlib
import os
import re
import unicodedata

import xbmcvfs

from tv_common.abstract_provider import AbstractProvider
from tv_common.utils.kodi import get_addon_info, log, ok_dialog


def clean_library_title(raw_title: str) -> tuple[str, int | None]:
    """Clean IPTV title for Kodi scrapers (e.g. TMDb).

    - Extracts trailing year (e.g. 'Matrix (1999)' or 'Film - 1999 [VOSTFR]').
    - Strips country/language prefixes (e.g. 'FR - ', 'EN - ', 'VIP - ').
    - Strips bracketed tags (e.g. '[VOSTFR]', '[MULTI-SUB]', '[4K]').
    - Strips trailing season indicators (e.g. 'S01', 'Saison 1') on series folders.
    - Trims excess whitespace and punctuation.
    """
    if not raw_title or not str(raw_title).strip():
        return "", None

    title = str(raw_title).strip()
    year = None

    # 1. Extract trailing year, e.g. "Matrix (1999)" or "Matrix - 1999 [VOSTFR]"
    m_year = re.search(r"\s*\((\d{4})\)\s*(?:\[.*?\]\s*)*$", title)
    if not m_year:
        m_year = re.search(r"[-–—]\s*(\d{4})\s*(?:\[.*?\]\s*)*$", title)
    if m_year:
        try:
            y = int(m_year.group(1))
            if 1900 <= y <= 2100:
                year = y
                prefix_part = title[:m_year.start()].rstrip()
                suffix_part = title[m_year.end():].lstrip()
                if prefix_part.endswith("("):
                    prefix_part = prefix_part[:-1].rstrip()
                if suffix_part.startswith(")"):
                    suffix_part = suffix_part[1:].lstrip()
                candidate = (prefix_part + " " + suffix_part).strip()
                if candidate:
                    title = candidate
        except ValueError:
            pass

    # 2. Strip country / language / format prefixes
    for _ in range(2):
        prefixed = re.sub(r"^(?:\[[A-Za-z]{2,4}\]|\([A-Za-z]{2,4}\))\s*[-:|/]?\s*", "", title)
        if prefixed.strip():
            title = prefixed
        prefixed = re.sub(r"^(?:[A-Za-z]{2,4}|VIP|UHD|FHD|4K|HD)\s*[-:|/]\s*", "", title)
        if prefixed.strip():
            title = prefixed

    # 3. Strip bracketed quality/sub tags
    without_brackets = re.sub(r"\[.*?\]", "", title)
    if without_brackets.strip():
        title = without_brackets

    # 4. Strip season suffixes at the end of TV show folder names
    while True:
        stripped = re.sub(r"\s+(?:(?:Saison|Season)\s+\d+|S\d{1,2})\s*$", "", title, flags=re.IGNORECASE)
        if stripped == title or not stripped.strip():
            break
        title = stripped

    title = re.sub(r"\s+", " ", title)
    title = title.strip(" -–—:|/")
    return title or raw_title, year


def get_library_path() -> str:
    """Return the writable library folder for the current addon.

    Uses the addon profile (special://profile/addon_data/<addon>/library/),
    which is always writable — unlike the addon install folder.
    """
    profile = xbmcvfs.translatePath(get_addon_info("profile"))
    return os.path.join(profile, "library")


# --- Canonical show grouping (library feed) ----------------------------------
#
# IPTV catalogues list the same series several times, once per language/quality
# variant ("FR - The Simpsons", "AR - آل سيمبسون The Simpsons", "[MULTI-SUB] The
# Simpsons"). clean_library_title() strips those prefixes, so every variant used
# to resolve to the SAME TMDb show while each variant still created its own
# folder and its own episode rows — Kodi ended up with duplicated episodes
# (one per variant) for every multilingual series. Grouping the variants under
# one canonical folder path fixes that at the source.

# Language preference for the library feed: the first language wins when the
# same episode exists in several variants.
LANGUAGE_PREFERENCE = ("fr", "ar", "en")

# "EAR" is a supplier typo for AR on the OTT catalogue; quality tags are not
# languages and must not be ranked as such.
_LANGUAGE_ALIASES = {"ear": "ar"}
_QUALITY_TAGS = {"vip", "uhd", "fhd", "4k", "hd", "sd", "multi", "vos", "vf"}
# Bracket/paren forms need no separator after the tag; the bare form does (else
# "The Simpsons" would be read as a language tag).
_BRACKET_PREFIX = re.compile(r"^(?:\[([A-Za-z]{2,4})\]|\(([A-Za-z]{2,4})\))\s*[-:|/]?\s*")
_BARE_PREFIX = re.compile(r"^([A-Za-z]{2,4})\s*[-:|/]\s*")

# œ/æ/ß are not decomposed by NFKD, they must be transliterated explicitly for
# slugs and for the latin-part grouping key.
_TRANSLITERATIONS = str.maketrans(
    {
        "œ": "oe", "Œ": "OE", "æ": "ae", "Æ": "AE", "ß": "ss",
        "ø": "o", "Ø": "O", "đ": "d", "Đ": "D", "ð": "d", "Ð": "D",
        "þ": "th", "Þ": "TH", "ł": "l", "Ł": "L",
    }
)

_LATIN_LETTER = re.compile(r"[A-Za-z]")
_NON_ASCII = re.compile(r"[^\x00-\x7F]")


def variant_language(raw_title: str) -> str:
    """Return the language tag carried by an IPTV title prefix ("" if none).

    "FR - Foo" → "fr", "[EN] Foo" → "en", "EAR - Foo" → "ar" (supplier typo),
    "4K - Foo" → "" (quality tag, not a language).
    """
    text = str(raw_title or "").strip()
    match = _BRACKET_PREFIX.match(text) or _BARE_PREFIX.match(text)
    if not match:
        return ""
    tag = (match.group(1) or match.group(2) or "").lower()
    if not tag or tag in _QUALITY_TAGS:
        return ""
    return _LANGUAGE_ALIASES.get(tag, tag)


def _latin_only(text: str) -> str:
    """Keep only the latin part of a title ("" when there is none).

    A part made only of digits/punctuation does not count as latin: Arabic
    titles carry trailing digits ("دكتور حب ج2") and grouping them on "2" would
    merge dozens of unrelated series.
    """
    transliterated = str(text or "").translate(_TRANSLITERATIONS)
    ascii_text = (
        unicodedata.normalize("NFKD", transliterated).encode("ascii", "ignore").decode()
    )
    latin = re.sub(r"\s+", " ", ascii_text).strip(" -–—:|/")
    return latin if _LATIN_LETTER.search(latin) else ""


def canonical_title_key(clean_title: str) -> str:
    """Return the grouping key of a cleaned title.

    Several catalogue variants carry a translated title with the original name
    appended ("آل سيمبسون The Simpsons" for "The Simpsons"): grouping on the
    latin part keeps those variants together, while a title with no latin
    characters groups on its own text.
    """
    return (_latin_only(clean_title) or str(clean_title or "")).casefold()


# "[FR] ", "(EN) ", "FR - ", "EAR - ", "4K - " … — the language/quality tag that
# starts an IPTV title.
def strip_variant_prefix(raw_title: str) -> str:
    """Remove the leading language/quality tag from a catalogue title.

    clean_library_title() alone is not enough for labels: applied to a title
    that IS a year ("EAR - 1992") it extracts the year first and leaves the bare
    tag ("EAR"). Stripping the tag first keeps "1992" as the usable name.
    """
    text = str(raw_title or "").strip()
    stripped = _BARE_PREFIX.sub("", _BRACKET_PREFIX.sub("", text)).strip()
    return stripped or text


def display_title(raw_title: str) -> tuple[str, int | None]:
    """Return the (cleaned) title usable as a library folder label, plus its year.

    The year is read from the raw title too, so a series whose name IS a year
    ("EAR - 1992") keeps both its name and its year hint.
    """
    clean_title, year = clean_library_title(strip_variant_prefix(raw_title))
    if year is None:
        year = clean_library_title(raw_title)[1]
    return clean_title, year


def variant_rank(raw_title: str) -> int:
    """Sort key of a catalogue variant: lower is preferred (FR > AR > EN >autres)."""
    language = variant_language(raw_title)
    try:
        return LANGUAGE_PREFERENCE.index(language)
    except ValueError:
        return len(LANGUAGE_PREFERENCE)


def library_slug(title: str, year: int | None = None) -> str:
    """Return a stable, URL-safe slug for a canonical title.

    Titles without latin letters (Arabic…) fall back to a short hash: their
    transliteration would be empty or a lone digit ("قهوة 2" → "2"), and two
    different series sharing one slug would collide as the same library item.
    """
    transliterated = str(title or "").translate(_TRANSLITERATIONS)
    ascii_text = (
        unicodedata.normalize("NFKD", transliterated).encode("ascii", "ignore").decode()
    )
    slug = re.sub(r"[^A-Za-z0-9]+", "-", ascii_text).strip("-").lower()
    if not _LATIN_LETTER.search(slug) and (_NON_ASCII.search(str(title or "")) or not slug):
        slug = "serie-" + hashlib.sha1(str(title or "").encode("utf-8")).hexdigest()[:10]
    return f"{slug}-{year}" if year else slug


def _catalogue_year(entry: dict):
    """Return the 4-digit year declared by a catalogue entry (None if unusable)."""
    raw = entry.get("year")
    if raw is None:
        return None
    candidate = str(raw).strip()[:4]
    return int(candidate) if candidate.isdigit() else None


def group_canonical_shows(
    entries: list, title_key: str = "name", id_key: str = "series_id"
) -> list:
    """Group catalogue entries that share one canonical title (language variants).

    Returns groups in catalogue order, each one:
      {"title", "year", "slug", "variants": [{"id", "title", "rank", "entry"}, ...]}
    Variants are sorted by language preference (FR > AR > EN > autres), ties
    broken by catalogue order. Entries without an id or without a usable title
    are dropped, and a variant never appears in two groups.
    """
    buckets: dict[str, list] = {}

    for entry in entries or []:
        if not isinstance(entry, dict):
            continue
        variant_id = entry.get(id_key)
        if variant_id in (None, ""):
            continue
        clean_title, extracted_year = display_title(entry.get(title_key) or "")
        if not clean_title:
            continue
        variant = {
            "id": variant_id,
            "title": entry.get(title_key) or "",
            "clean_title": clean_title,
            "year": _catalogue_year(entry) or extracted_year,
            "rank": variant_rank(entry.get(title_key) or ""),
            "entry": entry,
        }
        buckets.setdefault(canonical_title_key(clean_title), []).append(variant)

    ordered = []
    for variants in buckets.values():
        # Same title, several known years = several distinct shows (reboots,
        # remakes): split them. Variants without a year follow the only known
        # year when there is exactly one, otherwise they stay on their own.
        years = sorted({v["year"] for v in variants if v["year"] is not None})
        if len(years) <= 1:
            ordered.append(_build_show_group(variants))
            continue

        undated = [v for v in variants if v["year"] is None]
        for year in years:
            ordered.append(_build_show_group([v for v in variants if v["year"] == year]))
        if undated:
            ordered.append(_build_show_group(undated))

    return ordered


def _build_show_group(variants: list) -> dict:
    """Sort variants by language preference and name the canonical folder."""
    variants.sort(key=lambda variant: variant["rank"])
    preferred = variants[0]
    year = next((v["year"] for v in variants if v["year"] is not None), None)
    group = {
        "title": preferred["clean_title"],
        "year": year,
        "variants": variants,
    }
    group["slug"] = library_slug(group["title"], group["year"])
    return group


def _write_strm_file(directory: str, name: str, url: str) -> bool:
    """Write a single .strm file pointing to an addon URL.

    .strm files are plain text files whose content is a playable URL;
    the Kodi video library scans them like regular video files.
    Duplicate names get a numeric suffix so items are never overwritten.
    """
    library_folder = get_library_path()

    if directory:
        library_folder = os.path.join(library_folder, directory)

    if not os.path.exists(library_folder):
        os.makedirs(library_folder)

    clean_name, _ = clean_library_title(name)
    base_name = _safe_filename(clean_name or name)
    filename = os.path.join(library_folder, base_name + ".strm")
    suffix = 1
    while os.path.exists(filename):
        filename = os.path.join(library_folder, f"{base_name}_{suffix}.strm")
        suffix += 1

    with open(filename, "w", encoding="utf-8") as file:
        file.write(url)

    return True


def write_strm_files(items: list, directory: str = "") -> int:
    """Write .strm files for a list of items.

    Each item is a dict with: label, path (addon URL) and an optional
    subdirectory. Returns the number of files written.
    """
    count = 0

    for item in items:
        label = item.get("label")
        url = item.get("path")

        if not label or not url:
            continue

        subdir = item.get("library_dir", directory)
        if _write_strm_file(subdir, label, url):
            count += 1

    return count


def export_catchup_items(provider: AbstractProvider, levels: list, directory: str = "") -> int:
    """Write one .strm file per non-folder item at the given catchup level.

    Folder items are intentionally not recursed: exporting is done
    level by level from the VOD navigation, which keeps each call fast
    enough for the Kodi plugin timeout. Returns the number of files.
    Existing .strm files in the target directory are removed first so
    re-exporting a level does not create duplicates.
    """
    items = provider.get_catchup_items(levels)
    exportable = [item for item in items if not item.get("is_folder")]

    _clear_library_dir(directory)

    return write_strm_files(exportable, directory)


def _clear_library_dir(directory: str) -> None:
    """Remove existing .strm files in the target library directory."""
    library_folder = os.path.join(get_library_path(), directory) if directory else get_library_path()
    if not os.path.isdir(library_folder):
        return
    for filename in os.listdir(library_folder):
        if filename.endswith(".strm"):
            try:
                os.remove(os.path.join(library_folder, filename))
            except OSError as e:
                log(f"cannot remove {filename}: {e}")


def build_export_item(levels: list, label: str = "📥 Exporter vers la bibliothèque") -> dict:
    """Build a directory item that exports the given catchup level to the library.

    The item is a folder (is_folder=True): the export route runs the export
    and ends its directory, so Kodi navigates into it and back out cleanly.
    """
    from tv_common.utils.kodi import build_addon_url

    return {
        "is_folder": True,
        "label": label,
        "path": build_addon_url("/library/export/" + "/".join(levels)),
    }


def notify_export(count: int, directory: str = "") -> None:
    """Notify the user about a library export."""
    if count <= 0:
        log("No items exported to library")
        ok_dialog("Aucun élément exporté (dossier vide ?)")
        return

    library_folder = os.path.join(get_library_path(), directory) if directory else get_library_path()
    log(f"Added {count} items to library @ {library_folder}")
    ok_dialog(f"{count} éléments ajoutés à la bibliothèque.\n\n{library_folder}")


def _safe_filename(name: str) -> str:
    """Sanitize a name into a filesystem-safe filename."""
    chars = '<>:"/\\|?*'
    for char in chars:
        name = name.replace(char, "_")
    return name.strip().strip(".") or "untitled"