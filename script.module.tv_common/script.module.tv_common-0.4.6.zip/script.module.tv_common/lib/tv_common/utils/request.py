"""Request utils."""

import time
from random import randint
from typing import Mapping, Union

import xbmc
from requests import Response, Session
from requests.exceptions import (
    ConnectionError as RequestsConnectionError,
)
from requests.exceptions import JSONDecodeError, RequestException, Timeout

from tv_common.exceptions import StreamRequestException
from tv_common.utils.kodi import log

# Network backoff: after a transport-level failure (ConnectionReset, proxy
# 5xx, timeout) we refuse to hit the provider again for a while. Orange's
# proxy rate-limits aggressively (502 after ~20 rapid requests), and the
# addon must never hammer it — caches are served instead.
_BACKOFF_SEC = 600  # 10 minutes
_last_network_error = 0.0


def network_backoff_active() -> bool:
    """Return True when we are in the cooldown period after a network error."""
    return time.time() - _last_network_error < _BACKOFF_SEC


def note_network_error() -> None:
    """Record a transport-level failure to start the backoff window."""
    global _last_network_error
    _last_network_error = time.time()

_USER_AGENTS = [
    # Chrome
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/123.0.0.0 Safari/537.3",
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_12_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/103.0.0.0 Safari/537.3",  # noqa: E501
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/102.0.0.0 Safari/537.3",  # noqa: E501
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/109.0.0.0 Safari/537.3",
    # Edge
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/123.0.0.0 Safari/537.36 Edg/123.0.0",  # noqa: E501
    # Firefox
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:124.0) Gecko/20100101 Firefox/124.",
    "Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:109.0) Gecko/20100101 Firefox/115.",
    # Opera
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36 OPR/108.0.0.",  # noqa: E501
    # Safari
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.3.1 Safari/605.1.1",  # noqa: E501
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/16.6 Safari/605.1.1",  # noqa: E501
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_13_6) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/13.1.2 Safari/605.1.1",  # noqa: E501
]


def get_random_ua() -> str:
    """Get a randomised user agent."""
    return _USER_AGENTS[randint(0, len(_USER_AGENTS) - 1)]


def request(method: str, url: str, headers: Mapping[str, str] = None, data=None, session: Session = None) -> Response:
    """Send HTTP request using requests."""
    default_headers = {
        "Accept": "application/json",
        "Accept-Encoding": "gzip, deflate, br",
        "Accept-Language": "*",
        "Sec-Fetch-Mode": "cors",
        "User-Agent": get_random_ua(),
    }

    headers = {**(session.headers if session is not None else default_headers), **(headers or {})}
    session = session or Session()

    if network_backoff_active():
        log("Network backoff active, skipping request", xbmc.LOGDEBUG)
        raise RequestException("network backoff active, serving cache instead")

    log(f"Fetching {url}", xbmc.LOGDEBUG)
    try:
        res = session.request(method, url, headers=headers, data=data)
        res.raise_for_status()
        log(f" -> {res.status_code}", xbmc.LOGDEBUG)
        return res
    except RequestException as e:
        # Transport-level failures (connection reset, proxy 5xx, timeout)
        # trigger the backoff so we stop hammering the provider.
        if isinstance(e, (RequestsConnectionError, Timeout)) or (
            getattr(e, "response", None) is not None and e.response.status_code >= 500
        ):
            note_network_error()
            log(f"Network error ({e}), entering backoff", xbmc.LOGWARNING)
        raise


def request_json(url: str, headers: Mapping[str, str] = None, default: Union[dict, list] = None) -> Union[dict, list]:
    """Send HTTP request and load json response."""
    try:
        res = request("GET", url, headers=headers)
        res.raise_for_status()
    except RequestException as e:
        # During the network backoff we must NOT swallow the error: the
        # caller's cache decorator needs to see the failure so it serves
        # the stale cache instead of overwriting it with empty data.
        # Raise a StreamRequestException so managers surface a localized
        # message instead of a raw English ConnectionResetError.
        if network_backoff_active():
            raise StreamRequestException("network backoff active, serving cache instead") from e
        log(e, xbmc.LOGWARNING)
        return default

    try:
        content = res.json()
    except JSONDecodeError:
        log("Cannot load json content", xbmc.LOGWARNING)
        log(res.text, xbmc.LOGDEBUG)
        return default

    return content