"""Abstract TV Provider."""

from abc import ABC, abstractmethod
from typing import List, Optional, Union


class AbstractProvider(ABC):
    """Provide methods to be implemented by each TV provider."""

    name: str = ""

    @abstractmethod
    def get_live_stream_info(self, stream_id: str) -> dict:
        """Get live stream information for the specified id.

        Returned keys: path, protocol, mime_type, drm_config.
        """
        pass

    @abstractmethod
    def get_catchup_stream_info(self, stream_id: str) -> dict:
        """Get catchup stream information for the specified id.

        Returned keys: path, protocol, mime_type, drm_config.
        """
        pass

    @abstractmethod
    def get_streams(self) -> list:
        """Retrieve all available channels following JSON-STREAMS format.

        Each item: id, name, preset, logo, stream (addon url), group.
        """
        pass

    @abstractmethod
    def get_epg(self) -> Union[str, dict]:
        """Return EPG data for the specified period.

        Either JSON-EPG format (dict) or raw XMLTV (str), depending on what
        the provider and its consumer (IPTV Manager) support.
        """
        pass

    @abstractmethod
    def get_catchup_items(self, levels: List[str]) -> list:
        """Return a list of directory items for the specified levels.

        Each item: is_folder, label, path, art, info, content_type.
        """
        pass

    def get_category_name(self, levels: List[str]) -> Optional[str]:
        """Return breadcrumb category name for the given navigation levels, or None."""
        return None