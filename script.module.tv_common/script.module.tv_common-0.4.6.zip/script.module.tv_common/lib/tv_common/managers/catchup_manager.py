"""Catchup TV Manager."""

from typing import List, Optional, Union

import xbmc
import xbmcplugin

from tv_common.abstract_provider import AbstractProvider
from tv_common.exceptions import StreamRequestException
from tv_common.utils.bookmarks import get_kodi_bookmarks, normalize_path
from tv_common.utils.gui import create_list_item
from tv_common.utils.kodi import localize, log, ok_dialog

_MEDIA_TYPE_TO_CONTENT_TYPE = {
    "movie": "movies",
    "tvshow": "tvshows",
    "season": "seasons",
    "episode": "episodes",
    "video": "videos",
    "musicvideo": "musicvideos",
}


class CatchupManager:
    """Navigate through catchup TV content."""

    def __init__(self, provider: AbstractProvider, handle: int):
        """Initialize Catchup Manager object."""
        self.provider = provider
        self.handle = handle

    def render_items(
        self,
        items: List[dict],
        content_type: Optional[str] = None,
        category_name: Optional[str] = None,
    ) -> None:
        """Render given directory items to Kodi using batch C++ API."""
        if category_name and hasattr(xbmcplugin, "setPluginCategory"):
            xbmcplugin.setPluginCategory(self.handle, category_name)

        directory_items = []
        detected_content_types = set()
        bookmarks = get_kodi_bookmarks()

        for item in items:
            is_folder = item.get("is_folder", False)
            if not is_folder and bookmarks:
                path = item.get("path")
                bookmark = bookmarks.get(normalize_path(path)) if path else None
                if bookmark:
                    resume_time, total_time = bookmark
                    info = item.setdefault("info", {})
                    if "resumetime" not in info:
                        info["resumetime"] = resume_time
                    if "totaltime" not in info and total_time > 0:
                        info["totaltime"] = total_time
                    if not info.get("duration") and total_time > 0:
                        info["duration"] = int(total_time)

            list_item = create_list_item(item, is_folder)
            context_menu = item.get("context_menu")
            if context_menu:
                formatted_menu = []
                for label, action in context_menu:
                    if action.startswith(
                        (
                            "Container.",
                            "ActivateWindow(",
                            "RunPlugin(",
                            "RunScript(",
                            "PlayMedia(",
                        )
                    ):
                        formatted_menu.append((label, action))
                    else:
                        formatted_menu.append((label, f"RunPlugin({action})"))
                list_item.addContextMenuItems(formatted_menu, replaceItems=False)
            directory_items.append((item["path"], list_item, is_folder))

            c_type = item.get("content_type")
            if not c_type:
                media_type = item.get("info", {}).get("mediatype")
                c_type = _MEDIA_TYPE_TO_CONTENT_TYPE.get(media_type)
            if c_type:
                detected_content_types.add(c_type)

        if hasattr(xbmcplugin, "addDirectoryItems"):
            xbmcplugin.addDirectoryItems(self.handle, directory_items, len(directory_items))
        else:
            for path, list_item, is_folder in directory_items:
                xbmcplugin.addDirectoryItem(self.handle, path, list_item, is_folder)

        effective_content_type = content_type or (
            detected_content_types.pop() if detected_content_types else None
        )
        if effective_content_type and hasattr(xbmcplugin, "setContent"):
            xbmcplugin.setContent(self.handle, effective_content_type)

        xbmcplugin.endOfDirectory(self.handle)

    def build_directory(
        self,
        levels: Union[str, List[str], None] = None,
        content_type: Optional[str] = None,
        category_name: Optional[str] = None,
    ) -> None:
        """Build catchup TV directory."""
        if isinstance(levels, list):
            level_list = levels
        elif isinstance(levels, str) and levels:
            level_list = levels.split("/")
        else:
            level_list = []

        try:
            items = self.provider.get_catchup_items(level_list)
        except StreamRequestException as e:
            log(str(e), xbmc.LOGERROR)
            ok_dialog(localize(30900))
            xbmcplugin.endOfDirectory(self.handle)
            return

        if category_name is None:
            if hasattr(self.provider, "get_category_name"):
                category_name = self.provider.get_category_name(level_list)
            if not category_name and level_list:
                category_name = " > ".join(
                    lvl.replace("_", " ").title() for lvl in level_list if lvl
                )
            elif not category_name and not level_list:
                category_name = getattr(self.provider, "name", "") or "Accueil"

        self.render_items(items, content_type=content_type, category_name=category_name)