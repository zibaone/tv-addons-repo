"""Video stream manager."""

import contextlib
from typing import Callable

import inputstreamhelper
import xbmc
import xbmcplugin

from tv_common.abstract_provider import AbstractProvider
from tv_common.exceptions import (
    AuthenticationRequired,
    StreamDataDecodeError,
    StreamNotIncluded,
    StreamRequestException,
)
from tv_common.utils.gui import create_play_item
from tv_common.utils.kodi import localize, log, ok_dialog


class StreamManager:
    """Load video streams using the given provider."""

    def __init__(self, provider: AbstractProvider, handle: int, args: dict = None):
        """Initialize Stream Manager object."""
        self.provider = provider
        self.handle = handle
        self.args = args if args is not None else getattr(provider, "args", {})

    def load_live_stream(self, stream_id: str) -> None:
        """Load live TV stream."""
        self._load_stream(self.provider.get_live_stream_info, stream_id=stream_id)

    def load_catchup_stream(self, stream_id: str) -> None:
        """Load catchup TV stream."""
        self._load_stream(self.provider.get_catchup_stream_info, stream_id=stream_id)

    def _load_stream(self, stream_getter: Callable[[str], dict], stream_id: str) -> None:
        """Load stream."""
        try:
            stream_info = stream_getter(stream_id)
        except StreamNotIncluded:
            log("Stream not included in subscription", xbmc.LOGERROR)
            ok_dialog(localize(30900))
            with contextlib.suppress(Exception):
                xbmcplugin.setResolvedUrl(self.handle, False, create_play_item())
            return
        except StreamDataDecodeError:
            log("Cannot decode stream data", xbmc.LOGERROR)
            ok_dialog(localize(30900))
            with contextlib.suppress(Exception):
                xbmcplugin.setResolvedUrl(self.handle, False, create_play_item())
            return
        except AuthenticationRequired as e:
            log(e, xbmc.LOGERROR)
            ok_dialog(localize(30902))
            with contextlib.suppress(Exception):
                xbmcplugin.setResolvedUrl(self.handle, False, create_play_item())
            return
        except StreamRequestException as e:
            log(str(e), xbmc.LOGERROR)
            ok_dialog(localize(30900))
            with contextlib.suppress(Exception):
                xbmcplugin.setResolvedUrl(self.handle, False, create_play_item())
            return

        # Enrich stream_info with title / metadata from query params or Kodi GUI
        if not stream_info.get("title") and not stream_info.get("label"):
            arg_title = ""
            if self.args and isinstance(self.args, dict):
                title_list = self.args.get("title") or []
                if title_list:
                    arg_title = str(title_list[0])
            if not arg_title:
                with contextlib.suppress(Exception):
                    gui_title = xbmc.getInfoLabel("ListItem.Title") or xbmc.getInfoLabel("ListItem.Label")
                    if gui_title and gui_title not in ("..", ""):
                        arg_title = gui_title
            if arg_title:
                stream_info["title"] = arg_title
                stream_info["label"] = arg_title

        if self.args and isinstance(self.args, dict):
            info = stream_info.setdefault("info", {})
            if isinstance(info, dict):
                if not info.get("title") and stream_info.get("title"):
                    info["title"] = stream_info["title"]
                for k in ("season", "episode", "mediatype", "year", "plot"):
                    v = self.args.get(k)
                    if v and k not in info:
                        info[k] = v[0]

        protocol = stream_info.get("protocol", "")
        drm_cfg = stream_info.get("drm_config", {})
        drm = drm_cfg.get("license_type")
        if not drm and drm_cfg.get("drm_legacy"):
            drm = drm_cfg["drm_legacy"].split("|")[0]

        if drm or protocol in ("hls", "mpd"):
            try:
                is_helper = (
                    inputstreamhelper.Helper(protocol, drm=drm)
                    if drm
                    else inputstreamhelper.Helper(protocol)
                )

                if is_helper.check_inputstream():
                    play_item = create_play_item(stream_info, is_helper.inputstream_addon)
                    xbmcplugin.setResolvedUrl(self.handle, True, play_item)
                    return
            except Exception as e:
                log(f"Cannot initialize InputStream helper: {e}", xbmc.LOGWARNING)

            if drm:
                log("Cannot load InputStream for DRM stream", xbmc.LOGERROR)
                ok_dialog(localize(30901))
                with contextlib.suppress(Exception):
                    xbmcplugin.setResolvedUrl(self.handle, False, create_play_item())
                return

        # Plain stream (e.g. HTTP TS) or fallback: resolve directly
        play_item = create_play_item(stream_info)
        xbmcplugin.setResolvedUrl(self.handle, True, play_item)