"""Central background service implementation for TV addons."""

from typing import Optional

import xbmc

from tv_common.utils.gui import sync_addon_icon
from tv_common.utils.kodi import get_addon_info

_MonitorBase = getattr(xbmc, "Monitor", object)


class AddonSettingsMonitor(_MonitorBase):
    """Monitor setting changes for an addon."""

    def __init__(self, addon_id: str):
        """Initialize monitor with addon ID."""
        super().__init__()
        self.addon_id = addon_id
        self._last_sources_mode = None
        try:
            from tv_common.utils.kodi import get_addon_setting

            self._last_sources_mode = get_addon_setting("sources.mode", int, addon_id=self.addon_id)
        except Exception:
            pass

    def onSettingsChanged(self):
        """Handle addon settings modification by syncing visual assets and video sources."""
        xbmc.log(f"[{self.addon_id}] onSettingsChanged triggered", xbmc.LOGINFO)
        sync_addon_icon(addon_id=self.addon_id, notify_gui=True)
        self._check_and_sync_sources()

    def _check_and_sync_sources(self):
        """Automatically synchronize video sources if sources.mode setting changed."""
        try:
            from tv_common.utils.kodi import get_addon_setting

            current_mode = get_addon_setting("sources.mode", int, addon_id=self.addon_id)
            if current_mode is not None and current_mode != self._last_sources_mode:
                xbmc.log(
                    f"[{self.addon_id}] sources.mode: {self._last_sources_mode} -> {current_mode}",
                    xbmc.LOGINFO,
                )
                self._last_sources_mode = current_mode
                if xbmc and hasattr(xbmc, "executebuiltin"):
                    xbmc.executebuiltin(f"RunPlugin(plugin://{self.addon_id}/library/sources/sync)")
        except Exception as e:
            xbmc.log(f"[{self.addon_id}] _check_and_sync_sources error: {e}", xbmc.LOGWARNING)



def run_addon_service(addon_id: Optional[str] = None) -> None:
    """Run background monitor service for an addon."""
    resolved_id = addon_id or get_addon_info("id")
    sync_addon_icon(addon_id=resolved_id, notify_gui=False)

    monitor = AddonSettingsMonitor(resolved_id)
    while not monitor.abortRequested():
        if monitor.waitForAbort(10):
            break
