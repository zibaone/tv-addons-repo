"""TV Common — shared abstraction for TV streaming Kodi addons."""

from tv_common.abstract_provider import AbstractProvider
from tv_common.exceptions import (
    AuthenticationRequired,
    StreamDataDecodeError,
    StreamNotIncluded,
    StreamRequestException,
)

try:
    from tv_common.managers import CatchupManager, IPTVManager, StreamManager
except ImportError:
    CatchupManager = None  # type: ignore
    IPTVManager = None  # type: ignore
    StreamManager = None  # type: ignore

__all__ = [
    "AbstractProvider",
    "AuthenticationRequired",
    "CatchupManager",
    "IPTVManager",
    "StreamDataDecodeError",
    "StreamManager",
    "StreamNotIncluded",
    "StreamRequestException",
]