"""MPEG-TS timeline inspection and repair in pure Python (no Kodi imports).

Some panel servers return replay slots whose MPEG-TS stream starts
mid-packet and whose timestamp track is broken: the 33-bit clock wraps
inside the file (players then report absurd ~26 h durations), the track
resets backwards to a lower value mid-file (no duration at all), or stray
spliced fragments push the clock hours ahead. Consequences in Kodi: no seek
bar, playback behaves like a live stream.

This module rebuilds a monotone timeline: it walks the TS packets, follows
the DTS track (rewriting the PTS with the same offset so the PTS-DTS gap is
preserved) and shifts the PCR with the same offset. Backward jumps are
continued from the previous value; absurd forward gaps are absorbed, while
plausible holes (a few seconds) are kept. Only the timestamp bytes inside
PES headers and adaptation fields are modified; everything else is copied
byte for byte.
"""

from __future__ import annotations

import contextlib
import os
from dataclasses import dataclass
from typing import Callable

from tv_common.exceptions import DownloadCancelledError, DownloadError

TS_PACKET_SIZE = 188
TS_SYNC_BYTE = 0x47

TICKS_PER_SECOND = 90000
PCR_TICKS_PER_TICK = 300
CLOCK_WRAP_TICKS = 1 << 33

# Calibrated on the real defective fixtures (see tests): a backward jump of
# more than one second is a reset/wrap; a forward gap beyond 20 s cannot be a
# real recording hole (observed junk jumps are minutes to hours long) while
# genuine holes in these captures stay below 15 s.
BACKWARD_TOLERANCE_TICKS = 1 * TICKS_PER_SECOND
FORWARD_TOLERANCE_TICKS = 20 * TICKS_PER_SECOND
CONTINUATION_STEP_TICKS = 1800  # 20 ms — keeps continued values strictly increasing
MAX_SANE_SPAN_SECONDS = 8 * 3600

SAMPLE_BYTES = 2 * 1024 * 1024
COPY_CHUNK_BYTES = 4 * 1024 * 1024
_CARRY_LIMIT = 2 * TS_PACKET_SIZE - 1


class TimelineError(DownloadError):
    """The stream timeline could not be inspected or rebuilt."""


@dataclass(frozen=True)
class TimelineReport:
    """Result of a light timeline inspection (head/tail PES+PCR sampling)."""

    sane: bool
    reason: str
    first_dts: int | None
    last_dts: int | None
    pids: tuple
    span_s: float | None
    head_bytes: int
    tail_bytes: int


@dataclass(frozen=True)
class RepairReport:
    """Statistics of a full timeline rebuild pass."""

    events_backward: int
    events_forward: int
    events_clamped: int
    pes_headers: int
    pcr_fields: int
    first_dts: int
    last_dts: int
    bytes_in: int
    bytes_out: int

    @property
    def duration_s(self) -> float:
        """Rebuilt track duration in seconds."""
        return (self.last_dts - self.first_dts) / TICKS_PER_SECOND


# ── timestamp codec ─────────────────────────────────────────────────────────


def _decode_timestamp(ts_bytes) -> int:
    """Decode a 5-byte PES PTS/DTS field into 90 kHz ticks."""
    return (
        ((ts_bytes[0] & 0x0E) << 29)
        | (ts_bytes[1] << 22)
        | ((ts_bytes[2] & 0xFE) << 14)
        | (ts_bytes[3] << 7)
        | ((ts_bytes[4] & 0xFE) >> 1)
    )


def _encode_timestamp(value: int, prefix: int) -> bytes:
    """Encode 90 kHz ticks into a 5-byte PES field keeping the prefix nibble."""
    return bytes(
        (
            prefix | ((value >> 29) & 0x0E) | 0x01,
            (value >> 22) & 0xFF,
            ((value >> 14) & 0xFE) | 0x01,
            (value >> 7) & 0xFF,
            ((value << 1) & 0xFE) | 0x01,
        )
    )


def _decode_pcr(pcr_bytes) -> int:
    """Decode a 6-byte adaptation-field PCR into its full 27 MHz value."""
    base = (pcr_bytes[0] << 25) | (pcr_bytes[1] << 17) | (pcr_bytes[2] << 9) | (pcr_bytes[3] << 1) | (pcr_bytes[4] >> 7)
    ext = ((pcr_bytes[4] & 0x01) << 8) | pcr_bytes[5]
    return base * PCR_TICKS_PER_TICK + ext


def _encode_pcr(value27: int) -> bytes:
    """Encode a full 27 MHz value into a 6-byte adaptation-field PCR."""
    base, ext = divmod(value27, PCR_TICKS_PER_TICK)
    return bytes(
        (
            (base >> 25) & 0xFF,
            (base >> 17) & 0xFF,
            (base >> 9) & 0xFF,
            (base >> 1) & 0xFF,
            ((base & 1) << 7) | 0x7E | ((ext >> 8) & 0x01),
            ext & 0xFF,
        )
    )


# ── packet helpers ──────────────────────────────────────────────────────────


def _find_sync(buf, start: int, n: int) -> int:
    """Return the next offset whose byte and the one 188 apart are sync bytes."""
    j = buf.find(TS_SYNC_BYTE, start)
    while j != -1:
        if j + TS_PACKET_SIZE >= n:
            return -1
        if buf[j + TS_PACKET_SIZE] == TS_SYNC_BYTE and (
            j + 2 * TS_PACKET_SIZE >= n or buf[j + 2 * TS_PACKET_SIZE] == TS_SYNC_BYTE
        ):
            return j
        j = buf.find(TS_SYNC_BYTE, j + 1)
    return -1


def _pes_timestamp_fields(buf, po: int, packet_end: int) -> tuple[int, int] | None:
    """Return the (PTS, DTS) byte offsets of the PES header at ``po``.

    ``DTS`` is ``-1`` for PTS-only headers. Return ``None`` when the packet
    does not start a readable PES header with timestamps.
    """
    if po + 19 > packet_end or buf[po] or buf[po + 1] or buf[po + 2] != 1:
        return None
    if not buf[po + 6] & 0x80:
        return None
    mode = (buf[po + 7] >> 6) & 3
    if mode == 3:
        return po + 9, po + 14
    if mode == 2:
        return po + 9, -1
    return None


def _sample_stats(buf) -> dict:
    """Parse one sample buffer; return {pid: [first, last, backward, forward]}."""
    n = len(buf)
    per_pid: dict = {}
    i = _find_sync(buf, 0, n)
    while i != -1 and i + TS_PACKET_SIZE <= n:
        byte1 = buf[i + 1]
        pid = ((byte1 & 0x1F) << 8) | buf[i + 2]
        afc = (buf[i + 3] >> 4) & 0x3
        if (byte1 & 0x40) and afc != 2:
            po = i + 5 + buf[i + 4] if afc & 2 else i + 4
            fields = _pes_timestamp_fields(buf, po, i + TS_PACKET_SIZE)
            if fields is not None:
                pts_off, dts_off = fields
                cut = dts_off if dts_off != -1 else pts_off
                value = _decode_timestamp(buf[cut : cut + 5])
                rec = per_pid.get(pid)
                if rec is None:
                    per_pid[pid] = [value, value, 0, 0]
                else:
                    if value < rec[1] - BACKWARD_TOLERANCE_TICKS:
                        rec[2] += 1
                    elif value > rec[1] + FORWARD_TOLERANCE_TICKS:
                        rec[3] += 1
                    rec[1] = value
        i += TS_PACKET_SIZE
        if i + TS_PACKET_SIZE > n:
            break
        if buf[i] != TS_SYNC_BYTE:
            i = _find_sync(buf, i + 1, n)
    return per_pid


# ── light sanity check ──────────────────────────────────────────────────────


def timeline_report(path: str, sample_bytes: int = SAMPLE_BYTES) -> TimelineReport:
    """Inspect ``path`` and return the timeline diagnostic report.

    A few megabytes are read (head and tail samples): every PES timestamp is
    parsed to detect non-monotone jumps inside a sample, a track going
    backwards between the samples (mid-file reset or 33-bit wrap seen as an
    absurd duration) and an implausible total span.
    """
    try:
        size = os.path.getsize(path)
        with open(path, "rb") as handle:
            if size <= 2 * sample_bytes:
                head = _sample_stats(handle.read())
                tail = head
                crossed = False
                read_bytes = size
            else:
                head = _sample_stats(handle.read(sample_bytes))
                handle.seek(size - sample_bytes)
                tail = _sample_stats(handle.read(sample_bytes))
                crossed = True
                read_bytes = sample_bytes
    except OSError as exc:
        raise TimelineError(f"cannot read {path}: {exc}") from exc

    pids = sorted(set(head) | set(tail))
    if not pids:
        return TimelineReport(False, "no-pes-timestamps", None, None, (), None, read_bytes, read_bytes)

    sane, reason = True, "ok"
    if any(rec[2] for rec in head.values()) or any(rec[2] for rec in tail.values()):
        sane, reason = False, "backward-jump-in-sample"
    elif any(rec[3] for rec in head.values()) or any(rec[3] for rec in tail.values()):
        sane, reason = False, "forward-gap-in-sample"

    if sane and crossed:
        for pid in pids:
            head_rec, tail_rec = head.get(pid), tail.get(pid)
            if head_rec and tail_rec and tail_rec[0] < head_rec[1] - BACKWARD_TOLERANCE_TICKS:
                sane, reason = False, "timeline-goes-backward"
                break

    firsts = [rec[0] for rec in head.values()] or [rec[0] for rec in tail.values()]
    lasts = [rec[1] for rec in tail.values()] or [rec[1] for rec in head.values()]
    first = min(firsts)
    last = max(lasts)
    span = (last - first) / TICKS_PER_SECOND
    if sane and span <= 0:
        sane, reason = False, "duration-unmeasurable"
    elif sane and span > MAX_SANE_SPAN_SECONDS:
        sane, reason = False, "duration-out-of-range"

    return TimelineReport(sane, reason, first, last, tuple(pids), span, read_bytes, read_bytes)


def timeline_is_sane(path: str) -> bool:
    """Return True when the file timeline is monotone with a plausible span."""
    return timeline_report(path).sane


# ── full repair pass ────────────────────────────────────────────────────────


class _RepairState:
    """Mutable timeline state shared across chunks of one repair pass."""

    def __init__(self):
        """Start with no offset known yet (anchored on the first timestamp)."""
        self.offset: int | None = None
        self.last_out: int | None = None
        self.first_out: int | None = None
        self.events_backward = 0
        self.events_forward = 0
        self.events_clamped = 0
        self.pes_headers = 0
        self.pcr_fields = 0

    def apply(self, value: int) -> int:
        """Map a raw PES timestamp onto the rebuilt monotone track."""
        if self.offset is None:
            self.offset = -value
        out = value + self.offset
        if out < 0:
            self.offset += CONTINUATION_STEP_TICKS - out
            self.events_clamped += 1
            out = value + self.offset
        if self.last_out is None:
            self.first_out = out
        elif out < self.last_out - BACKWARD_TOLERANCE_TICKS:
            self.offset += (self.last_out + CONTINUATION_STEP_TICKS) - out
            self.events_backward += 1
            out = value + self.offset
        elif out > self.last_out + FORWARD_TOLERANCE_TICKS:
            self.offset += (self.last_out + CONTINUATION_STEP_TICKS) - out
            self.events_forward += 1
            out = value + self.offset
        if self.last_out is None or out > self.last_out:
            self.last_out = out
        return out


def repair_timeline(
    src_path: str,
    dst_path: str,
    monitor=None,
    progress_cb: Callable[[int, int], None] | None = None,
) -> RepairReport:
    """Rebuild a monotone timeline from ``src_path`` into ``dst_path``.

    The whole source is copied to ``dst_path`` (same length, byte for byte)
    except the PES PTS/DTS and PCR fields, which are rewritten onto a
    monotone track starting near zero. Bytes before the first valid TS sync
    (the panel streams start mid-packet) are dropped. ``monitor`` is polled
    between chunks (Kodi abort); ``progress_cb`` receives
    ``(bytes_done, total_bytes)`` after each chunk. On any failure the
    destination is removed and the exception is re-raised with the source
    untouched.
    """
    try:
        size = os.path.getsize(src_path)
    except OSError as exc:
        raise TimelineError(f"cannot read {src_path}: {exc}") from exc

    state = _RepairState()
    carry = b""
    started = False
    out_start = 0
    bytes_out = 0
    read_done = 0
    try:
        with open(src_path, "rb") as fsrc, open(dst_path, "wb") as fdst:
            while True:
                if monitor is not None and monitor.abortRequested():
                    raise DownloadCancelledError(dst_path)
                data = fsrc.read(COPY_CHUNK_BYTES)
                if not data:
                    break
                read_done += len(data)

                buf = bytearray(carry + data)
                n = len(buf)
                i = 0
                if not started:
                    i = _find_sync(buf, 0, n)
                    if i == -1:
                        keep = min(_CARRY_LIMIT, n)
                        carry = bytes(buf[n - keep :])
                        if progress_cb is not None:
                            progress_cb(read_done, size)
                        continue
                    started = True
                    out_start = i

                while i + TS_PACKET_SIZE <= n:
                    if buf[i] != TS_SYNC_BYTE:
                        j = _find_sync(buf, i + 1, n)
                        if j == -1:
                            i = max(i, n - _CARRY_LIMIT)
                            break
                        i = j
                        continue

                    byte1 = buf[i + 1]
                    afc = (buf[i + 3] >> 4) & 0x3
                    pes_start = -1
                    if afc & 2:
                        af_len = buf[i + 4]
                        pes_start = i + 5 + af_len
                        if af_len >= 1 and (buf[i + 5] & 0x10):
                            off = i + 6
                            value27 = _decode_pcr(buf[off : off + 6])
                            if state.offset is None:
                                state.offset = -(value27 // PCR_TICKS_PER_TICK)
                            new27 = value27 + state.offset * PCR_TICKS_PER_TICK
                            if new27 < 0:
                                new27 = 0
                            if new27 != value27:
                                buf[off : off + 6] = _encode_pcr(new27)
                                state.pcr_fields += 1
                    if (byte1 & 0x40) and afc != 2:
                        po = pes_start if afc & 2 else i + 4
                        fields = _pes_timestamp_fields(buf, po, i + TS_PACKET_SIZE)
                        if fields is not None:
                            pts_off, dts_off = fields
                            pts = _decode_timestamp(buf[pts_off : pts_off + 5])
                            primary = (
                                _decode_timestamp(buf[dts_off : dts_off + 5]) if dts_off != -1 else pts
                            )
                            state.apply(primary)
                            new_pts = state.offset + pts
                            buf[pts_off : pts_off + 5] = _encode_timestamp(new_pts, buf[pts_off] & 0xF0)
                            if dts_off != -1:
                                buf[dts_off : dts_off + 5] = _encode_timestamp(
                                    state.offset + primary, buf[dts_off] & 0xF0
                                )
                            state.pes_headers += 1
                    i += TS_PACKET_SIZE

                fdst.write(buf[out_start:i])
                bytes_out += i - out_start
                out_start = 0
                carry = bytes(buf[i:])
                if progress_cb is not None:
                    progress_cb(read_done, size)

            if started:
                if carry:
                    fdst.write(carry)
                    bytes_out += len(carry)
            else:
                raise TimelineError(f"not an MPEG-TS stream: {src_path}")
    except BaseException:
        with contextlib.suppress(OSError):
            os.remove(dst_path)
        raise

    if state.first_out is None or state.last_out is None:
        with contextlib.suppress(OSError):
            os.remove(dst_path)
        raise TimelineError(f"no PES timestamps found in {src_path}")

    return RepairReport(
        events_backward=state.events_backward,
        events_forward=state.events_forward,
        events_clamped=state.events_clamped,
        pes_headers=state.pes_headers,
        pcr_fields=state.pcr_fields,
        first_dts=state.first_out,
        last_dts=state.last_out,
        bytes_in=size,
        bytes_out=bytes_out,
    )
