"""Media download helpers (long HTTP transfers to the box storage).

Kept separate from ``tv_common.utils.request``: the network backoff there is
reserved for provider API calls, while a media transfer is one long stream.
Callers pass the provider's own session, so the browser user agent and the
redirect handling are exactly those validated in real playback.
"""

import contextlib
import os
import re
import time
from typing import Callable, Dict, Optional

import xbmc

from tv_common.exceptions import DownloadCancelledError, DownloadInProgressError
from tv_common.utils.kodi import log

DEFAULT_CHUNK_SIZE = 256 * 1024
DEFAULT_READ_TIMEOUT = 30
MAX_FILENAME_LEN = 180

_FORBIDDEN_FILENAME_CHARS_RE = re.compile(r'[\\/:*?"<>|\x00-\x1f\x7f]')

_MEDIA_PATH_RE = re.compile(r"(/(?:movie|series|live|timeshift)/)[^/]+/[^/]+/")
_USERINFO_RE = re.compile(r"//[^/@:\s]+(?::[^/@\s]*)?@")
_QUERY_SECRET_RE = re.compile(r"(?i)([?&](?:username|password|user|pass|token)=)[^&\s]+")


def mask_url(url: str, *secrets: str) -> str:
    """Return a URL safe for logs: credentials are replaced by ``[REDACTED]``.

    Redacts the provided secrets, the ``user:pass@`` userinfo part, the
    Xtream ``/<type>/<user>/<pass>/`` path credentials (movie, series, live,
    timeshift) and credential query parameters. Callers pass the provider
    username/password when they know them; the generic patterns cover the
    rest.
    """
    if not url:
        return ""

    masked = str(url)
    for secret in secrets:
        if secret:
            masked = masked.replace(str(secret), "[REDACTED]")
    masked = _USERINFO_RE.sub("//[REDACTED]@", masked)
    masked = _MEDIA_PATH_RE.sub(r"\1[REDACTED]/[REDACTED]/", masked)
    return _QUERY_SECRET_RE.sub(r"\1[REDACTED]", masked)


def download_to_file(
    session,
    url: str,
    dest_path: str,
    headers: Optional[Dict[str, str]] = None,
    progress_cb: Optional[Callable[[int, Optional[int]], None]] = None,
    monitor=None,
    chunk_size: int = DEFAULT_CHUNK_SIZE,
    read_timeout: int = DEFAULT_READ_TIMEOUT,
) -> str:
    """Download an HTTP media stream to ``dest_path``, atomically.

    Writes ``<dest_path>.part`` (created with ``O_EXCL``, so a leftover file
    means a download is running or was interrupted) then renames it into
    place with ``os.replace``. The transfer goes through the provided session
    (browser user agent and redirect handling inherited from the caller) and
    never through the API backoff.

    ``progress_cb`` receives ``(downloaded_bytes, total_bytes)``; ``total`` is
    ``None`` when the server sends no ``Content-Length``. When ``monitor``
    reports an abort the transfer stops and the partial file is removed.

    Return the final path. Raise ``DownloadInProgressError`` when the partial
    file already exists, ``DownloadCancelledError`` on abort; stream errors
    propagate as-is.
    """
    part_path = f"{dest_path}.part"
    directory = os.path.dirname(dest_path)
    if directory:
        os.makedirs(directory, exist_ok=True)

    try:
        part_fd = os.open(part_path, os.O_CREAT | os.O_EXCL | os.O_WRONLY, 0o644)
    except FileExistsError as exc:
        raise DownloadInProgressError(part_path) from exc

    log(f"download start: {mask_url(url)} -> {dest_path}", xbmc.LOGDEBUG)
    response = None
    downloaded = 0
    try:
        with os.fdopen(part_fd, "wb") as part_file:
            response = session.get(url, headers=headers, stream=True, timeout=read_timeout)
            response.raise_for_status()

            total = None
            raw_total = response.headers.get("Content-Length")
            if raw_total is not None:
                with contextlib.suppress(TypeError, ValueError):
                    total = int(raw_total)

            for chunk in response.iter_content(chunk_size=chunk_size):
                if monitor is not None and monitor.abortRequested():
                    raise DownloadCancelledError(part_path)
                if not chunk:
                    continue
                part_file.write(chunk)
                downloaded += len(chunk)
                if progress_cb is not None:
                    progress_cb(downloaded, total)
    except BaseException:
        with contextlib.suppress(OSError):
            os.remove(part_path)
        raise
    finally:
        if response is not None:
            with contextlib.suppress(Exception):
                response.close()

    os.replace(part_path, dest_path)
    log(f"download complete: {downloaded} bytes -> {dest_path}", xbmc.LOGDEBUG)
    return dest_path


def sanitize_filename_part(text) -> str:
    """Return a filesystem-safe filename part.

    Path separators, reserved characters and control characters are replaced
    by spaces; runs of whitespace collapse to one space. Return an empty
    string when nothing printable is left.
    """
    if text is None:
        return ""
    cleaned = _FORBIDDEN_FILENAME_CHARS_RE.sub(" ", str(text))
    return " ".join(cleaned.split())


def _season_episode_marker(season, episode) -> str:
    """Return the ``SxxEyy`` segment (partial markers allowed), or ''."""
    marker = ""
    with contextlib.suppress(TypeError, ValueError):
        if season is not None:
            marker += f"S{int(season):02d}"
    with contextlib.suppress(TypeError, ValueError):
        if episode is not None:
            marker += f"E{int(episode):02d}"
    return marker


def build_download_filename(title, channel_name, start_epoch, season=None, episode=None, extension: str = "ts") -> str:
    """Build ``<Title> - [SxxEyy - ]<Channel> - <YYYY-MM-DD HH-MM>.<ext>``.

    The date is the programme start in box-local time (the time the guide
    displays). The season/episode segment is only added when available; the
    name is sanitized and bounded to stay well under filesystem limits.
    """
    stamp = time.strftime("%Y-%m-%d %H-%M", time.localtime(int(start_epoch)))
    parts = [sanitize_filename_part(title) or "Replay"]
    marker = _season_episode_marker(season, episode)
    if marker:
        parts.append(marker)
    channel = sanitize_filename_part(channel_name)
    if channel:
        parts.append(channel)

    head = " - ".join(parts)
    tail = f" - {stamp}.{extension}"
    if len(head) + len(tail) > MAX_FILENAME_LEN:
        head = head[: max(0, MAX_FILENAME_LEN - len(tail))].rstrip(" -")
    return f"{head}{tail}"
