"""TV guide context-item helpers (selected EPG entry parsing).

Pure helpers for providers that add actions to the TV guide's context menu
(``kodi.context.item``): they turn the raw data of the selected EPG entry —
the ``sys.listitem`` handed to the script — into plain Python values, without
any UI or network side effect.
"""

import calendar
import re
import time
from typing import Callable, Dict, Optional, Tuple

_PVR_GUIDE_PATH_RE = re.compile(r"^pvr://guide/(\d+)/(\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2})\.epg$")


def parse_pvr_guide_path(path: Optional[str]) -> Optional[Tuple[str, int]]:
    """Parse a ``pvr://guide/<id>/<YYYY-MM-DD HH:MM:SS>.epg`` path.

    The timestamp is the programme start in **UTC** (same base as IPTV Simple's
    ``{utc}`` catch-up substitution, verified against a real replay log).

    Return ``(pvr_channel_id, start_epoch)``, or ``None`` when the path does
    not follow the guide format.
    """
    if not path or not isinstance(path, str):
        return None

    match = _PVR_GUIDE_PATH_RE.match(path.strip())
    if not match:
        return None

    try:
        start_epoch = calendar.timegm(time.strptime(match.group(2), "%Y-%m-%d %H:%M:%S"))
    except ValueError:
        return None
    return match.group(1), start_epoch


def parse_duration_to_minutes(text: Optional[str]) -> Optional[int]:
    """Convert a Kodi duration label (``MM:SS`` or ``H:MM:SS``) to minutes.

    Minutes are truncated (integer division), matching IPTV Simple's
    ``{duration:60}`` catch-up substitution so a downloaded window is the
    exact programme length.

    Return ``None`` when the text is empty or malformed.
    """
    if not text or not isinstance(text, str):
        return None

    parts = text.strip().split(":")
    if len(parts) not in (2, 3) or not all(part.strip().isdigit() for part in parts):
        return None

    seconds = int(parts[-1])
    minutes = int(parts[-2])
    hours = int(parts[0]) if len(parts) == 3 else 0
    return (hours * 3600 + minutes * 60 + seconds) // 60


def _clean(value) -> Optional[str]:
    """Return a stripped string from a possibly-missing value (``None`` when empty)."""
    if value is None:
        return None
    text = str(value).strip()
    return text or None


def _as_int(text: Optional[str]) -> Optional[int]:
    """Convert a numeric infolabel value to int (``None`` when not numeric)."""
    if not text:
        return None
    try:
        return int(str(text).strip())
    except (TypeError, ValueError):
        return None


def guide_item_from_listitem(listitem, infolabel: Optional[Callable] = None) -> Dict[str, Optional[object]]:
    """Extract the useful fields of the selected TV-guide listitem.

    Reads the listitem itself (label, path) and infolabels (channel name,
    duration, plot, season/episode). ``infolabel`` defaults to
    ``xbmc.getInfoLabel`` and stays injectable for tests; every getter is
    wrapped so one broken field cannot kill the caller (Kodi 22 pitfall).

    Missing or unusable fields come back as ``None``.
    """
    if infolabel is None:
        import xbmc

        infolabel = xbmc.getInfoLabel

    def _label(name: str) -> Optional[str]:
        try:
            return _clean(infolabel(name))
        except Exception:
            return None

    def _attr(getter: Callable) -> Optional[str]:
        try:
            return _clean(getter())
        except Exception:
            return None

    title = _attr(listitem.getLabel) or _label("ListItem.Title")
    parsed_path = parse_pvr_guide_path(_attr(listitem.getPath))

    return {
        "title": title,
        "channel_name": _label("ListItem.ChannelName"),
        "plot": _label("ListItem.Plot"),
        "start_epoch": parsed_path[1] if parsed_path else None,
        "pvr_channel_id": parsed_path[0] if parsed_path else None,
        "duration_min": parse_duration_to_minutes(_label("ListItem.Duration")),
        "season": _as_int(_label("ListItem.Season")),
        "episode": _as_int(_label("ListItem.Episode")),
    }
