"""TV Common exceptions."""


class StreamRequestException(IOError):
    """There was an exception while handling stream request."""

    def __init__(self, *args, **kwargs):
        """Initialise StreamRequestException."""
        super().__init__(*args, **kwargs)


class AuthenticationRequired(StreamRequestException):
    """Authentication is required in order to request stream."""


class StreamNotIncluded(StreamRequestException):
    """Requested stream is not included in subscription."""


class StreamDataDecodeError(StreamRequestException):
    """Stream data can't be read."""


class DownloadError(IOError):
    """There was an error while handling a media download."""


class DownloadInProgressError(DownloadError):
    """A download already runs for this target (or a partial file was left behind)."""


class DownloadCancelledError(DownloadError):
    """The download was interrupted (Kodi shutting down or user abort)."""