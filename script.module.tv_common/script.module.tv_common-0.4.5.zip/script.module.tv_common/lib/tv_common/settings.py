"""Unified settings and localization manager for tv-addons.

Provides standard definitions for common categories (Integration, Appearance, Playback),
maintains localized translation strings (FR and EN), and generates synchronized
resources/settings.xml and resources/language/*/strings.po files across all addons.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path

# ---------------------------------------------------------------------------
# Common Translations (Single Source of Truth)
# ---------------------------------------------------------------------------

STRINGS_COMMON: dict[int, dict[str, str]] = {
    # Integration (30100-30199)
    30100: {"fr": "Intégration", "en": "Integration"},
    30101: {"fr": "Installer le gestionnaire TV…", "en": "Install TV Manager…"},
    30102: {
        "fr": "IPTV Manager est requis pour la TV en direct dans Kodi",
        "en": "IPTV Manager is required for live TV in Kodi",
    },
    30103: {"fr": "Activer la TV en direct dans Kodi", "en": "Enable Kodi live TV"},
    30104: {
        "fr": "Activer cette option pour accéder à vos chaînes en direct depuis Kodi",
        "en": "Enable this option to access your live channels from Kodi",
    },
    30105: {"fr": "Paramètres du gestionnaire TV…", "en": "TV Manager settings…"},
    30106: {
        "fr": "Ouvrir les paramètres d'IPTV Manager",
        "en": "Open IPTV Manager settings",
    },
    30110: {
        "fr": "Synchroniser les sources dans Kodi Vidéos",
        "en": "Synchronize sources in Kodi Videos",
    },
    30111: {
        "fr": "Ajoute ou met à jour les sources vidéo dans la section Vidéos de Kodi",
        "en": "Add or update video sources in Kodi Videos section",
    },
    # Appearance (30400-30499)
    30400: {"fr": "Apparence", "en": "Appearance"},
    30401: {"fr": "Style d'icône", "en": "Icon style"},
    30402: {
        "fr": "Sélectionner le style d'icône de l'addon (Officiel ou 3D Moderne)",
        "en": "Select addon icon style (Official or Modern 3D)",
    },
    30403: {"fr": "Officiel", "en": "Official"},
    30404: {"fr": "3D Moderne", "en": "Modern 3D"},
    30410: {"fr": "Mode des sources vidéo", "en": "Video sources mode"},
    30411: {
        "fr": "Type de sources à intégrer dans la section Vidéos de Kodi",
        "en": "Type of sources to integrate into Kodi Videos section",
    },
    30412: {"fr": "Navigation (Dossiers)", "en": "Navigation (Folders)"},
    30413: {"fr": "Médiathèque (Scraper)", "en": "Library (Scraper)"},
    30414: {"fr": "Les deux (Développeur)", "en": "Both (Developer)"},
    30415: {"fr": "Désactivé", "en": "Disabled"},
    # Playback / DRM (30500-30599)
    30500: {"fr": "Lecture", "en": "Playback"},
    30501: {"fr": "Profil de périphérique", "en": "Device profile"},
    30502: {
        "fr": "Profil API et DRM Widevine : Auto pour détection auto, Android pour Android TV, Web pour PC",
        "en": "API and Widevine DRM profile: Auto detects platform, Android for Android TV, Web for browser/PC",
    },
    30503: {"fr": "Auto (Recommandé)", "en": "Auto (Recommended)"},
    30504: {"fr": "Android (Android TV)", "en": "Android (Android TV)"},
    30505: {"fr": "Web (Navigateur / FHD)", "en": "Web (Browser / FHD)"},
}


# ---------------------------------------------------------------------------
# Addon Specific Settings & Strings Declarations
# ---------------------------------------------------------------------------

@dataclass
class AddonSettingsSpec:
    """Specification of settings and translations for an addon."""

    addon_id: str
    addon_name: str
    specific_categories_xml: list[str] = field(default_factory=list)
    specific_strings: dict[int, dict[str, str]] = field(default_factory=dict)


ADDON_SPECS: dict[str, AddonSettingsSpec] = {
    # 1. Orange TV
    "plugin.video.orange.tv": AddonSettingsSpec(
        addon_id="plugin.video.orange.tv",
        addon_name="Orange TV France",

        specific_categories_xml=[
            """  <!-- Provider -->
  <category label="30200">
    <setting id="provider.country" label="30201" help="30202" type="select" values="France" default="France"/>
    <setting id="provider.name" visible="eq(-1,France)" label="30203" help="30204"
             type="labelenum" values="Orange|Orange Caraïbe|Orange Réunion" default="Orange"/>
    <setting type="lsep"/>
    <setting id="provider.session_data" visible="false" default="{}"/>
    <setting id="provider.show_not_included" label="30903" help="30904" type="bool" default="false"/>
    <setting id="provider.use_credentials" label="30205" help="30206" type="bool" default="false"/>
    <setting id="provider.username" label="30207" help="30208" enable="eq(-1,true)" type="text" default=""/>
    <setting id="provider.password" label="30209" help="30210" enable="eq(-2,true)"
             type="text" default="" option="hidden"/>
  </category>""",
            """  <!-- Proxy -->
  <category label="30300">
    <setting id="proxy.enabled" label="30301" help="30302" type="bool" default="false"/>
    <setting id="proxy.protocol" label="30303" help="30304" enable="eq(-1,true)"
             type="labelenum" values="HTTP|Socks5 Local DNS|Socks5 Remote DNS" default="HTTP"/>
    <setting id="proxy.ip" label="30305" help="30306" enable="eq(-2,true)" type="text" default=""/>
    <setting id="proxy.port" label="30307" help="30308" enable="eq(-3,true)" type="text" default=""/>
  </category>""",

        ],
        specific_strings={
            # Provider
            30200: {"fr": "Fournisseur", "en": "Provider"},
            30201: {"fr": "Pays", "en": "Country"},
            30202: {
                "fr": "Sélectionner le pays de votre fournisseur d'accès à internet",
                "en": "Select ISP country",
            },
            30203: {"fr": "Fournisseur d'accès", "en": "Internet service provider"},
            30204: {
                "fr": "Sélectionner votre fournisseur d'accès à internet",
                "en": "Select your internet service provider",
            },
            30205: {"fr": "Utiliser des identifiants", "en": "Use credentials"},
            30206: {
                "fr": "Permet de renseigner manuellement vos identifiants",
                "en": "Allows entering your credentials",
            },
            30207: {"fr": "Identifiant", "en": "Username"},
            30208: {"fr": "Votre identifiant Orange", "en": "Your Orange username"},
            30209: {"fr": "Mot de passe", "en": "Password"},
            30210: {"fr": "Votre mot de passe Orange", "en": "Your Orange password"},
            # Proxy
            30300: {"fr": "Proxy", "en": "Proxy"},
            30301: {"fr": "Activer le proxy", "en": "Enable proxy"},
            30302: {
                "fr": "Permet de passer par un proxy réseau",
                "en": "Route traffic through a network proxy",
            },
            30303: {"fr": "Protocole", "en": "Protocol"},
            30304: {"fr": "Protocole de proxy à utiliser", "en": "Proxy protocol to use"},
            30305: {"fr": "Adresse IP", "en": "IP address"},
            30306: {"fr": "Adresse IP du serveur proxy", "en": "Proxy server IP address"},
            30307: {"fr": "Port", "en": "Port"},
            30308: {"fr": "Numéro de port du serveur proxy", "en": "Proxy server port"},
            # Dialogs
            30900: {
                "fr": "Cette chaîne ne fait pas partie de votre abonnement.",
                "en": "This channel is not included of your current subscription.",
            },
            30901: {
                "fr": "InputStream n'a pas pu être chargé.",
                "en": "InputStream cannot be loaded.",
            },
            30902: {
                "fr": "Authentification impossible avec votre fournisseur.",
                "en": "Cannot authenticate with your provider.",
            },
            30903: {
                "fr": "Afficher les chaînes non incluses dans l'abonnement",
                "en": "Show channels not included in subscription",
            },
            30904: {
                "fr": "Si désactivé, les chaînes non incluses sont masquées de la playlist.",
                "en": "When disabled, channels not included are hidden from playlist.",
            },
        },
    ),
    # 2. Xtream Codes
    "plugin.video.xtream": AddonSettingsSpec(
        addon_id="plugin.video.xtream",
        addon_name="Xtream TV",
        specific_categories_xml=[
            """  <!-- Provider -->
  <category label="30200">
    <setting id="xtream.name" label="30201" help="30202" type="text" default="TVA"/>
    <setting id="xtream.ip" label="30203" help="30204" type="text" default=""/>
    <setting type="lsep"/>
    <setting id="xtream.username" label="30205" help="30206" type="text" default=""/>
    <setting id="xtream.password" label="30207" help="30208" type="text" default="" option="hidden"/>
    <setting type="lsep"/>
    <setting id="xtream.excluded_groups" label="30210" help="30211" type="text" default=""/>
    <setting visible="true" label="30212" help="30213" type="action"
             action="RunPlugin(plugin://plugin.video.xtream/groups/manage)" option="close"/>
    <setting type="lsep"/>
    <setting label="30220" help="30221" type="action"
             action="RunPlugin(plugin://plugin.video.xtream/clear_cache)" option="close"/>
  </category>""",
        ],
        specific_strings={
            30200: {"fr": "Fournisseur", "en": "Provider"},
            30201: {"fr": "Nom du fournisseur", "en": "Provider name"},
            30202: {
                "fr": "Nom utilisé pour identifier ce fournisseur",
                "en": "Name used to identify this provider",
            },
            30203: {"fr": "URL du serveur", "en": "Server URL"},
            30204: {
                "fr": "URL du serveur Xtream, ex. http://provider.example.com",
                "en": "Xtream server URL, e.g. http://provider.example.com",
            },
            30205: {"fr": "Identifiant", "en": "Username"},
            30206: {"fr": "Identifiant du compte Xtream", "en": "Xtream account username"},
            30207: {"fr": "Mot de passe", "en": "Password"},
            30208: {"fr": "Mot de passe du compte Xtream", "en": "Xtream account password"},
            30210: {
                "fr": "Groupes exclus (séparés par ;)",
                "en": "Excluded groups (separated by ;)",
            },
            30211: {
                "fr": "Liste des groupes de chaînes à exclure de la playlist, séparés par ;.",
                "en": "List of channel groups to exclude from playlist, separated by ;.",
            },
            30212: {
                "fr": "Gérer les groupes (exclure des chaînes)",
                "en": "Manage groups (exclude channels)",
            },
            30213: {
                "fr": "Ouvre le dialogue de sélection des groupes à exclure de la playlist.",
                "en": "Opens group selection dialog to exclude from playlist.",
            },
            30220: {"fr": "Vider le cache", "en": "Clear cache"},
            30221: {
                "fr": "Supprime les données du fournisseur mises en cache (elles seront re-téléchargées au besoin)",
                "en": "Delete cached provider data (it will be re-downloaded when needed)",
            },
        },
    ),
    # 3. Rakuten TV
    "plugin.video.rakuten.tv": AddonSettingsSpec(
        addon_id="plugin.video.rakuten.tv",
        addon_name="Rakuten TV Free",
        specific_categories_xml=[
            """  <!-- Playback / DRM -->
  <category label="30500">
    <setting id="playback.device_profile" type="enum" label="30501" help="30502"
             lvalues="30503|30504|30505" default="0"/>
  </category>""",
        ],
        specific_strings={},  # 30500..30505 are already in STRINGS_COMMON
    ),
    # 4. Pluto TV
    "plugin.video.pluto.tv": AddonSettingsSpec(
        addon_id="plugin.video.pluto.tv",
        addon_name="Pluto TV",
        specific_categories_xml=[],
        specific_strings={},
    ),
    # 5. Samsung TV Plus
    "plugin.video.samsung.tvplus": AddonSettingsSpec(
        addon_id="plugin.video.samsung.tvplus",
        addon_name="Samsung TV Plus",
        specific_categories_xml=[
            """  <!-- Provider -->
  <category label="30200">
    <setting id="samsung.region" label="30201" help="30202" type="text" default="fr"/>
  </category>""",
        ],

        specific_strings={
            30200: {"fr": "Fournisseur", "en": "Provider"},
            30201: {"fr": "Région", "en": "Region"},
            30202: {
                "fr": "Code région Samsung TV Plus (fr, us, gb, ...)",
                "en": "Samsung TV Plus region code (fr, us, gb, ...)",
            },
        },
    ),
}


# ---------------------------------------------------------------------------
# XML Generators
# ---------------------------------------------------------------------------

def generate_integration_category(addon_id: str) -> str:
    """Generate the standard Integration category XML."""
    c_uri = f'plugin://{addon_id}/iptv/channels'
    e_uri = f'plugin://{addon_id}/iptv/epg'
    sync_action = f'RunPlugin(plugin://{addon_id}/library/sources/sync)'

    lines = [
        '  <!-- Integration -->',
        '  <category label="30100">',
        f'    <setting id="iptv.channels_uri" type="text" default="{c_uri}" visible="false"/>',
        f'    <setting id="iptv.epg_uri" type="text" default="{e_uri}" visible="false"/>',
        (
            '    <setting visible="!System.HasAddon(service.iptv.manager)" label="30101" help="30102" '
            'type="action" action="InstallAddon(service.iptv.manager)" option="close"/>'
        ),
        (
            '    <setting id="iptv.enabled" visible="System.HasAddon(service.iptv.manager)" label="30103" help="30104" '
            'type="bool" default="true"/>'
        ),
        (
            '    <setting visible="System.HasAddon(service.iptv.manager)" label="30105" help="30106" '
            'type="action" action="Addon.OpenSettings(service.iptv.manager)" option="close" subsetting="true"/>'
        ),
        '    <setting type="lsep"/>',
        f'    <setting label="30110" help="30111" type="action" action="{sync_action}" option="close"/>',
        '  </category>',
    ]
    return '\n'.join(lines)


def generate_appearance_category() -> str:
    """Generate the standard Appearance category XML with unified sources.mode."""
    lines = [
        '  <!-- Appearance -->',
        '  <category label="30400">',
        (
            '    <setting id="appearance.icon_style" type="enum" label="30401" help="30402" '
            'lvalues="30403|30404" default="0"/>'
        ),
        (
            '    <setting id="sources.mode" type="enum" label="30410" help="30411" '
            'lvalues="30412|30413|30414|30415" default="3"/>'
        ),
        '  </category>',
    ]
    return '\n'.join(lines)


def generate_settings_xml(addon_id: str) -> str:
    """Generate the full resources/settings.xml content for an addon."""
    spec = ADDON_SPECS[addon_id]
    categories = [
        generate_integration_category(addon_id),
    ]
    categories.extend(spec.specific_categories_xml)
    categories.append(generate_appearance_category())

    parts = [
        '<?xml version="1.0" encoding="utf-8" standalone="yes"?>',
        '<settings>',
    ]
    parts.extend(categories)
    parts.append('</settings>\n')
    return '\n\n'.join(parts[:-1]) + '\n' + parts[-1]


# ---------------------------------------------------------------------------
# Strings PO Generator
# ---------------------------------------------------------------------------

def generate_strings_po(addon_id: str, lang: str = "fr") -> str:
    """Generate the full resources/language/*/strings.po content for an addon."""
    spec = ADDON_SPECS[addon_id]
    lang_code = "fr" if lang.startswith("fr") else "en"
    plural = "nplurals=2; plural=(n != 1);"

    header = (
        '# Kodi Media Center language file\n'
        f'# Addon Name: {spec.addon_name}\n'
        f'# Addon id: {addon_id}\n'
        'msgid ""\n'
        'msgstr ""\n'
        '"MIME-Version: 1.0\\n"\n'
        '"Content-Type: text/plain; charset=UTF-8\\n"\n'
        '"Content-Transfer-Encoding: 8bit\\n"\n'
        f'"Language: {lang_code}\\n"\n'
        f'"Plural-Forms: {plural}\\n"\n'
    )

    # Collect all needed string IDs
    needed_ids = set()

    # Integration strings
    needed_ids.update([30100, 30101, 30102, 30103, 30104, 30105, 30106, 30110, 30111])

    # Appearance strings (including all 4 sources.mode options)
    needed_ids.update([30400, 30401, 30402, 30403, 30404, 30410, 30411, 30412, 30413, 30414, 30415])

    # Add specific strings
    needed_ids.update(spec.specific_strings.keys())

    # Add playback strings if Rakuten
    if addon_id == "plugin.video.rakuten.tv":
        needed_ids.update([30500, 30501, 30502, 30503, 30504, 30505])


    entries = []
    for str_id in sorted(needed_ids):
        entry_data = STRINGS_COMMON.get(str_id) or spec.specific_strings.get(str_id)
        if not entry_data:
            continue
        msgid = entry_data.get("en", "")
        msgstr = entry_data.get(lang_code, msgid)
        entries.append(
            f'msgctxt "#{str_id}"\n'
            f'msgid "{msgid}"\n'
            f'msgstr "{msgstr}"\n'
        )

    return header + '\n' + '\n'.join(entries)


# ---------------------------------------------------------------------------
# Sync / Apply to Repository
# ---------------------------------------------------------------------------

def sync_all_addon_settings(repo_root: Path | None = None) -> list[Path]:
    """Generate and write settings.xml and strings.po for all 5 addons."""
    if repo_root is None:
        # Defaults to repo root based on this file location
        repo_root = Path(__file__).resolve().parents[3]

    modified_files: list[Path] = []
    for addon_id in ADDON_SPECS:
        addon_dir = repo_root / addon_id
        if not addon_dir.is_dir():
            continue

        # 1. settings.xml
        settings_xml_path = addon_dir / "resources" / "settings.xml"
        settings_xml_path.parent.mkdir(parents=True, exist_ok=True)
        xml_content = generate_settings_xml(addon_id)
        settings_xml_path.write_text(xml_content, encoding="utf-8")
        modified_files.append(settings_xml_path)

        # 2. strings.po (fr_fr)
        fr_po_path = addon_dir / "resources" / "language" / "resource.language.fr_fr" / "strings.po"
        fr_po_path.parent.mkdir(parents=True, exist_ok=True)
        fr_content = generate_strings_po(addon_id, "fr")
        fr_po_path.write_text(fr_content, encoding="utf-8")
        modified_files.append(fr_po_path)

        # 3. strings.po (en_gb)
        en_po_path = addon_dir / "resources" / "language" / "resource.language.en_gb" / "strings.po"
        en_po_path.parent.mkdir(parents=True, exist_ok=True)
        en_content = generate_strings_po(addon_id, "en")
        en_po_path.write_text(en_content, encoding="utf-8")
        modified_files.append(en_po_path)

    return modified_files


if __name__ == "__main__":
    files = sync_all_addon_settings()
    print(f"✔ Synchronized settings and strings across {len(files)} files.")
