"""Cache utils."""

import datetime
import functools
import json
import os
import time
from typing import Any, Callable, Optional

import xbmc
import xbmcvfs

from tv_common.utils.kodi import get_addon_info, log

# Per-item cache entries (vod_info, series_info, stream epg, ...) are never
# refreshed once written; purge them after this age to keep the cache folder
# from growing unbounded (one file per movie/series/channel).
_CACHE_MAX_AGE_SEC = 7 * 24 * 60 * 60
_CACHE_MAX_SIZE_BYTES = 250 * 1024 * 1024


def _cache_folder(subfolder: str = "") -> str:
    """Return (and create) the addon cache folder, optionally under a subfolder."""
    cache_folder = os.path.join(xbmcvfs.translatePath(get_addon_info("profile")), "cache", subfolder)

    if not os.path.exists(cache_folder):
        os.makedirs(cache_folder)

    return cache_folder


def cleanup_cache(max_age_sec: int = _CACHE_MAX_AGE_SEC, max_size_bytes: int = _CACHE_MAX_SIZE_BYTES) -> int:
    """Remove stale cache files and trim the cache folder to a max size.

    Files older than ``max_age_sec`` are always removed (they would be
    refreshed on next use anyway). If the folder still exceeds
    ``max_size_bytes``, oldest files are removed first (the big XMLTV EPG
    cache is the main consumer, and it gets re-fetched lazily).

    Returns the number of files removed.
    """
    cache_folder = _cache_folder()
    if not os.path.isdir(cache_folder):
        return 0

    now = time.time()
    removed = 0

    def _is_stale(fp: str) -> bool:
        try:
            return now - os.path.getmtime(fp) > max_age_sec
        except OSError:
            return False

    def _walk():
        for root, _dirs, files in os.walk(cache_folder):
            for name in files:
                yield os.path.join(root, name)

    # 1. Drop stale files.
    for fp in _walk():
        if _is_stale(fp):
            try:
                os.remove(fp)
                removed += 1
            except OSError:
                pass

    # 2. If still over budget, remove oldest files until under the limit.
    remaining = [fp for fp in _walk() if not _is_stale(fp)]
    total = sum(os.path.getsize(fp) for fp in remaining)
    for fp in sorted(remaining, key=lambda f: os.path.getmtime(f)):
        if total <= max_size_bytes:
            break
        try:
            size = os.path.getsize(fp)
            os.remove(fp)
            total -= size
            removed += 1
        except OSError:
            pass

    return removed


def _is_empty_payload(value: Any) -> bool:
    """Return True if value is empty or contains only empty wrapped data."""
    if not value:
        return True
    if isinstance(value, dict) and "version" in value:
        if "epg" in value and not value["epg"]:
            return True
        if "streams" in value and not value["streams"]:
            return True
    return False


def cached(
    file_prefix: Optional[str] = None, expire_sec: int = 60 * 60 * 5, subfolder: str = "providers"
) -> Callable[[Callable], Callable]:
    """Cache the result of a method for expire_sec seconds.

    The cache file is named from the object name, an optional prefix and the
    method positional arguments, e.g. OTT_categories_movie.json.

    - Fresh cache: served without calling the wrapped function.
    - Stale/absent cache: the function is called and the result written.
    - Call failure with an existing (even stale) cache: stale value is served.
    - Call failure with no cache: the original exception is re-raised.

    Pass expire_sec=-1 to cache forever.
    """

    def decorator(func: Callable[[Any, Any], Any]):
        @functools.wraps(func)
        def wrapper(self: Any, *args: Any, **kwargs: Any) -> Any:
            cache_folder = _cache_folder(subfolder)
            name = getattr(self, "name", None) or getattr(getattr(self, "xt", None), "name", "cache")
            path_elements = [name] + ([file_prefix] if file_prefix else [])
            filepath = "_".join(path_elements + list(map(str, args))) + ".json"
            fp = os.path.join(cache_folder, filepath)

            try:
                with open(fp, encoding="utf-8") as file:
                    cached = json.loads("".join(file.readlines()))
                    oldness = datetime.datetime.now() - datetime.datetime.fromtimestamp(os.path.getmtime(fp))
                    if expire_sec == -1 or oldness < datetime.timedelta(seconds=expire_sec):
                        # An empty cached value is almost certainly a poisoned cache
                        # (server was down when it was written). Treat it as stale so
                        # we re-fetch instead of serving an empty list to the user.
                        if _is_empty_payload(cached):
                            raise TimeoutError(f"{filepath} cache is empty, treating as stale")
                        log(f"USING CACHE FILE: {filepath}", xbmc.LOGDEBUG)
                        return cached
                    raise TimeoutError(f"{filepath} file is too old")
            except Exception as e:
                log(f"{e}", xbmc.LOGWARNING)

            try:
                result = func(self, *args, **kwargs)
            except Exception as e:
                # Serve a stale cache if we have one, otherwise re-raise.
                log("Can't load data: using cache instead", xbmc.LOGWARNING)
                try:
                    with open(fp, encoding="utf-8") as file:
                        return json.loads("".join(file.readlines()))
                except (OSError, ValueError):
                    raise e from None

            # Guard: don't overwrite a good cache with an empty result (server
            # hiccup, rate-limit, maintenance). Serve the stale cache instead.
            if _is_empty_payload(result) and os.path.exists(fp):
                log("Empty result from server, keeping stale cache", xbmc.LOGWARNING)
                try:
                    with open(fp, encoding="utf-8") as file:
                        return json.loads("".join(file.readlines()))
                except (OSError, ValueError):
                    pass  # cache corrupt — fall through to write the empty result

            try:
                with open(fp, "wb") as file:
                    file.write(json.dumps(result).encode("utf-8"))
            except Exception as e:
                log(f"error: {e}", xbmc.LOGERROR)

            return result

        return wrapper

    return decorator


def use_cache(filepath: str) -> Callable[[Callable], Callable]:
    """Backward-compatible alias: cache under the root cache folder, no expiry.

    Kept for callers that relied on the old write-through/fallback semantics
    (e.g. IPTVManager socket payloads).
    """

    def decorator(func: Callable[[Any, Any], Any]):
        @functools.wraps(func)
        def wrapper(*args: Any, **kwargs: Any) -> Any:
            cache_folder = _cache_folder()
            full_path = os.path.join(cache_folder, filepath)

            try:
                result = func(*args, **kwargs)
            except Exception as e:
                log("Can't load data: using cache instead", xbmc.LOGWARNING)
                try:
                    with open(full_path, encoding="utf-8") as file:
                        return json.loads("".join(file.readlines()))
                except (OSError, ValueError):
                    raise e from None

            # Guard: don't overwrite a good cache with an empty result.
            if _is_empty_payload(result) and os.path.exists(full_path):
                log("Empty result from server, keeping stale cache", xbmc.LOGWARNING)
                try:
                    with open(full_path, encoding="utf-8") as file:
                        return json.loads("".join(file.readlines()))
                except (OSError, ValueError):
                    pass

            try:
                with open(full_path, "wb") as file:
                    file.write(json.dumps(result).encode("utf-8"))
            except Exception as e:
                log(f"error: {e}", xbmc.LOGERROR)

            return result

        return wrapper

    return decorator


def use_router_cache(
    file_prefix: Optional[str] = None, expire_sec: int = 60 * 60 * 5
) -> Callable[[Callable], Callable]:
    """Backward-compatible alias for :func:`cached` (providers subfolder)."""
    return cached(file_prefix=file_prefix, expire_sec=expire_sec, subfolder="providers")
