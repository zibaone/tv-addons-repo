"""Kodi video bookmarks / resume points lookup utility."""

import glob
import os
import sqlite3
from typing import Dict, Tuple

import xbmc
import xbmcvfs

from tv_common.utils.kodi import log


def get_kodi_bookmarks() -> Dict[str, Tuple[float, float]]:
    """Return a mapping of media URL/filename -> (time_in_seconds, total_time_in_seconds).

    Reads the latest Kodi video database (MyVideos*.db) in read-only mode.
    Returns an empty dict if the database cannot be found or read.
    """
    try:
        db_dir = xbmcvfs.translatePath("special://database")
        if not db_dir or not os.path.exists(db_dir):
            return {}

        dbs = sorted(glob.glob(os.path.join(db_dir, "MyVideos*.db")))
        if not dbs:
            return {}

        latest_db = dbs[-1]
        uri_path = f"file:{os.path.abspath(latest_db)}?mode=ro"
        with sqlite3.connect(uri_path, uri=True, timeout=1.0) as conn:
            cursor = conn.cursor()
            cursor.execute(
                "SELECT files.strFilename, bookmark.timeInSeconds, bookmark.totalTimeInSeconds "
                "FROM bookmark "
                "JOIN files ON bookmark.idFile = files.idFile "
                "WHERE bookmark.timeInSeconds > 0"
            )
            return {row[0]: (float(row[1]), float(row[2])) for row in cursor.fetchall()}
    except Exception as e:
        log(f"Bookmark lookup failed (non-fatal): {e}", xbmc.LOGDEBUG)
        return {}
