"""Helpers for Kodi GUI."""

import contextlib
import shutil
import sys
import urllib.parse
from pathlib import Path
from typing import Optional, Union

import xbmc
from xbmcgui import ListItem


def _set_int(video_info_tag, method: str, value) -> None:
    """Call a Kodi InfoTagVideo int setter only with a valid integer.

    Kodi's C++ bindings raise TypeError ('... cannot be interpreted as an
    integer') when passed None or a non-numeric string, so we guard every
    numeric setter (duration, year, season, episode).
    """
    setter = getattr(video_info_tag, method, None)
    if setter is None or value is None:
        return
    with contextlib.suppress(TypeError, ValueError):
        setter(int(value))


def _set_float(video_info_tag, method: str, value) -> None:
    """Call a Kodi InfoTagVideo float setter (rating) only with a valid number."""
    setter = getattr(video_info_tag, method, None)
    if setter is None or value is None:
        return
    with contextlib.suppress(TypeError, ValueError):
        setter(float(value))


def _apply_video_info_tag(video_info_tag, item_info_data: dict) -> None:
    """Populate Kodi VideoInfoTag with metadata fields."""
    _set_int(video_info_tag, "setDuration", item_info_data.get("duration"))
    _set_int(video_info_tag, "setYear", item_info_data.get("year"))
    _set_int(video_info_tag, "setSeason", item_info_data.get("season"))
    _set_int(video_info_tag, "setEpisode", item_info_data.get("episode"))

    if "genres" in item_info_data:
        video_info_tag.setGenres(item_info_data.get("genres"))

    if "plot" in item_info_data:
        video_info_tag.setPlot(item_info_data.get("plot"))

    if "title" in item_info_data:
        video_info_tag.setTitle(item_info_data.get("title"))

    if "mediatype" in item_info_data:
        video_info_tag.setMediaType(item_info_data.get("mediatype"))

    if "premiered" in item_info_data:
        video_info_tag.setPremiered(item_info_data.get("premiered"))

    if "cast" in item_info_data:
        cast = item_info_data.get("cast")
        if cast:
            try:
                actors = []
                for member in cast:
                    if isinstance(member, str):
                        actors.append(xbmc.Actor(name=member))
                    elif isinstance(member, dict):
                        actors.append(
                            xbmc.Actor(
                                name=member.get("name", ""),
                                role=member.get("role", ""),
                            )
                        )
                video_info_tag.setCast(actors)
            except TypeError:
                # Very old Kodi builds may not provide xbmc.Actor.
                video_info_tag.setCast(cast)

    if "tmdb" in item_info_data and hasattr(video_info_tag, "setTmdbId"):
        video_info_tag.setTmdbId(item_info_data.get("tmdb"))

    _set_float(video_info_tag, "setRating", item_info_data.get("rating"))

    if "director" in item_info_data:
        director = item_info_data.get("director")
        if director:
            if hasattr(video_info_tag, "setDirectors"):
                video_info_tag.setDirectors(director)
            elif hasattr(video_info_tag, "setDirector"):
                video_info_tag.setDirector(director)

    if "writer" in item_info_data and hasattr(video_info_tag, "setWriters"):
        video_info_tag.setWriters(item_info_data.get("writer"))

    if "country" in item_info_data and hasattr(video_info_tag, "setCountries"):
        video_info_tag.setCountries(item_info_data.get("country"))

    if "trailer" in item_info_data and hasattr(video_info_tag, "setTrailer"):
        video_info_tag.setTrailer(item_info_data.get("trailer"))

    resume_time = item_info_data.get("resumetime") or item_info_data.get("resume_point")
    total_time = item_info_data.get("totaltime") or item_info_data.get("duration")
    if resume_time is not None and hasattr(video_info_tag, "setResumePoint"):
        with contextlib.suppress(TypeError, ValueError):
            video_info_tag.setResumePoint(float(resume_time), float(total_time or 0))


def create_list_item(item_data: dict, is_folder: bool = False) -> ListItem:
    """Create a list item from data."""
    list_item = ListItem(label=item_data.get("label"), path=item_data.get("path"))

    if "art" in item_data:
        item_art_data: dict = item_data.get("art", {})
        art_dict = {k: v for k, v in item_art_data.items() if v}
        if art_dict and hasattr(list_item, "setArt"):
            list_item.setArt(art_dict)

    if not is_folder:
        props = {"IsPlayable": "true"}
        info_data = item_data.get("info", {})
        resume_time = info_data.get("resumetime") or info_data.get("resume_point")
        total_time = info_data.get("totaltime") or info_data.get("duration")
        if resume_time is not None:
            with contextlib.suppress(TypeError, ValueError):
                props["ResumeTime"] = str(float(resume_time))
                if total_time:
                    props["TotalTime"] = str(float(total_time))
        list_item.setProperties(props)

    if "info" in item_data and hasattr(list_item, "getVideoInfoTag"):
        item_info_data: dict = item_data.get("info", {})
        video_info_tag = list_item.getVideoInfoTag()
        if video_info_tag is not None:
            _apply_video_info_tag(video_info_tag, item_info_data)

    return list_item


def create_play_item(stream_info: dict = None, inputstream_addon: str = "") -> ListItem:
    """Create a play item from stream data."""
    if stream_info is None:
        stream_info = {}

    path = stream_info.get("path")
    headers = stream_info.get("headers", {})

    if not inputstream_addon and headers and path and "|" not in path:
        header_param = "&".join(f"{k}={urllib.parse.quote(str(v))}" for k, v in headers.items())
        path = f"{path}|{header_param}"

    label = stream_info.get("label") or stream_info.get("title")
    if not label and isinstance(stream_info.get("info"), dict):
        label = stream_info["info"].get("title")

    play_item = ListItem(label=str(label), path=path) if (label or path) else ListItem()
    if label and hasattr(play_item, "setLabel"):
        play_item.setLabel(str(label))
    play_item.setContentLookup(False)

    # Set art if available
    if "art" in stream_info and isinstance(stream_info["art"], dict):
        art_dict = {k: v for k, v in stream_info["art"].items() if v}
        if art_dict and hasattr(play_item, "setArt"):
            play_item.setArt(art_dict)

    # Set video info tag if available
    info = dict(stream_info.get("info", {})) if isinstance(stream_info.get("info"), dict) else {}
    if label and not info.get("title"):
        info["title"] = str(label)

    if info and hasattr(play_item, "getVideoInfoTag"):
        video_info_tag = play_item.getVideoInfoTag()
        if video_info_tag is not None:
            _apply_video_info_tag(video_info_tag, info)

    if inputstream_addon:
        play_item.setProperty("inputstream", inputstream_addon)
        play_item.setProperty("inputstream.adaptive.manifest_type", stream_info.get("protocol"))
        play_item.setProperty("inputstream.adaptive.play_timeshift_buffer", "true")

        if headers:
            header_str = "&".join(f"{k}={urllib.parse.quote(str(v))}" for k, v in headers.items())
            play_item.setProperty("inputstream.adaptive.manifest_headers", header_str)
            play_item.setProperty("inputstream.adaptive.stream_headers", header_str)

        drm_config = stream_info.get("drm_config", {})
        if drm_config.get("drm_legacy"):
            play_item.setProperty("inputstream.adaptive.drm_legacy", drm_config["drm_legacy"])
        elif drm_config.get("drm"):
            play_item.setProperty("inputstream.adaptive.drm", drm_config["drm"])
        else:
            keys = [
                "license_type",
                "license_key",
                "license_data",
                "server_certificate",
                "license_flags",
                "pre_init_data",
            ]
            for key in keys:
                if drm_config.get(key) is not None:
                    play_item.setProperty(f"inputstream.adaptive.{key}", drm_config.get(key))

    return play_item


def sync_addon_icon(
    addon_path: Union[str, Path, None] = None,
    addon_id: Optional[str] = None,
    notify_gui: bool = False,
) -> bool:
    """Synchronize addon icon.png based on appearance.icon_style setting.

    - appearance.icon_style == 0 (or 'Officiel'): uses resources/media/icon_official.png
    - appearance.icon_style == 1 (or '3D Moderne'): uses resources/media/icon_3d.png
    Also invalidates and directly updates Kodi's texture cache if available.
    Returns True if an update was made, False otherwise.
    """
    try:
        import xbmcaddon

        from tv_common.utils.kodi import get_addon_info, get_addon_setting, log

        resolved_path = None
        if addon_path:
            resolved_path = Path(addon_path)
            if not addon_id and resolved_path.name.startswith("plugin.video."):
                addon_id = resolved_path.name
        elif addon_id:
            with contextlib.suppress(Exception):
                kodi_path = xbmcaddon.Addon(addon_id).getAddonInfo("path")
                if kodi_path:
                    resolved_path = Path(kodi_path)

        if not resolved_path:
            kodi_path = get_addon_info("path")
            if kodi_path:
                resolved_path = Path(kodi_path)
                if not addon_id:
                    addon_id = get_addon_info("id")
            else:
                main_mod = sys.modules.get("__main__")
                if main_mod and hasattr(main_mod, "__file__") and main_mod.__file__:
                    p = Path(main_mod.__file__).resolve()
                    resolved_path = p.parent.parent if p.parent.name == "resources" else p.parent
                    if not addon_id and resolved_path.name.startswith("plugin.video."):
                        addon_id = resolved_path.name
                else:
                    resolved_path = Path.cwd()

        media_dir = resolved_path / "resources" / "media"
        if not media_dir.is_dir():
            return False

        icon_official = media_dir / "icon_official.png"
        icon_3d = media_dir / "icon_3d.png"
        target_icon = media_dir / "icon.png"

        setting_val = None
        if addon_id:
            with contextlib.suppress(Exception):
                setting_val = xbmcaddon.Addon(addon_id).getSetting("appearance.icon_style")

        if setting_val is None or setting_val == "":
            try:
                setting_val = get_addon_setting("appearance.icon_style", int)
            except Exception:
                try:
                    setting_val = get_addon_setting("appearance.icon_style", str)
                except Exception:
                    setting_val = "0"

        is_3d = str(setting_val).strip() in ("1", "3D Moderne", "3D")
        source = icon_3d if is_3d else icon_official
        if not source.exists():
            return False

        updated = False
        if not target_icon.exists() or target_icon.stat().st_size != source.stat().st_size:
            shutil.copyfile(source, target_icon)
            updated = True

        for legacy in media_dir.glob("*.png"):
            if legacy.name not in ("icon.png", "icon_3d.png", "icon_official.png") and (
                not legacy.exists() or legacy.stat().st_size != source.stat().st_size
            ):
                shutil.copyfile(source, legacy)
                updated = True

        # Invalidate / update Kodi texture cache
        textures_purged = False
        try:
            import sqlite3

            import xbmcvfs

            db_dir_str = xbmcvfs.translatePath("special://database/")
            thumbs_dir_str = xbmcvfs.translatePath("special://thumbnails/")
            if db_dir_str and thumbs_dir_str:
                db_dir = Path(db_dir_str)
                thumbs_dir = Path(thumbs_dir_str)
                if db_dir.is_dir() and thumbs_dir.is_dir():
                    db_files = sorted(db_dir.glob("Textures*.db"))
                    search_key = addon_id or resolved_path.name

                    for db_file in db_files:
                        if not db_file.exists() or db_file.stat().st_size == 0:
                            continue
                        try:
                            conn = sqlite3.connect(db_file, timeout=2.0)
                            cur = conn.cursor()
                            cur.execute(
                                "SELECT id, url, cachedurl FROM texture WHERE url LIKE ?",
                                (f"%{search_key}%",),
                            )
                            rows = cur.fetchall()
                            for tid, url, cachedurl in rows:
                                fname = url.split("/")[-1].split("?")[0].lower()
                                is_icon = "icon" in fname or fname.endswith(".png")
                                if is_icon:
                                    thumb_file = thumbs_dir / cachedurl
                                    thumb_stale = (
                                        updated
                                        or (not thumb_file.exists())
                                        or (thumb_file.stat().st_size != source.stat().st_size)
                                    )
                                    if thumb_stale:
                                        if thumb_file.exists():
                                            with contextlib.suppress(Exception):
                                                thumb_file.unlink()
                                        cur.execute("DELETE FROM texture WHERE id = ?", (tid,))
                                        textures_purged = True
                            conn.commit()
                            conn.close()
                        except Exception as db_err:
                            xbmc.log(f"Texture cache sync skipped for {db_file.name}: {db_err}", xbmc.LOGDEBUG)
        except Exception as tex_err:
            xbmc.log(f"Texture cache sync skipped: {tex_err}", xbmc.LOGDEBUG)

        if not (updated or textures_purged):
            return False

        log(f"icon.png synced to {'3D Moderne' if is_3d else 'Officiel'}", xbmc.LOGDEBUG)

        if notify_gui:
            with contextlib.suppress(Exception):
                xbmc.executebuiltin("Container.Refresh")

        return True
    except Exception as e:
        xbmc.log(f"Failed to sync addon icon: {e}", xbmc.LOGWARNING)
        return False