"""IPTV Manager Integration module."""

import functools
import json
import socket
from typing import Any, Callable

from tv_common.abstract_provider import AbstractProvider
from tv_common.utils.cache import cached


def via_socket(func: Callable[[Any], Any]) -> Callable[[Any], None]:
    """Send the output of the wrapped method to a socket.

    The wrapped method receives the instance (self) and returns data that is
    JSON-serialized and sent to 127.0.0.1:self.port.
    """

    @functools.wraps(func)
    def send(self) -> None:
        """Decorate to send over a socket."""
        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        sock.connect(("127.0.0.1", self.port))
        try:
            sock.sendall(json.dumps(func(self)).encode())
        finally:
            sock.close()

    return send


class IPTVManager:
    """Manage interactions with IPTV Manager."""

    def __init__(self, port: int, provider: AbstractProvider):
        """Initialize IPTV Manager object."""
        self.port = port
        self.provider = provider
        provider_name = getattr(provider, "name", None) or "unknown"
        self.name = f"iptvmanager_{provider_name}"

    @via_socket
    @cached("streams", expire_sec=6 * 60 * 60)
    def send_channels(self) -> dict:
        """Return JSON-STREAMS formatted python datastructure to IPTV Manager.

        Cached 6h: a fresh cache is served without touching the provider
        (IPTV Manager refreshes on every boot), so repeated reboots no
        longer hammer the Orange/Xtream servers.
        """
        return dict(version=1, streams=self.provider.get_streams())

    @via_socket
    @cached("epg", expire_sec=6 * 60 * 60)
    def send_epg(self) -> dict:
        """Return JSON-EPG formatted python data structure to IPTV Manager."""
        return dict(version=1, epg=self.provider.get_epg())
