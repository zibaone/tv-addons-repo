"""Xtream-compatible IPTV client."""

import time
from typing import Any, Dict, List, Optional

import xbmc
from requests import Session
from requests.exceptions import (
    ConnectionError as RequestsConnectionError,
)
from requests.exceptions import RequestException, Timeout
from tv_common.utils.kodi import log
from tv_common.utils.request import get_random_ua, network_backoff_active, note_network_error

_TIMEOUT = 15
_XMLTV_TIMEOUT = 120
_RETRIES = 1


class XTream:
    """Minimal client for Xtream-compatible IPTV provider APIs.

    API reference: https://xtream-codes.com/ (player_api.php)
    """

    live_type = "live"
    vod_type = "movie"
    series_type = "series"

    def __init__(self, name: str, username: str, password: str, server: str):
        """Initialize XTream client."""
        self.name = name or "provider"
        self.username = username or ""
        self.password = password or ""
        self.server = server.rstrip("/") if server else ""
        self.session = Session()
        self.session.headers.update(
            {
                "User-Agent": get_random_ua(),
                "Accept": "application/json, text/plain, */*",
            }
        )
        self.user_info: Dict[str, Any] = {}
        self.server_info: Dict[str, Any] = {}

    def _api_url(self, action: str, **params) -> str:
        """Build a player_api.php URL."""
        url = f"{self.server}/player_api.php?username={self.username}&password={self.password}&action={action}"
        for key, value in params.items():
            url += f"&{key}={value}"
        return url

    def _safe_url(self, url: str) -> str:
        """Redact credentials from a URL for safe logging."""
        return url.replace(self.password, "[REDACTED]").replace(self.username, "[REDACTED]")

    def _get(self, url: str, timeout: int = _TIMEOUT) -> Optional[Any]:
        """GET a URL with backoff protection and a single retry.

        Returns the parsed JSON response, or None on failure. While the
        network backoff is active, no request is emitted at all (the caller
        falls back to its caches).
        """
        if network_backoff_active():
            log("Network backoff active, skipping request", xbmc.LOGDEBUG)
            return None

        for attempt in range(_RETRIES + 1):
            try:
                response = self.session.get(url, timeout=timeout)
                response.raise_for_status()
                return response.json()
            except (RequestException, ValueError) as e:
                is_transport = isinstance(e, (RequestsConnectionError, Timeout)) or (
                    getattr(e, "response", None) is not None and e.response.status_code >= 500
                )
                if not is_transport:
                    log(f"error while fetching {self._safe_url(url)}: {e}")
                    return None
                # Retry once, then enter the backoff only if it failed again
                # (a transient 502 is absorbed by the retry; a down server
                # stops being hammered).
                if attempt < _RETRIES:
                    time.sleep(1)
                    continue
                note_network_error()
                log(f"Network error while fetching {self._safe_url(url)}: {e}", xbmc.LOGWARNING)
                return None

        return None

    def authenticate(self) -> bool:
        """Authenticate against the provider and load user/server info."""
        if not self.server:
            log("No Xtream server configured", xbmc.LOGWARNING)
            return False

        data = self._get(self._api_url(""))
        if not isinstance(data, dict):
            return False
        self.user_info = data.get("user_info", {})
        self.server_info = data.get("server_info", {})
        log(f"authenticated on {self.name}: {self.user_info.get('status')}")
        return self.user_info.get("status") == "Active"

    def _get_request(self, url: str) -> Optional[dict]:
        """GET a player_api endpoint and parse JSON."""
        data = self._get(url)
        return data if isinstance(data, dict) else None

    def _streams_action(self, stream_type: str) -> str:
        """Map a stream type to its player_api action name."""
        if stream_type == self.vod_type:
            return "get_vod_streams"
        if stream_type == self.series_type:
            return "get_series"
        return f"get_{stream_type}_streams"

    def _categories_action(self, stream_type: str) -> str:
        """Map a stream type to its categories action name."""
        if stream_type == self.vod_type:
            return "get_vod_categories"
        return f"get_{stream_type}_categories"

    def load_categories(self, stream_type: str) -> list:
        """Load categories for a stream type (live, movie, series)."""
        data = self._get(self._api_url(self._categories_action(stream_type)))
        return data if isinstance(data, list) else []

    def load_streams(self, stream_type: str) -> list:
        """Load streams for a stream type (live, movie, series)."""
        data = self._get(self._api_url(self._streams_action(stream_type)))
        return data if isinstance(data, list) else []

    def get_vod_info(self, vod_id) -> dict:
        """Load VOD info for a movie."""
        return self._get(self._api_url("get_vod_info", vod_id=vod_id)) or {}

    def get_series_info(self, series_id) -> dict:
        """Load series info (seasons/episodes) for a series."""
        return self._get(self._api_url("get_series_info", series_id=series_id)) or {}

    def get_epg(self, stream_id: int) -> dict:
        """Load EPG for a live stream id."""
        return self._get(self._api_url("get_short_epg", stream_id=stream_id)) or {}

    def get_simple_data_table(self, stream_id: int) -> dict:
        """Load the full-day EPG table for a live stream id."""
        return self._get(self._api_url("get_simple_data_table", stream_id=stream_id)) or {}

    def get_xmltv(self) -> str:
        """Fetch the full XMLTV EPG (all channels) as raw XML."""
        if not self.server:
            return ""
        if network_backoff_active():
            log("Network backoff active, skipping xmltv fetch", xbmc.LOGDEBUG)
            return ""

        url = f"{self.server}/xmltv.php?username={self.username}&password={self.password}"
        try:
            response = self.session.get(url, timeout=_XMLTV_TIMEOUT)
            response.raise_for_status()
            return response.text
        except (RequestException, ValueError) as e:
            if isinstance(e, (RequestsConnectionError, Timeout)) or (
                getattr(e, "response", None) is not None and e.response.status_code >= 500
            ):
                note_network_error()
                log(f"Network error while fetching xmltv on {self.name}: {e}", xbmc.LOGWARNING)
            else:
                log(f"error while fetching xmltv on {self.name}: {e}")
            return ""

    def make_stream_url(self, stream_type: str, stream_id, extension: Optional[str] = None) -> str:
        """Build the playable stream URL.

        Level keys use ``vod`` for films internally while the panel serves
        movie streams under ``/movie/`` (only the ``get_vod_*`` API actions
        use the ``vod`` spelling), so alias the type before building the URL.
        """
        if stream_type in ("vod", self.vod_type):
            stream_type = self.vod_type
        url = f"{self.server}/{stream_type}/{self.username}/{self.password}/{stream_id}"
        return f"{url}.{extension}" if extension else url

    def filter_streams(self, param: str, value, streams: List[dict]) -> List[dict]:
        """Filter a stream list by a given parameter/value pair."""
        return [stream for stream in streams if stream.get(param) == value]

    def make_timeshift_url(
        self,
        stream_id,
        start_ts: int,
        duration_minutes: int,
        extension: str = "ts",
        utc_offset_secs: Optional[int] = None,
    ) -> str:
        """Build the timeshift (catch-up) URL for a programme start.

        Follows the ``Xtream codes`` catch-up convention (the same scheme
        pvr.iptvsimple generates in its xc mode):
        ``{server}/timeshift/{user}/{pass}/{minutes}/{Y}-{m}-{d}:{H}-{M}/{id}.ts``

        The panel server interprets the timestamp in its own timezone (the
        PHP server timezone — often UTC — not the box's), so callers pass
        ``utc_offset_secs`` captured from the panel's ``server_info``. Without
        it, fall back to the box's local timezone.
        """
        ts = int(start_ts)
        if utc_offset_secs is None:
            stamp = time.strftime("%Y-%m-%d:%H-%M", time.localtime(ts))
            log(f"catch-up stamp {stamp} built in box-local time (panel offset unknown)")
        else:
            offset = int(utc_offset_secs)
            stamp = time.strftime("%Y-%m-%d:%H-%M", time.gmtime(ts + offset))
            log(f"catch-up stamp {stamp} built with panel UTC offset {offset}s")
        minutes = max(1, int(duration_minutes))
        return (
            f"{self.server}/timeshift/{self.username}/{self.password}/"
            f"{minutes}/{stamp}/{stream_id}.{extension}"
        )
