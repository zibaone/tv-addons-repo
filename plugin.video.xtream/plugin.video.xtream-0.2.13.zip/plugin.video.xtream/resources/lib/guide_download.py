"""Replay download from the TV guide (context item core).

A ``kodi.context.item`` click on a past programme lands here: resolve the
channel offline, guard the request (finished programme, archive window, one
download at a time), build the timeshift URL and download the exact
programme window to the configured folder with a background progress dialog.
The downloaded timeline is then checked (head/tail sampling) and rebuilt
in place when the panel stream carried a broken 33-bit clock, so Kodi gets
a seekable file.

Every side-effecting collaborator (provider, monitor, progress, clock) is a
parameter so the core stays fully testable; the user notification is left to
the bootstrap.
"""

import contextlib
import os
import time
from typing import Dict, Optional

import xbmc
import xbmcgui
import xbmcvfs
from tv_common import ts_timeline
from tv_common.exceptions import DownloadCancelledError, DownloadInProgressError
from tv_common.utils.context_item import guide_item_from_listitem
from tv_common.utils.download import build_download_filename, download_to_file, mask_url
from tv_common.utils.kodi import get_addon_info, get_addon_setting, localize, log

DEFAULT_DOWNLOAD_FOLDER = "/storage/videos/"
SETTING_DOWNLOAD_FOLDER = "download.folder"
LOCK_FILENAME = ".download.lock"
REPAIR_TEMP_SUFFIX = ".repairing.ts"

MSG_NOT_FOUND = 30253
MSG_NOT_ARCHIVED = 30254
MSG_NOT_FINISHED = 30255
MSG_OUT_OF_WINDOW = 30256
MSG_ALREADY_RUNNING = 30257
MSG_SAVED = 30258
MSG_FAILED = 30259
MSG_REPAIRING = 30260
MSG_REPAIR_FAILED = 30261

_ARCHIVE_DEFAULT_DAYS = 2
_ARCHIVE_MAX_DAYS = 7
_UPDATE_INTERVAL_SEC = 0.5


class ProgressDialog:
    """Non-blocking background progress dialog (throttled updates)."""

    def __init__(self):
        """Create the wrapped ``DialogProgressBG``."""
        self._dialog = xbmcgui.DialogProgressBG()
        self._last_update = 0.0

    def create(self, message: str) -> None:
        """Show the dialog for the file being downloaded."""
        self._dialog.create(get_addon_info("name"), message)
        self._last_update = 0.0

    def update(self, downloaded: int, total: Optional[int]) -> None:
        """Refresh the progress (~2 updates/s); percentage when size is known."""
        now = time.monotonic()
        if now - self._last_update < _UPDATE_INTERVAL_SEC:
            return
        self._last_update = now
        if total:
            self._dialog.update(int(downloaded * 100 / total))
        else:
            self._dialog.update(0, message=f"{downloaded / (1024 * 1024):.1f} MB")

    def relabel(self, message: str) -> None:
        """Switch the dialog label for a new phase (progress restarts at 0)."""
        self._dialog.update(0, message=message)
        self._last_update = 0.0

    def close(self) -> None:
        """Close the dialog."""
        self._dialog.close()


def resolve_download_folder() -> str:
    """Return the configured download folder, creating it when missing."""
    folder = get_addon_setting(SETTING_DOWNLOAD_FOLDER) or DEFAULT_DOWNLOAD_FOLDER
    folder = xbmcvfs.translatePath(folder)
    if folder and not os.path.isdir(folder):
        os.makedirs(folder, exist_ok=True)
    return folder


def _archive_days(channel: Optional[dict]) -> int:
    """Archive window (days) declared by the panel, clamped like the provider."""
    raw = (channel or {}).get("tv_archive_duration")
    days = int(raw) if str(raw).strip().isdigit() else _ARCHIVE_DEFAULT_DAYS
    return min(max(days, 1), _ARCHIVE_MAX_DAYS)


def _guard(channel, item, now: int):
    """Return ``(message_id, message_args)`` blocking the download, or None."""
    if channel is None:
        return MSG_NOT_FOUND, {}
    if str(channel.get("tv_archive")) != "1":
        return MSG_NOT_ARCHIVED, {}

    start_epoch = item.get("start_epoch")
    duration_min = item.get("duration_min")
    if start_epoch is None or duration_min is None:
        return MSG_FAILED, {"error": "unreadable guide item (no start/duration)"}

    if start_epoch + duration_min * 60 > now:
        return MSG_NOT_FINISHED, {}

    days = _archive_days(channel)
    if start_epoch < now - days * 86400:
        return MSG_OUT_OF_WINDOW, {"days": days}
    return None


def _result(path=None, message_id=None, message_args=None) -> Dict:
    """Build the normalized result dict."""
    return {"path": path, "message_id": message_id, "message_args": message_args or {}}


def _acquire_lock(folder: str) -> str:
    """Create the single-download lock file (O_EXCL) and return its path."""
    lock_path = os.path.join(folder, LOCK_FILENAME)
    try:
        fd = os.open(lock_path, os.O_CREAT | os.O_EXCL | os.O_WRONLY, 0o644)
    except FileExistsError as exc:
        raise DownloadInProgressError(lock_path) from exc
    os.close(fd)
    return lock_path


def _release_lock(lock_path: str) -> None:
    """Remove the lock file, ignoring races and missing files."""
    with contextlib.suppress(OSError):
        os.remove(lock_path)


def _provider_secrets(provider) -> tuple:
    """Return the provider credentials to redact from logs."""
    xt = getattr(provider, "xt", None)
    return ((getattr(xt, "username", "") or ""), (getattr(xt, "password", "") or ""))


def _repair_timeline_if_needed(dest_path: str, monitor=None, progress=None) -> bool:
    """Check the downloaded timeline and rebuild it when broken.

    A cheap head/tail sampling decides (no extra cost on sane files). A
    broken track is rebuilt into ``<dest_path>.repairing.ts`` and swapped in
    with ``os.replace``; ``monitor`` and the progress dialog follow the pass.
    Return True when the repair failed and the original download was kept
    (the caller announces it); False when nothing had to be reported.
    """
    try:
        if ts_timeline.timeline_is_sane(dest_path):
            return False
    except Exception as exc:
        log(f"timeline check failed (keeping the download as is): {exc}", xbmc.LOGWARNING)
        return False

    temp_path = dest_path + REPAIR_TEMP_SUFFIX
    log(f"broken timeline detected, repairing: {dest_path}", xbmc.LOGINFO)
    if progress is not None:
        progress.relabel(localize(MSG_REPAIRING))
    try:
        report = ts_timeline.repair_timeline(
            dest_path,
            temp_path,
            monitor=monitor,
            progress_cb=progress.update if progress is not None else None,
        )
    except DownloadCancelledError:
        with contextlib.suppress(OSError):
            os.remove(temp_path)
        raise
    except Exception as exc:
        log(f"timeline repair failed, keeping the original download: {exc}", xbmc.LOGWARNING)
        with contextlib.suppress(OSError):
            os.remove(temp_path)
        return True

    os.replace(temp_path, dest_path)
    log(
        f"timeline repaired: {report.duration_s:.1f} s, {report.events_backward} backward / "
        f"{report.events_forward} forward jumps, {report.events_clamped} rebased, "
        f"{report.pes_headers} PES headers, {report.pcr_fields} PCR fields",
        xbmc.LOGINFO,
    )
    return False


def download_replay(listitem, provider, infolabel=None, monitor=None, progress=None, now=None) -> Dict:
    """Download the replay of the programme Kodi handed to the context script.

    ``listitem`` is ``sys.listitem``. Return ``{"path", "message_id",
    "message_args"}``: ``message_id`` is the localized id to notify, ``None``
    when the run must stay silent (cancellation).
    """
    item = guide_item_from_listitem(listitem, infolabel=infolabel)
    log(
        "guide download request: title={title!r} channel={channel!r} start={start} dur={dur}".format(
            title=item.get("title"),
            channel=item.get("channel_name"),
            start=item.get("start_epoch"),
            dur=item.get("duration_min"),
        ),
        xbmc.LOGINFO,
    )

    channel = None
    if item.get("channel_name"):
        channel = provider.find_channel_by_name(item["channel_name"])
    blocked = _guard(channel, item, int(now if now is not None else time.time()))
    if blocked:
        message_id, message_args = blocked
        log(f"guide download refused: message {message_id} {message_args}", xbmc.LOGWARNING)
        return _result(message_id=message_id, message_args=message_args)

    folder = resolve_download_folder()
    try:
        lock_path = _acquire_lock(folder)
    except DownloadInProgressError as exc:
        log(f"guide download refused: another download is in progress ({exc})", xbmc.LOGWARNING)
        return _result(message_id=MSG_ALREADY_RUNNING, message_args={"path": str(exc)})

    secrets = _provider_secrets(provider)
    repair_failed = False
    try:
        url_info = provider.archive_download_url(
            channel.get("stream_id"), item["start_epoch"], item["duration_min"]
        )
        filename = build_download_filename(
            item.get("title"),
            item.get("channel_name"),
            item["start_epoch"],
            season=item.get("season"),
            episode=item.get("episode"),
        )
        dest_path = os.path.join(folder, filename)
        log(f"guide download start: {mask_url(url_info.get('url', ''), *secrets)} -> {filename}", xbmc.LOGINFO)

        if progress is not None:
            progress.create(filename)
        try:
            download_to_file(
                provider.xt.session,
                url_info["url"],
                dest_path,
                headers=url_info.get("headers"),
                progress_cb=progress.update if progress is not None else None,
                monitor=monitor,
            )
            repair_failed = _repair_timeline_if_needed(dest_path, monitor=monitor, progress=progress)
        except DownloadInProgressError as exc:
            log(f"guide download refused: target already in progress ({exc})", xbmc.LOGWARNING)
            return _result(message_id=MSG_ALREADY_RUNNING, message_args={"path": str(exc)})
        except DownloadCancelledError:
            log("guide download cancelled", xbmc.LOGINFO)
            return _result()
        except Exception as exc:
            error = mask_url(str(exc), *secrets)
            log(f"guide download failed: {error}", xbmc.LOGERROR)
            return _result(message_id=MSG_FAILED, message_args={"error": error})
        finally:
            if progress is not None:
                progress.close()
    finally:
        _release_lock(lock_path)

    log(f"guide download saved: {filename}", xbmc.LOGINFO)
    if repair_failed:
        return _result(
            path=dest_path, message_id=MSG_REPAIR_FAILED, message_args={"filename": filename}
        )
    return _result(path=dest_path, message_id=MSG_SAVED, message_args={"filename": filename})
