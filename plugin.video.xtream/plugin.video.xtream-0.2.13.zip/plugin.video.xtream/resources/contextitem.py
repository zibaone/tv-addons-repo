"""Bootstrap of the "download this replay" TV-guide context item.

Kodi runs this file (declared in addon.xml, ``kodi.context.item``) when the
user picks the entry on a past programme. Thin wrapper: make the addon's
``resources`` directory importable (same layout as ``resources/addon.py``),
run the download core and show the single notification.
"""

import os
import sys

_ADDON_RESOURCES = os.path.dirname(os.path.abspath(__file__))


def main() -> None:
    """Run the replay download and notify the user of the outcome."""
    if _ADDON_RESOURCES not in sys.path:
        sys.path.insert(0, _ADDON_RESOURCES)

    import xbmc
    import xbmcgui
    from lib.guide_download import ProgressDialog, download_replay
    from lib.providers import get_provider
    from tv_common.utils.kodi import get_addon_info, localize, log

    log("guide download context item invoked", xbmc.LOGINFO)
    result = download_replay(
        getattr(sys, "listitem", None),
        get_provider(),
        monitor=xbmc.Monitor(),
        progress=ProgressDialog(),
    )

    message_id = result.get("message_id")
    if message_id is None:
        return  # cancelled (or nothing to report): stay silent
    message = localize(message_id, **(result.get("message_args") or {}))
    icon = xbmcgui.NOTIFICATION_INFO if result.get("path") else xbmcgui.NOTIFICATION_WARNING
    xbmcgui.Dialog().notification(get_addon_info("name"), message, icon, 5000)


if __name__ == "__main__":
    main()
