"""Addon routes."""

import urllib.parse

import xbmc
import xbmcgui
import xbmcplugin
from tv_common.managers import CatchupManager, IPTVManager, StreamManager
from tv_common.utils.cache import clear_cache as clear_cache_files
from tv_common.utils.kodi import build_addon_url, log, ok_dialog, set_addon_setting
from tv_common.utils.library import export_catchup_items, notify_export

from lib.providers import get_provider
from lib.router import router


@router.route("/")
def index():
    """Display catchup service index."""
    log("Display catchup index", xbmc.LOGINFO)
    provider = get_provider()
    error = provider.validate_settings() if hasattr(provider, "validate_settings") else None
    if error:
        log(error, xbmc.LOGERROR)
        ok_dialog(error)
        xbmcplugin.endOfDirectory(router.handle)
        return
    CatchupManager(provider, router.handle).build_directory()


@router.route("/catchup/all/<stream_type>")
def catchup_all(stream_type: str):
    """Display paginated catchup directory for a stream type."""
    page_arg = router.args.get("page", ["1"])
    try:
        page = max(1, int(page_arg[0]))
    except (ValueError, TypeError):
        page = 1

    limit = 100
    log(f"Display all catchup {stream_type} (page {page})", xbmc.LOGINFO)
    provider = get_provider()
    items, _ = provider.get_catchup_all_paginated(stream_type, page=page, limit=limit)
    content_type = "tvshows" if stream_type == "series" else "movies"
    CatchupManager(provider, router.handle).render_items(
        items, content_type=content_type, category_name=f"Tous ({page})"
    )


@router.route("/search/<stream_type>")
def search_streams(stream_type: str):
    """Search streams by keyword."""
    query_args = router.args.get("query", [])
    query = query_args[0] if query_args else ""

    if not query:
        media_label = "film" if stream_type == "vod" else "série"
        dialog = xbmcgui.Dialog()
        query = dialog.input(f"Rechercher un {media_label}")
        if not query:
            xbmcplugin.endOfDirectory(router.handle)
            return

    log(f"Searching {stream_type} for: {query}", xbmc.LOGINFO)
    provider = get_provider()
    items = provider.search_streams(stream_type, query)
    content_type = "movies" if stream_type == "vod" else "tvshows"
    CatchupManager(provider, router.handle).render_items(
        items, content_type=content_type, category_name=f"Recherche: {query}"
    )


@router.route("/library/sources/sync")
@router.route("/library/sources/add/<source_type>")
@router.route("/library/sources/add")
def add_library_sources(source_type: str = "all"):
    """Add or synchronize Xtream sources in Kodi's sources.xml."""
    from tv_common.utils.sources import sync_sources_from_mode

    def _get_sources(mode_idx: int):
        sources = []
        include_movies = source_type in ("movies", "vod", "all")
        include_series = source_type in ("tvshows", "series", "all")

        if mode_idx == 0:  # Navigation
            if include_movies:
                sources.append({
                    "name": "Xtream - Films",
                    "path": build_addon_url("/catchup/all/vod"),
                })
            if include_series:
                sources.append({
                    "name": "Xtream - Séries",
                    "path": build_addon_url("/catchup/all/series"),
                })
        elif mode_idx == 1:  # Médiathèque
            if include_movies:
                sources.append({
                    "name": "Xtream - Médiathèque Films",
                    "path": build_addon_url("/library/movies"),
                })
            if include_series:
                sources.append({
                    "name": "Xtream - Médiathèque Séries",
                    "path": build_addon_url("/library/tvshows"),
                })
        elif mode_idx == 2:  # Développeur (Les deux)
            if include_movies:
                sources.append({
                    "name": "Xtream - Films (Navigation)",
                    "path": build_addon_url("/catchup/all/vod"),
                })
                sources.append({
                    "name": "Xtream - Médiathèque Films",
                    "path": build_addon_url("/library/movies"),
                })
            if include_series:
                sources.append({
                    "name": "Xtream - Séries (Navigation)",
                    "path": build_addon_url("/catchup/all/series"),
                })
                sources.append({
                    "name": "Xtream - Médiathèque Séries",
                    "path": build_addon_url("/library/tvshows"),
                })
        return sources

    sync_sources_from_mode(
        addon_id="plugin.video.xtream",
        addon_name="Xtream Codes",
        get_sources_fn=_get_sources,
        is_disabled_fn=lambda mode: mode == 3,
        mode_names=["Navigation", "Médiathèque", "Développeur", "Désactivé"],
    )



@router.route("/library/sources")
def library_sources():
    """Display dedicated source folders for Kodi video library scanning."""
    items = [
        {
            "is_folder": False,
            "label": "➕ Ajouter automatiquement toutes les sources à Kodi",
            "path": build_addon_url("/library/sources/add/all"),
        },
        {
            "is_folder": True,
            "label": "🎬 Films (pour Médiathèque Kodi)",
            "path": build_addon_url("/library/movies"),
            "content_type": "movies",
        },
        {
            "is_folder": True,
            "label": "📺 Séries TV (pour Médiathèque Kodi)",
            "path": build_addon_url("/library/tvshows"),
            "content_type": "tvshows",
        },
    ]
    CatchupManager(get_provider(), router.handle).render_items(
        items, content_type="videos", category_name="Sources Médiathèque Kodi"
    )


@router.route("/library/movies")
def library_movies():
    """Return all VOD movies in a single batch formatted for Kodi library scraping."""
    log("Building library movies directory for Kodi scraper", xbmc.LOGINFO)
    provider = get_provider()
    items = provider.get_library_movies()
    CatchupManager(provider, router.handle).render_items(
        items, content_type="movies", category_name="Films"
    )


@router.route("/library/tvshows")
def library_tvshows():
    """Return all series folders formatted for Kodi library scraping."""
    log("Building library tvshows directory for Kodi scraper", xbmc.LOGINFO)
    provider = get_provider()
    items = provider.get_library_tvshows()
    CatchupManager(provider, router.handle).render_items(
        items, content_type="tvshows", category_name="Séries TV"
    )


@router.route("/library/tvshows/<series_id>")
def library_series_episodes(series_id: str):
    """Return episodes of a series for Kodi library scraping."""
    log(f"Building library episodes for series {series_id}", xbmc.LOGINFO)
    provider = get_provider()
    # The folder path carries the merged catalogue variant ids in its query args.
    provider.set_args(router.args)
    items = provider.get_library_episodes(series_id)
    CatchupManager(provider, router.handle).render_items(
        items, content_type="episodes"
    )


@router.route("/catchup/<path:levels>")
def catchup_directory(levels: str):
    """Display catchup service directory."""
    log(f"Display catchup directory {levels}", xbmc.LOGINFO)
    CatchupManager(get_provider(), router.handle).build_directory(levels)


@router.route("/stream/live/<stream_id>")
def stream_live(stream_id: str):
    """Load live stream for the required channel id."""
    log(f"Loading live stream {stream_id}", xbmc.LOGINFO)
    provider = get_provider()
    provider.set_args(router.args)
    StreamManager(provider, router.handle, router.args).load_live_stream(stream_id)


@router.route("/stream/live")
@router.route("/stream/live/")
def stream_live_fallback():
    """Fallback if Kodi navigates up to stream parent directory."""
    xbmcplugin.endOfDirectory(router.handle, succeeded=False)


@router.route("/stream/catchup/<stream_id>")
def stream_catchup(stream_id: str):
    """Load catchup stream for the required video id."""
    log(f"Loading catchup stream {stream_id}", xbmc.LOGINFO)
    provider = get_provider()
    provider.set_args(router.args)
    StreamManager(provider, router.handle, router.args).load_catchup_stream(stream_id)


@router.route("/stream/catchup")
@router.route("/stream/catchup/")
def stream_catchup_fallback():
    """Fallback if Kodi navigates up to stream parent directory."""
    xbmcplugin.endOfDirectory(router.handle, succeeded=False)


@router.route("/library/export/<path:levels>")
def library_export(levels: str):
    """Export the given catchup level to the Kodi video library as .strm files."""
    log(f"Exporting catchup {levels} to library", xbmc.LOGINFO)
    level_list = levels.split("/") if levels else []
    directory = level_list[-1] if level_list else "library"
    provider = get_provider()
    # Library export only needs label + stream URL: skip per-item VOD info fetches.
    provider.light_mode = True
    count = export_catchup_items(provider, level_list, directory)
    notify_export(count, directory)
    xbmcplugin.endOfDirectory(router.handle)


@router.route("/groups/manage")
def manage_groups():
    """Open the native multiselect dialog to pick excluded groups."""
    log("Opening groups multiselect dialog", xbmc.LOGINFO)
    provider = get_provider()
    groups_data = provider.get_live_groups()
    if not groups_data:
        ok_dialog("Aucun groupe trouvé — serveur injoignable ?")
        return

    names = [g["name"] for g in groups_data]
    preselect = [i for i, g in enumerate(groups_data) if g["excluded"]]

    selected = xbmcgui.Dialog().multiselect(
        "Groupes à exclure de la playlist",
        names,
        preselect=preselect,
    )

    if selected is None:
        return  # annulé par l'utilisateur

    new_excluded = [names[i] for i in selected]
    set_addon_setting("xtream.excluded_groups", ";".join(sorted(new_excluded)))
    log(f"{len(new_excluded)} group(s) excluded: {new_excluded}", xbmc.LOGINFO)
    ok_dialog(f"{len(new_excluded)} groupe(s) exclu(s) ✓")


@router.route("/groups")
def groups():
    """List live groups with their excluded/included status."""
    log("Displaying live groups", xbmc.LOGINFO)
    provider = get_provider()
    groups_data = provider.get_live_groups()

    for group in groups_data:
        name = group["name"]
        status = "❌" if group["excluded"] else "✅"
        label = f"{status} {name}  ({group['count']} chaînes)"
        path = build_addon_url(f"/groups/toggle/{urllib.parse.quote(name)}")
        list_item = xbmcgui.ListItem(label=label)
        xbmcplugin.addDirectoryItem(router.handle, path, list_item, isFolder=False)

    xbmcplugin.endOfDirectory(router.handle)


@router.route("/groups/toggle/<path:group_name>")
def toggle_group(group_name: str):
    """Toggle a group in the exclusion list and refresh the directory."""
    log(f"Toggling group: {group_name}", xbmc.LOGINFO)
    provider = get_provider()
    name = urllib.parse.unquote(group_name)
    excluded = provider.get_excluded_groups()

    if name in excluded:
        excluded.discard(name)
        status = "inclus"
    else:
        excluded.add(name)
        status = "exclu"

    set_addon_setting("xtream.excluded_groups", ";".join(sorted(excluded)))
    log(f"Group {name} {status}", xbmc.LOGINFO)
    xbmc.executebuiltin(f"Container.Refresh({build_addon_url('/groups')})")


@router.route("/clear_cache")
def clear_cache():
    """Clear the provider cache folder (context menu / settings action)."""
    log("Clearing provider cache", xbmc.LOGINFO)
    count = clear_cache_files()
    log(f"Cache cleared: {count} file(s) removed", xbmc.LOGINFO)
    message = f"Cache vidé ({count} fichier(s))" if count else "Cache déjà vide"
    xbmcgui.Dialog().notification("Xtream Codes", message, xbmcgui.NOTIFICATION_INFO, 4000)
    xbmc.executebuiltin("Container.Refresh")


@router.route("/iptv/channels")
def iptv_channels():
    """Return JSON-STREAMS formatted data for all live channels."""
    log("Loading channels for IPTV Manager", xbmc.LOGINFO)
    port = int(router.args.get("port")[0])
    IPTVManager(port, get_provider()).send_channels()


@router.route("/iptv/epg")
def iptv_epg():
    """Return JSON-EPG formatted data for all live channel EPG data."""
    log("Loading EPG for IPTV Manager", xbmc.LOGINFO)
    port = int(router.args.get("port")[0])
    IPTVManager(port, get_provider()).send_epg()