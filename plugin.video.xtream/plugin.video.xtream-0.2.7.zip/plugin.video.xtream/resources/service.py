"""Background service entrypoint."""

from tv_common.service import run_addon_service

if __name__ == "__main__":
    run_addon_service()
