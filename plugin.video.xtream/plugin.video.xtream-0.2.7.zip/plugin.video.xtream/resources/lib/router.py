"""Addon router (routes are registered in lib.routes)."""

from routing import Plugin as Router

router = Router()
