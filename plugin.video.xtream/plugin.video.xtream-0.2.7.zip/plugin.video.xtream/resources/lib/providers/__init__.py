"""Xtream provider selection."""

from tv_common.abstract_provider import AbstractProvider

from .xtream_provider import XtreamProvider

_PROVIDER = XtreamProvider()


def get_provider() -> AbstractProvider:
    """Return the Xtream provider."""
    return _PROVIDER