"""Xtream Provider."""

import contextlib
import urllib.parse
from datetime import datetime
from typing import Dict, List, Optional, Union

import xbmc
from tv_common.abstract_provider import AbstractProvider
from tv_common.utils.cache import use_router_cache
from tv_common.utils.kodi import build_addon_url, get_addon_setting, log
from tv_common.utils.library import (
    clean_library_title,
    group_canonical_shows,
)
from tv_common.utils.routing import dispatch_by_depth, to_json_streams

from lib.xtream import XTream


class XtreamProvider(AbstractProvider):
    """Xtream-compatible IPTV provider."""

    def __init__(self):
        """Initialize Xtream Provider from addon settings."""
        name = get_addon_setting("xtream.name")
        username = get_addon_setting("xtream.username")
        password = get_addon_setting("xtream.password")
        server = get_addon_setting("xtream.ip")

        self.xt = XTream(name, username, password, server)
        self.name = self.xt.name
        self.light_mode = get_addon_setting("xtream.light_mode", bool)
        self.args: Dict[str, list] = {}

    def validate_settings(self) -> Optional[str]:
        """Return an error message if provider settings are unusable, else None."""
        if not self.xt.server:
            return "Xtream server not configured (settings → Xtream)"
        if not self.xt.username or not self.xt.password:
            return "Xtream credentials not configured (settings → Xtream)"
        if not self.xt.server.startswith(("http://", "https://")):
            return f"Xtream server must start with http(s):// (got: {self.xt.server})"
        return None

    def set_args(self, args: Dict[str, list]) -> None:
        """Set routing query args (stream_type, container_extension, ...)."""
        self.args = args or {}

    def _arg(self, name: str, default: str = None) -> Optional[str]:
        """Get a routing query arg value."""
        values = self.args.get(name) or []
        return values[0] if values else default

    def get_live_stream_info(self, stream_id: str) -> dict:
        """Get live stream information."""
        extension = self._get_container_extension(XTream.live_type, stream_id) or "ts"
        ua = self.xt.session.headers.get("User-Agent") or "IPTVSmartersPro"
        title = self._arg("title")
        return {
            "path": self.xt.make_stream_url(XTream.live_type, stream_id, extension),
            "protocol": "http",
            "mime_type": "video/mp2t",
            "headers": {"User-Agent": ua},
            "title": title,
            "info": {"title": title} if title else {},
        }

    def get_catchup_stream_info(self, stream_id: str) -> dict:
        """Get catchup (VOD/series episode) stream information."""
        stream_type = self._arg("stream_type", XTream.vod_type)
        extension = (
            self._arg("container_extension")
            or self._get_container_extension(stream_type, stream_id)
            or "mp4"
        )
        ua = self.xt.session.headers.get("User-Agent") or "IPTVSmartersPro"
        title = self._arg("title")
        art = {}
        info = {}
        if not title and stream_type == XTream.vod_type:
            with contextlib.suppress(Exception):
                vod_data = self.get_vod_info(stream_id)
                v_info = vod_data.get("info", {})
                title = v_info.get("name")
                art = {
                    "thumb": v_info.get("movie_image") or "",
                    "poster": v_info.get("cover_big") or v_info.get("movie_image") or "",
                }
                info = self._vod_info(v_info)

        if title and "title" not in info:
            info["title"] = title

        return {
            "path": self.xt.make_stream_url(stream_type, stream_id, extension),
            "protocol": "http",
            "mime_type": "video/mp4",
            "headers": {"User-Agent": ua},
            "title": title,
            "info": info,
            "art": art,
        }

    def get_streams(self) -> list:
        """Return JSON-STREAMS formatted channel list, minus excluded groups."""
        cats, channels = self.load_iptv2([XTream.live_type])[XTream.live_type]
        log(f"{len(channels)} channels found for {self.name}")

        groups = {cat["category_id"]: cat["category_name"] for cat in cats}
        excluded = self.get_excluded_groups()

        filtered = [
            c
            for c in channels
            if groups.get(c.get("category_id"), "Autres") not in excluded
        ]
        if excluded:
            log(f"{len(channels) - len(filtered)} channels hidden (excluded groups)", xbmc.LOGINFO)

        return to_json_streams(
            filtered,
            {
                "id": lambda c: (c.get("epg_channel_id") or "").strip() or str(c["stream_id"]),
                "name": lambda c: c["name"],
                "preset": lambda c: c["num"],
                "logo": lambda c: c.get("stream_icon", ""),
                "stream": lambda c: build_addon_url(f"/stream/live/{c.get('stream_id')}"),
                "group": lambda c: [groups.get(c.get("category_id"), "Autres")],
            },
        )

    def get_excluded_groups(self) -> set:
        """Return the set of excluded group names (setting xtream.excluded_groups).

        Group names contain '|' (e.g. "AR | ALGERIA") so the separator is ';'.
        """
        raw = get_addon_setting("xtream.excluded_groups")
        return {g.strip() for g in raw.split(";") if g.strip()}

    def get_live_groups(self) -> list:
        """Return the list of live groups (category_id, category_name, channel count)."""
        cats, streams = self.load_iptv2([XTream.live_type])[XTream.live_type]
        counts = {}
        for s in streams:
            cat = s.get("category_id")
            counts[cat] = counts.get(cat, 0) + 1
        return [
            {
                "id": cat["category_id"],
                "name": cat["category_name"],
                "count": counts.get(cat["category_id"], 0),
                "excluded": cat["category_name"] in self.get_excluded_groups(),
            }
            for cat in cats
        ]

    def get_epg(self) -> Union[str, dict]:
        """Return EPG data following JSON-EPG or raw XMLTV format.

        The provider exposes a bulk XMLTV endpoint (xmltv.php) that returns
        the EPG of all channels in a single request — much faster than the
        per-channel player_api get_short_epg. IPTV Manager accepts raw XMLTV
        strings (it writes them directly into epg.xml), so we return the
        XML as-is; fall back to the time-bounded per-channel JSON-EPG when
        xmltv.php is unavailable.
        """
        xmltv = self._get_xmltv_cached()
        if xmltv:
            return self._strip_xmltv_envelope(xmltv)

        import time

        max_fetch_sec = 8.0
        epg: Dict[str, list] = {}
        cats, channels = self.load_iptv2([XTream.live_type])[XTream.live_type]
        start_time = time.monotonic()

        for channel in channels:
            if time.monotonic() - start_time >= max_fetch_sec:
                break
            stream_id = channel.get("stream_id")
            if stream_id is None:
                continue
            listings = self.get_stream_epg(stream_id).get("epg_listings") or []
            for program in listings:
                start_ts = program.get("start_timestamp")
                stop_ts = program.get("stop_timestamp")
                start = (
                    datetime.fromtimestamp(start_ts).astimezone().replace(microsecond=0).isoformat()
                    if start_ts
                    else ""
                )
                stop = datetime.fromtimestamp(stop_ts).astimezone().isoformat() if stop_ts else ""
                epg.setdefault(program.get("channel_id"), []).append(
                    {
                        "start": start,
                        "stop": stop,
                        "title": program.get("title", ""),
                        "description": program.get("description", ""),
                    }
                )

        return epg

    def get_catchup_items(self, levels: List[str]) -> list:
        """Return a list of directory items for the specified levels."""
        if levels and levels[0] == "all":
            return self._get_catchup_all(levels[1])
        item_getters = [
            self._get_catchup_0,
            self._get_catchup_1,
            self._get_catchup_2,
            self._get_catchup_3,
        ]

        return dispatch_by_depth(item_getters, levels)

    def get_category_name(self, levels: List[str]) -> Optional[str]:
        """Return breadcrumb category name for given navigation levels."""
        if not levels:
            return "Accueil"
        if levels[0] == "all" and len(levels) >= 2:
            st = levels[1]
            return "Tous les films" if st == XTream.vod_type else "Toutes les séries"

        stream_type = levels[0]
        type_labels = {
            XTream.vod_type: "Films",
            XTream.series_type: "Séries",
            XTream.live_type: "Direct",
        }
        base_label = type_labels.get(stream_type, stream_type.title())
        if len(levels) == 1:
            return base_label

        group_id = levels[1]
        try:
            cats, _ = self.load_iptv2([stream_type])[stream_type]
            groups = {str(c["category_id"]): c["category_name"] for c in cats}
            group_name = groups.get(str(group_id), group_id.replace("_", " ").title())
        except Exception:
            group_name = group_id.replace("_", " ").title()

        if len(levels) == 2:
            return f"{base_label} > {group_name}"

        series_id = levels[2]
        with contextlib.suppress(Exception):
            series_info = self.get_series_info(series_id)
            name = series_info.get("info", {}).get("name")
            if name:
                return f"{base_label} > {group_name} > {name}"

        return f"{base_label} > {group_name} > {series_id}"

    def get_catchup_all_paginated(
        self, stream_type: str, page: int = 1, limit: int = 100
    ) -> tuple:
        """Return paginated items of a stream type across categories."""
        cats, streams = self.load_iptv2([stream_type])[stream_type]
        total = len(streams)
        total_pages = max(1, (total + limit - 1) // limit)
        page = max(1, min(page, total_pages))
        start_idx = (page - 1) * limit
        end_idx = start_idx + limit
        page_streams = streams[start_idx:end_idx]

        caller_light = self.light_mode
        self.light_mode = True
        try:
            items = [self._build_item(stream_type, stream) for stream in page_streams]
        finally:
            self.light_mode = caller_light

        c_type = "tvshows" if stream_type == XTream.series_type else "movies"
        if page > 1:
            items.insert(
                0,
                {
                    "is_folder": True,
                    "label": f"« Page précédente ({page - 1}/{total_pages})",
                    "path": build_addon_url(f"/catchup/all/{stream_type}?page={page - 1}"),
                    "content_type": c_type,
                },
            )
        if page < total_pages:
            items.append(
                {
                    "is_folder": True,
                    "label": f"Page suivante ({page + 1}/{total_pages}) »",
                    "path": build_addon_url(f"/catchup/all/{stream_type}?page={page + 1}"),
                    "content_type": c_type,
                }
            )

        return items, total

    def search_streams(self, stream_type: str, query: str) -> list:
        """Search streams by keyword in name."""
        cats, streams = self.load_iptv2([stream_type])[stream_type]
        q = query.lower().strip()
        matches = [s for s in streams if q in s.get("name", "").lower()]
        caller_light = self.light_mode
        self.light_mode = True
        try:
            return [self._build_item(stream_type, s) for s in matches]
        finally:
            self.light_mode = caller_light

    def get_library_movies(self) -> list:
        """Return all movies formatted for the Kodi video library scanner."""
        cats, streams = self.load_iptv2([XTream.vod_type])[XTream.vod_type]
        items = []
        for s in streams:
            stream_id = s.get("stream_id")
            if not stream_id:
                continue
            name = s.get("name", "Sans nom")
            ext = s.get("container_extension") or "mp4"
            params = urllib.parse.urlencode(
                {"stream_type": XTream.vod_type, "container_extension": ext, "title": name}
            )

            clean_name, extracted_year = clean_library_title(name)
            year = s.get("year") or extracted_year

            items.append(
                {
                    "is_folder": False,
                    "label": clean_name,
                    "path": build_addon_url(f"/stream/catchup/{stream_id}?{params}"),
                    "content_type": "movies",
                    "art": {
                        "thumb": s.get("stream_icon", ""),
                        "poster": s.get("stream_icon", ""),
                    },
                    "info": {
                        "title": clean_name,
                        "mediatype": "movie",
                        "year": int(year) if year and str(year).isdigit() else None,
                    },
                }
            )
        return items

    def get_library_tvshows(self) -> list:
        """Return all TV series folders for the Kodi video library scanner.

        Language/quality variants of one series ("FR - X", "AR - X",
        "X [MULTI-SUB]") are merged into a single canonical folder: publishing
        one folder per variant made Kodi resolve every variant to the same TMDb
        show while each variant contributed its own episode rows, which
        duplicated episodes across the whole library. The folder path is a
        stable slug (plus the merged variant ids) so it never changes between
        two scans as long as the catalogue is unchanged.
        """
        cats, streams = self.load_iptv2([XTream.series_type])[XTream.series_type]
        groups = group_canonical_shows(streams)
        items = []
        merged_variants = 0

        for group in groups:
            variants = group["variants"]
            merged_variants += len(variants) - 1
            art_entry = next(
                (v["entry"] for v in variants if v["entry"].get("cover")), variants[0]["entry"]
            )
            plot = next(
                (v["entry"].get("plot") for v in variants if v["entry"].get("plot")), ""
            )
            variant_ids = ",".join(str(v["id"]) for v in variants)
            cover = art_entry.get("cover", "")

            items.append(
                {
                    "is_folder": True,
                    "label": group["title"],
                    "path": build_addon_url(f"/library/tvshows/{group['slug']}?v={variant_ids}"),
                    "content_type": "tvshows",
                    "art": {"thumb": cover, "poster": cover},
                    "info": {
                        "title": group["title"],
                        "mediatype": "tvshow",
                        "year": group["year"],
                        "plot": plot,
                    },
                }
            )

        if merged_variants:
            log(
                f"{merged_variants} variante(s) fusionnée(s) dans {len(items)} séries "
                "pour la médiathèque"
            )
        return items

    def get_library_episodes(self, series_ref: str) -> list:
        """Return episodes of a series for the Kodi video library scanner.

        `series_ref` is the canonical slug built by get_library_tvshows(); the
        merged variant ids arrive through the `v` query arg. A bare numeric ref
        (legacy paths, direct links) is still accepted.

        Episodes are deduplicated on (saison, épisode): the preferred variant
        (FR > AR > EN) provides the stream when several variants carry the same
        episode, and the other variants fill the gaps — so a variant that has
        extra episodes still contributes them instead of being dropped.
        """
        variant_ids = self._variant_ids(series_ref)
        if not variant_ids:
            log(f"cannot resolve series reference {series_ref!r}", xbmc.LOGWARNING)
            return []

        merged: dict = {}
        for position, series_id in enumerate(variant_ids):
            series_info = self.get_series_info(series_id) or {}
            series_cover = (series_info.get("info") or {}).get("cover", "")
            episodes = series_info.get("episodes") or {}

            for season, episode_list in episodes.items():
                for episode in episode_list or []:
                    ep_info = episode.get("info") or {}
                    episode_number = episode.get("episode_num")
                    s_num = int(season) if str(season).isdigit() else 1
                    e_num = (
                        int(episode_number)
                        if episode_number and str(episode_number).isdigit()
                        else None
                    )
                    raw_title = episode.get("title") or (
                        f"S{s_num:02d}E{e_num:02d}" if e_num else f"Saison {season}"
                    )
                    title = clean_library_title(raw_title)[0] or raw_title

                    # Same season+episode in several variants = same episode.
                    key = (s_num, e_num if e_num is not None else title.casefold())
                    if key in merged:
                        continue

                    merged[key] = {
                        "is_folder": False,
                        "label": title,
                        "path": build_addon_url(
                            f"/stream/catchup/{episode.get('id')}?"
                            + urllib.parse.urlencode(
                                {
                                    "stream_type": XTream.series_type,
                                    "container_extension": episode.get("container_extension", "mp4"),
                                    "title": title,
                                }
                            )
                        ),
                        "content_type": "episodes",
                        "art": {"thumb": series_cover},
                        "info": {
                            "title": title,
                            "mediatype": "episode",
                            "season": s_num,
                            "episode": e_num,
                            "plot": ep_info.get("plot") or "",
                            "premiered": ep_info.get("releasedate") or "",
                            "duration": (
                                int(ep_info["duration_secs"])
                                if ep_info.get("duration_secs")
                                else None
                            ),
                        },
                        "_sort": (s_num, e_num if e_num is not None else 0, title, position),
                    }

        items = sorted(merged.values(), key=lambda item: item["_sort"])
        for item in items:
            item.pop("_sort", None)
        if len(variant_ids) > 1:
            log(f"merged {len(items)} episodes from {len(variant_ids)} variantes for {series_ref}")
        return items

    def _variant_ids(self, series_ref: str) -> list:
        """Resolve the series ids to merge for a library folder (see get_library_tvshows)."""
        raw = self._arg("v") or ""
        ids = []
        for part in str(raw).split(","):
            part = part.strip()
            if part.isdigit() and part not in ids:
                ids.append(part)
        if not ids and str(series_ref or "").isdigit():
            ids.append(str(series_ref))
        return ids

    def _get_catchup_all(self, stream_type: str) -> list:
        """Flatten all items of a stream type across categories (with pagination)."""
        items, _ = self.get_catchup_all_paginated(stream_type, page=1, limit=100)
        return items

    def _get_catchup_0(self) -> list:
        """Root level: VOD, series, and groups management (always hierarchical)."""
        return [
            {
                "is_folder": True,
                "label": "Films",
                "path": build_addon_url("/catchup/vod"),
                "content_type": "movies",
                "context_menu": [
                    ("🔍 Rechercher un film...", f"Container.Update({build_addon_url('/search/vod')})"),
                    ("🎬 Tous les films (à plat)", f"Container.Update({build_addon_url('/catchup/all/vod')})"),
                    ("📁 Ajouter aux sources Kodi", f"RunPlugin({build_addon_url('/library/sources/add/movies')})"),
                ],
            },
            {
                "is_folder": True,
                "label": "Séries",
                "path": build_addon_url("/catchup/series"),
                "content_type": "tvshows",
                "context_menu": [
                    ("🔍 Rechercher une série...", f"Container.Update({build_addon_url('/search/series')})"),
                    (
                        "📺 Toutes les séries (à plat)",
                        f"Container.Update({build_addon_url('/catchup/all/series')})",
                    ),
                    (
                        "📁 Ajouter aux sources Kodi",
                        f"RunPlugin({build_addon_url('/library/sources/add/tvshows')})",
                    ),
                ],
            },
            {
                "is_folder": True,
                "label": "⚙️ Groupes (exclusion)",
                "path": build_addon_url("/groups/manage"),
            },
        ]

    @use_router_cache("catchup_1")
    def _get_catchup_1(self, stream_type: str) -> list:
        """Categories level for a stream type."""
        cats, streams = self.load_iptv2([stream_type])[stream_type]
        is_series = stream_type == XTream.series_type
        c_type = "tvshows" if is_series else "movies"
        search_type = "series" if is_series else "vod"
        return [
            {
                "is_folder": True,
                "label": cat["category_name"],
                "path": build_addon_url(f"/catchup/{stream_type}/{cat['category_id']}"),
                "content_type": c_type,
                "context_menu": [
                    ("🔍 Rechercher...", f"Container.Update({build_addon_url(f'/search/{search_type}')})"),
                ],
            }
            for cat in cats
        ]

    @use_router_cache("catchup_2")
    def _get_catchup_2(self, stream_type: str, group_id: str) -> list:
        """Items level for a category."""
        cats, streams = self.load_iptv2([stream_type])[stream_type]
        streams = self.xt.filter_streams(param="category_id", value=group_id, streams=streams)

        # Fetching per-item VOD info is one HTTP request per movie: for large
        # categories this would blow the Kodi plugin timeout, so fall back to
        # light mode (no detailed info) above a threshold. Restore the caller's
        # state afterwards (an export may have forced light mode on).
        caller_light = self.light_mode
        if not caller_light and len(streams) > 500:
            self.light_mode = True

        try:
            items = [self._build_item(stream_type, stream) for stream in streams]
        finally:
            self.light_mode = caller_light

        # Export .strm désactivé temporairement (en attente d'une source locale dédiée)
        # if stream_type == XTream.vod_type:
        #     export = ("📥 Exporter cette catégorie", build_addon_url(f"/library/export/{stream_type}/{group_id}"))
        #     for item in items:
        #         item["context_menu"] = [export]
        return items

    @use_router_cache("catchup_3")
    def _get_catchup_3(self, stream_type: str, group_id: str, series_id: str) -> list:
        """Episodes level for a series."""
        series_info = self.get_series_info(series_id)
        episodes = series_info.get("episodes") or {}
        # Export .strm désactivé temporairement (en attente d'une source locale dédiée)
        # export = ("📥 Exporter cette série", build_addon_url(f"/library/export/{stream_type}/{group_id}/{series_id}"))
        items = []

        for season, episode_list in episodes.items():
            for episode in episode_list:
                ep_title = episode.get("title") or f"Saison {season}"
                params = urllib.parse.urlencode(
                    {
                        "stream_type": stream_type,
                        "container_extension": episode.get("container_extension"),
                        "title": ep_title,
                    }
                )
                stream_path = build_addon_url(f"/stream/catchup/{episode.get('id')}?{params}")
                ep_info = episode.get("info") or {}
                episode_number = episode.get("episode_num")
                items.append(
                    {
                        "is_folder": False,
                        "label": ep_title,
                        "path": stream_path,
                        "content_type": "episodes",
                        "art": {"thumb": series_info.get("info", {}).get("cover", "")},
                        "info": {
                            "title": ep_title,
                            "mediatype": "episode",
                            "season": int(season) if str(season).isdigit() else None,
                            "episode": (
                                int(episode_number)
                                if episode_number and str(episode_number).isdigit()
                                else None
                            ),
                            "plot": ep_info.get("plot") or "",
                            "premiered": ep_info.get("releasedate") or "",
                            "duration": int(ep_info["duration_secs"]) if ep_info.get("duration_secs") else None,
                        },
                    }
                )

        return items

    def _build_item(self, stream_type: str, stream: dict) -> dict:
        """Build a catchup directory item for a VOD or series stream."""
        if stream_type == XTream.series_type:
            return {
                "is_folder": True,
                "label": stream.get("name", "Sans nom"),
                "path": build_addon_url(
                    f"/catchup/{stream_type}/{stream.get('category_id')}/{stream.get('series_id')}"
                ),
                "content_type": "tvshows",
                "art": {"thumb": stream.get("cover", ""), "poster": stream.get("cover", "")},
                "info": {
                    "title": stream.get("name", ""),
                    "mediatype": "tvshow",
                    "plot": stream.get("plot", ""),
                    "year": stream.get("year"),
                },
            }

        stream_id = stream.get("stream_id")
        name = stream.get("name", "Sans nom")
        params = urllib.parse.urlencode(
            {
                "stream_type": stream_type,
                "container_extension": stream.get("container_extension", "mp4"),
                "title": name,
            }
        )
        vod_info = {} if self.light_mode else self.get_vod_info(stream_id)

        return {
            "is_folder": False,
            "label": name,
            "path": build_addon_url(f"/stream/catchup/{stream_id}?{params}"),
            "content_type": "movies",
            "art": {
                "thumb": vod_info.get("movie_image") or stream.get("stream_icon", ""),
                "poster": vod_info.get("cover_big") or vod_info.get("movie_image") or stream.get("stream_icon", ""),
                "fanart": vod_info.get("backdrop_path") or "",
            },
            "info": self._vod_info(vod_info, stream),
        }

    def _vod_info(self, vod_info: dict, stream: dict = None) -> dict:
        """Extract Kodi video info from a VOD info payload."""
        stream = stream or {}
        releasedate = vod_info.get("releasedate")
        year = None
        if releasedate:
            try:
                year = int(datetime.strptime(releasedate, "%Y-%m-%d").year)
            except ValueError:
                year = None
        if not year and stream.get("year"):
            try:
                year = int(stream["year"])
            except (ValueError, TypeError):
                year = None
        if not year and stream.get("name"):
            import re

            m = re.search(r"\((\d{4})\)", stream["name"])
            if m:
                try:
                    year = int(m.group(1))
                except ValueError:
                    year = None

        cast = vod_info.get("cast")
        if isinstance(cast, str):
            cast = [name.strip() for name in cast.split(",") if name.strip()]
        elif not isinstance(cast, list):
            cast = []

        director = vod_info.get("director")
        director = [director] if isinstance(director, str) and director else []

        country = vod_info.get("country")
        country = [country] if isinstance(country, str) and country else []

        trailer = vod_info.get("youtube_trailer")
        trailer = f"https://www.youtube.com/watch?v={trailer}" if isinstance(trailer, str) and trailer else ""

        rating = None
        try:
            rating = float(vod_info["rating"]) if vod_info.get("rating") else None
        except (TypeError, ValueError):
            rating = None

        info = {
            "title": vod_info.get("name") or stream.get("name", ""),
            "genres": (vod_info.get("genre") or "").split(", "),
            "plot": vod_info.get("plot") or vod_info.get("description") or "No description...",
            "premiered": releasedate,
            "mediatype": "movie",
            "cast": cast,
            "director": director,
            "country": country,
            "tmdb": vod_info.get("tmdb_id"),
            "trailer": trailer,
            "rating": rating,
        }
        if year:
            info["year"] = year
        if vod_info.get("duration_secs"):
            info["duration"] = int(vod_info["duration_secs"])

        return info

    @use_router_cache("auth", expire_sec=6 * 60 * 60)
    def authenticate(self) -> bool:
        """Authenticate against the provider (cached 6h to limit server load)."""
        return self.xt.authenticate()

    def load_iptv2(self, stream_types: List[str]) -> dict:
        """Load categories and streams for the given stream types."""
        if not self.authenticate():
            log(f"cannot authenticate on {self.name}")

        result = {}
        for stream_type in stream_types:
            cats = self._load_categories(stream_type)
            streams = self._load_streams(stream_type)
            result[stream_type] = (cats, streams)

        return result

    @use_router_cache("categories", expire_sec=24 * 60 * 60)
    def _load_categories(self, stream_type: str) -> list:
        """Load and cache categories for a stream type (24h)."""
        return self.xt.load_categories(stream_type)

    @use_router_cache("streams", expire_sec=24 * 60 * 60)
    def _load_streams(self, stream_type: str) -> list:
        """Load and cache streams for a stream type (24h)."""
        return self.xt.load_streams(stream_type)

    @use_router_cache("epg", expire_sec=24 * 60 * 60)
    def get_stream_epg(self, stream_id) -> dict:
        """Load and cache EPG for a stream id (24h)."""
        return self.xt.get_epg(stream_id)

    @use_router_cache("vod_info", expire_sec=-1)
    def get_vod_info(self, stream_id) -> dict:
        """Load and cache VOD info for a movie (never expires)."""
        return self.xt.get_vod_info(stream_id).get("info") or {}

    @use_router_cache("series_info", expire_sec=-1)
    def get_series_info(self, series_id) -> dict:
        """Load and cache series info (never expires)."""
        return self.xt.get_series_info(series_id)

    def _get_xmltv_cached(self) -> str:
        """Fetch the bulk XMLTV EPG, cached on disk for 12h.

        xmltv.php is a large payload (~tens of MB) and IPTV Manager triggers
        a refresh at every boot; serving it from disk avoids hammering the
        provider server. The raw XML is stored as-is (not JSON-encoded).
        """
        import os
        import time

        from tv_common.utils.cache import _cache_folder

        cache_dir = _cache_folder("providers")
        cache_file = os.path.join(cache_dir, f"{self.name}_xmltv.xml")

        try:
            if os.path.exists(cache_file) and time.time() - os.path.getmtime(cache_file) < 12 * 60 * 60:
                with open(cache_file, encoding="utf-8") as f:
                    return f.read()
        except OSError as e:
            log(f"cannot read xmltv cache: {e}", xbmc.LOGWARNING)

        xmltv = self.xt.get_xmltv()
        if not xmltv:
            return ""

        try:
            os.makedirs(cache_dir, exist_ok=True)
            with open(cache_file, "w", encoding="utf-8") as f:
                f.write(xmltv)
        except OSError as e:
            log(f"cannot write xmltv cache: {e}", xbmc.LOGWARNING)

        return xmltv

    def _strip_xmltv_envelope(self, xmltv: str) -> str:
        """Strip <?xml...>, <!DOCTYPE...> and outer <tv> / </tv> tags.

        IPTV Manager already opens and closes <tv>...</tv> with its own XML
        declaration; embedding a complete XML document inside another <tv>
        element creates invalid nested XML that pvr.iptvsimple rejects.
        """
        import re

        xmltv = xmltv.lstrip("\ufeff")
        xmltv = re.sub(r"<\?xml[^>]*\?>", "", xmltv, flags=re.IGNORECASE)
        xmltv = re.sub(r"<!DOCTYPE[^>]*>", "", xmltv, flags=re.IGNORECASE)
        xmltv = re.sub(r"<tv\b[^>]*>", "", xmltv, flags=re.IGNORECASE)
        xmltv = re.sub(r"</tv\s*>", "", xmltv, flags=re.IGNORECASE)
        return xmltv.strip()

    def _get_container_extension(self, stream_type: str, stream_id: int) -> Optional[str]:
        """Get the container extension for a live stream."""
        try:
            stream_id = int(stream_id)
        except (TypeError, ValueError):
            return None
        cats, streams = self.load_iptv2([stream_type])[stream_type]
        stream = self.xt.filter_streams(param="stream_id", value=stream_id, streams=streams)
        return stream[0].get("container_extension") if stream else None