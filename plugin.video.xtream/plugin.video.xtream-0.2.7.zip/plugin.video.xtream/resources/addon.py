"""Addon entry point."""

import os
import sys
import time

import lib.routes  # noqa: F401  (enregistre les routes sur lib.router.router)
import xbmc
import xbmcvfs
from lib.router import router
from tv_common.utils.cache import cleanup_cache
from tv_common.utils.kodi import get_addon_info, log
from tv_common.utils.routing import init_router

_CLEANUP_INTERVAL_SEC = 24 * 60 * 60


def _maybe_cleanup_cache() -> None:
    """Run cache cleanup at most once a day (addon is invoked on every navigation)."""
    marker = os.path.join(xbmcvfs.translatePath(get_addon_info("profile")), "cache", ".last_cleanup")
    try:
        if os.path.exists(marker) and time.time() - os.path.getmtime(marker) < _CLEANUP_INTERVAL_SEC:
            return
        removed = cleanup_cache()
        if removed:
            log(f"cache cleanup: removed {removed} stale file(s)", xbmc.LOGINFO)
        with open(marker, "w", encoding="utf-8") as f:
            f.write(str(time.time()))
    except OSError as e:
        log(f"cache cleanup skipped: {e}", xbmc.LOGWARNING)


if __name__ == "__main__":
    log(sys.version, xbmc.LOGDEBUG)
    _maybe_cleanup_cache()
    init_router(router)
