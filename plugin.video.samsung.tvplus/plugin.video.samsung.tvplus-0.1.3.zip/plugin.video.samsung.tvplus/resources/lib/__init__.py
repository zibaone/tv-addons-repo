"""Samsung TV Plus resources."""
