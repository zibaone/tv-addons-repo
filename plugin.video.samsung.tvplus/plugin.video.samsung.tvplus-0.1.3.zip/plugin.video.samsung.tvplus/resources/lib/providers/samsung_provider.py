"""Samsung TV Plus provider (FAST gratuit, HLS clair)."""

import gzip
import json
from datetime import datetime, timezone
from io import BytesIO
from typing import Dict, List, Union

import requests
from tv_common.abstract_provider import AbstractProvider
from tv_common.utils.cache import cached
from tv_common.utils.kodi import build_addon_url, get_addon_setting, log
from tv_common.utils.routing import dispatch_by_depth, to_json_streams

_CHANNELS_URL = "https://i.mjh.nz/SamsungTVPlus/.channels.json.gz"
_PLAYBACK_URL_TMPL = "https://jmp2.uk/stvp-{id}"
_DEFAULT_REGION = "fr"
_TIMEOUT = 15
_STREAM_HEADERS = {
    "User-Agent": (
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
        "AppleWebKit/537.36 (KHTML, like Gecko) Chrome/125.0.0.0 Safari/537.36"
    )
}


class SamsungProvider(AbstractProvider):
    """Provider for Samsung TV Plus FAST channels (France by default)."""

    name = "samsungtvplus"

    def __init__(self, region: str | None = None):
        """Initialize provider.

        Region is read from Kodi settings (samsung.region) when not passed
        explicitly — this keeps unit tests hermetic while production reads the
        setting.
        """
        self.region = (region or get_addon_setting("samsung.region") or _DEFAULT_REGION).lower()
        self.session = requests.Session()
        self.session.headers.update(
            {
                "User-Agent": "okhttp/4.12.0",
                "Accept": "application/json, */*",
            }
        )

    # -- internal helpers ----------------------------------------------------

    @cached("samsung_channels", expire_sec=6 * 60 * 60)
    def _load_data(self) -> dict:
        """Fetch and decompress the global channels JSON (cached 6h)."""
        resp = self.session.get(_CHANNELS_URL, timeout=_TIMEOUT)
        resp.raise_for_status()
        data = json.loads(gzip.GzipFile(fileobj=BytesIO(resp.content)).read().decode("utf-8"))
        return data

    def _region_channels(self) -> Dict[str, dict]:
        """Return the {id: channel} dict for the configured region."""
        data = self._load_data()
        regions = data.get("regions") or {}
        region_data = regions.get(self.region) or regions.get(_DEFAULT_REGION) or {}
        channels = region_data.get("channels") or {}
        # Skip DRM-licensed channels (clear HLS only)
        return {cid: ch for cid, ch in channels.items() if not ch.get("license_url")}

    def _resolve_hls(self, stream_id: str) -> str:
        """Resolve jmp2.uk short URL to final HLS m3u8.

        Follows the 302 redirect without downloading the playlist. Falls back
        to the short URL itself if the redirect fails (Kodi can still follow
        it at playback time).
        """
        short = _PLAYBACK_URL_TMPL.format(id=stream_id)
        try:
            resp = self.session.head(short, allow_redirects=False, timeout=_TIMEOUT)
            loc = resp.headers.get("Location")
            if loc:
                return loc
            resp = self.session.get(short, allow_redirects=False, timeout=_TIMEOUT)
            loc = resp.headers.get("Location")
            if loc:
                return loc
        except requests.RequestException as e:
            log(f"Samsung HLS resolve failed for {stream_id}: {e}")
        return short

    # -- AbstractProvider ----------------------------------------------------

    def get_live_stream_info(self, stream_id: str) -> dict:
        """Return HLS stream info for a live channel."""
        path = self._resolve_hls(stream_id)
        return {
            "path": path,
            "protocol": "hls",
            "mime_type": "application/vnd.apple.mpegurl",
            "headers": dict(_STREAM_HEADERS),
        }

    def get_catchup_stream_info(self, stream_id: str) -> dict:
        """Catchup reuses live HLS (FAST has no VOD)."""
        return self.get_live_stream_info(stream_id)

    def get_streams(self) -> list:
        """Return JSON-STREAMS list for IPTV Manager / Kodi."""
        channels = self._region_channels()
        items = [{"_id": cid, **ch} for cid, ch in channels.items()]
        items.sort(key=lambda c: c.get("chno", 0))
        return to_json_streams(
            items,
            {
                "id": lambda c: c["_id"],
                "name": lambda c: c.get("name", c["_id"]),
                "preset": lambda c: c.get("chno", 0),
                "logo": lambda c: c.get("logo", ""),
                "stream": lambda c: build_addon_url(f"/stream/live/{c['_id']}"),
                "group": lambda c: [c.get("group", "Samsung TV Plus")],
            },
        )

    def get_epg(self) -> Union[str, dict]:
        """Return JSON-EPG dict built from channel programs.

        Each channel's ``programs`` is a list of [unix_ts, title]. We expand
        it into {start, stop, title, description} entries. Stop is the next
        program's start; last program gets +1h.
        """
        channels = self._region_channels()
        epg: Dict[str, list] = {}
        for cid, ch in channels.items():
            programs = ch.get("programs") or []
            if not programs:
                continue
            entries = []
            for idx, prog in enumerate(programs):
                if not isinstance(prog, (list, tuple)) or len(prog) < 2:
                    continue
                start_ts, title = prog[0], prog[1]
                try:
                    start_dt = datetime.fromtimestamp(int(start_ts), tz=timezone.utc).astimezone()
                    start = start_dt.replace(microsecond=0).isoformat()
                except (ValueError, OSError, OverflowError):
                    continue
                if idx + 1 < len(programs) and isinstance(programs[idx + 1], (list, tuple)):
                    try:
                        stop_ts = int(programs[idx + 1][0])
                        stop_dt = datetime.fromtimestamp(stop_ts, tz=timezone.utc).astimezone()
                        stop = stop_dt.replace(microsecond=0).isoformat()
                    except (ValueError, OSError, OverflowError):
                        stop = ""
                else:
                    try:
                        stop_dt = datetime.fromtimestamp(int(start_ts) + 3600, tz=timezone.utc).astimezone()
                        stop = stop_dt.replace(microsecond=0).isoformat()
                    except (ValueError, OSError, OverflowError):
                        stop = ""
                entries.append(
                    {
                        "start": start,
                        "stop": stop,
                        "title": str(title),
                        "description": ch.get("description", ""),
                    }
                )
            if entries:
                epg[cid] = entries
        return epg

    def get_catchup_items(self, levels: List[str]) -> list:
        """2-level navigation: categories (groups) -> channels."""
        getters = [
            self._get_catchup_0,
            self._get_catchup_1,
        ]
        return dispatch_by_depth(getters, levels)

    def _get_catchup_0(self) -> list:
        """Root: list groups (categories)."""
        channels = self._region_channels()
        groups: Dict[str, int] = {}
        for ch in channels.values():
            g = ch.get("group") or "Autres"
            groups[g] = groups.get(g, 0) + 1
        items = []
        for group in sorted(groups):
            items.append(
                {
                    "is_folder": True,
                    "label": f"{group} ({groups[group]})",
                    "path": build_addon_url(f"/catchup/{group}"),
                    "art": {},
                    "info": {"title": group, "plot": f"{groups[group]} chaînes"},
                }
            )
        return items

    def _get_catchup_1(self, group: str) -> list:
        """Second level: channels in a group."""
        import urllib.parse

        group_decoded = urllib.parse.unquote(group)
        channels = self._region_channels()
        items = []
        for cid, ch in channels.items():
            g = ch.get("group") or "Autres"
            if g != group_decoded and g != group:
                continue
            items.append(
                {
                    "is_folder": False,
                    "label": ch.get("name", cid),
                    "path": build_addon_url(f"/stream/live/{cid}"),
                    "art": {"thumb": ch.get("logo", ""), "poster": ch.get("logo", "")},
                    "info": {
                        "title": ch.get("name", cid),
                        "plot": ch.get("description", ""),
                    },
                }
            )
        items.sort(key=lambda x: x["label"])
        return items
