"""Samsung TV Plus provider selection."""

from tv_common.abstract_provider import AbstractProvider

from .samsung_provider import SamsungProvider

_PROVIDER = SamsungProvider()


def get_provider() -> AbstractProvider:
    """Return the Samsung TV Plus provider."""
    return _PROVIDER
