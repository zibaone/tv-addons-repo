"""Addon routes."""


import xbmc
from tv_common.managers import CatchupManager, IPTVManager, StreamManager
from tv_common.utils.kodi import log

from lib.providers import get_provider
from lib.router import router


@router.route("/")
def index():
    """Display catchup service index."""
    log("Display catchup index", xbmc.LOGINFO)
    CatchupManager(get_provider(), router.handle).build_directory()


@router.route("/library/sources/sync")
@router.route("/library/sources/add")
def add_library_sources():
    """Add or synchronize Samsung TV Plus sources in Kodi's sources.xml."""
    from tv_common.utils.kodi import build_addon_url
    from tv_common.utils.sources import sync_sources_from_mode

    def _get_sources(mode_idx: int):
        sources = []
        if mode_idx in (0, 1, 2):
            sources.append({
                "name": "Samsung TV Plus - Chaînes",
                "path": build_addon_url("/catchup/all"),
            })
        return sources

    sync_sources_from_mode(
        addon_id="plugin.video.samsung.tvplus",
        addon_name="Samsung TV Plus",
        get_sources_fn=_get_sources,
        is_disabled_fn=lambda mode: mode == 3,
        mode_names=["Navigation", "Médiathèque", "Développeur", "Désactivé"],
    )


@router.route("/catchup/<path:levels>")

def catchup_directory(levels: str):
    """Display catchup service directory."""
    log(f"Display catchup directory {levels}", xbmc.LOGINFO)
    CatchupManager(get_provider(), router.handle).build_directory(levels)


@router.route("/stream/live/<stream_id>")
def stream_live(stream_id: str):
    """Load live stream for the required channel id."""
    log(f"Loading live stream {stream_id}", xbmc.LOGINFO)
    StreamManager(get_provider(), router.handle, router.args).load_live_stream(stream_id)


@router.route("/stream/catchup/<stream_id>")
def stream_catchup(stream_id: str):
    """Load catchup stream for the required video id."""
    log(f"Loading catchup stream {stream_id}", xbmc.LOGINFO)
    StreamManager(get_provider(), router.handle, router.args).load_catchup_stream(stream_id)


@router.route("/iptv/channels")
def iptv_channels():
    """Return JSON-STREAMS formatted data for all live channels."""
    log("Loading channels for IPTV Manager", xbmc.LOGINFO)
    port = int(router.args.get("port")[0])
    IPTVManager(port, get_provider()).send_channels()


@router.route("/iptv/epg")
def iptv_epg():
    """Return JSON-EPG formatted data for all live channel EPG data."""
    log("Loading EPG for IPTV Manager", xbmc.LOGINFO)
    port = int(router.args.get("port")[0])
    IPTVManager(port, get_provider()).send_epg()
