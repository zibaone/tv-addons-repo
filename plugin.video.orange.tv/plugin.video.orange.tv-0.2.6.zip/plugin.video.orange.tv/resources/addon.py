"""Addon entry point."""

import contextlib
import os
import sys
import time

import lib.routes  # noqa: F401  (enregistre les routes sur lib.router.router)
import xbmc
import xbmcvfs
from lib.router import router
from tv_common.utils.cache import cleanup_cache
from tv_common.utils.kodi import get_addon_info, get_addon_setting, log, set_addon_setting
from tv_common.utils.routing import init_router


def _sanitize_settings() -> None:
    """Fix corrupted settings due to type mismatches (e.g. after rename/migration)."""
    settings = {
        "iptv.channels_uri": "plugin://plugin.video.orange.tv/iptv/channels",
        "iptv.epg_uri": "plugin://plugin.video.orange.tv/iptv/epg",
    }
    for key, default in settings.items():
        try:
            curr = None
            with contextlib.suppress(Exception):
                curr = get_addon_setting(key, str)
            if curr != default:
                set_addon_setting(key, default)
                log(f"sanitized setting {key}", xbmc.LOGINFO)
        except Exception as e:
            log(f"failed to sanitize {key}: {e}", xbmc.LOGERROR)


_CLEANUP_INTERVAL_SEC = 24 * 60 * 60


def _maybe_cleanup_cache() -> None:
    """Run cache cleanup at most once a day (addon is invoked on every navigation)."""
    marker = os.path.join(xbmcvfs.translatePath(get_addon_info("profile")), "cache", ".last_cleanup")
    try:
        if os.path.exists(marker) and time.time() - os.path.getmtime(marker) < _CLEANUP_INTERVAL_SEC:
            return
        removed = cleanup_cache()
        if removed:
            log(f"cache cleanup: removed {removed} stale file(s)", xbmc.LOGINFO)
        with open(marker, "w", encoding="utf-8") as f:
            f.write(str(time.time()))
    except OSError as e:
        log(f"cache cleanup skipped: {e}", xbmc.LOGWARNING)


if __name__ == "__main__":
    _sanitize_settings()
    log(sys.version, xbmc.LOGDEBUG)
    _maybe_cleanup_cache()
    init_router(router)
