# ruff: noqa: D102
"""Orange provider template."""

import base64
import json
import re
from abc import ABC
from datetime import date, datetime, timedelta, timezone
from time import strptime
from typing import List, Optional
from urllib.parse import urlencode

import xbmc
from requests import Session
from requests.exceptions import JSONDecodeError, RequestException
from tv_common.abstract_provider import AbstractProvider
from tv_common.exceptions import (
    AuthenticationRequired,
    StreamDataDecodeError,
    StreamNotIncluded,
    StreamRequestException,
)
from tv_common.utils.cache import use_router_cache
from tv_common.utils.kodi import build_addon_url, get_addon_setting, get_drm, get_global_setting, log, set_addon_setting
from tv_common.utils.library import clean_library_title
from tv_common.utils.request import get_random_ua, network_backoff_active, request, request_json
from tv_common.utils.routing import dispatch_by_depth, to_json_streams

_PROGRAMS_ENDPOINT = "https://rp-ott-mediation-tv.woopic.com/api-gw/live/v3/applications/STB4PC/programs?period={period}&epgIds=all&mco={mco}"
_CATCHUP_CHANNELS_ENDPOINT = "https://rp-ott-mediation-tv.woopic.com/api-gw/catchup/v4/applications/PC/channels"
_CATCHUP_ARTICLES_ENDPOINT = "https://rp-ott-mediation-tv.woopic.com/api-gw/catchup/v4/applications/PC/channels/{channel_id}/categories/{category_id}"
_CATCHUP_VIDEOS_ENDPOINT = "https://rp-ott-mediation-tv.woopic.com/api-gw/catchup/v4/applications/PC/groups/{group_id}"
_CATCHUP_SINGLE_VIDEO_ENDPOINT = "https://rp-ott-mediation-tv.woopic.com/api-gw/catchup/v4/applications/PC/videos/{video_id}"
_CHANNELS_ENDPOINT = "https://rp-ott-mediation-tv.woopic.com/api-gw/pds/v1/live/ew?everywherePopulation=OTT_Metro"

_LIVE_STREAM_ENDPOINT = "https://mediation-tv.orange.fr/all/api-gw/stream/v2/auth/accountToken/live/{stream_id}?deviceModel=WEB_PC&customerOrangePopulation=OTT_Metro"
_CATCHUP_STREAM_ENDPOINT = "https://mediation-tv.orange.fr/all/api-gw/catchup/v4/auth/accountToken/applications/PC/videos/{stream_id}/stream?terminalModel=WEB_PC&terminalId="

_STREAM_LOGO_URL = "https://proxymedia.woopic.com/api/v1/images/2090{path}"
_HOMEPAGE_URL = "https://tv.orange.fr/"
_LOGIN_URL = "https://login.orange.fr"

_INIT_RIGHTS_ENDPOINT = "https://mediation-tv.orange.fr/all/api-gw/init-ew/v1/auth/right?terminalModel=WEB_PC"
_LICENSE_ENDPOINT = "https://mediation-tv.orange.fr/all/api-gw/license/v1/auth/accountToken"


class AbstractOrangeProvider(AbstractProvider, ABC):
    """Abstract Orange Provider."""

    chunks_per_day = 2
    mco = "OFR"
    groups = {}
    _session: Optional[Session] = None

    def get_live_stream_info(self, stream_id: str) -> dict:
        """Get live stream info."""
        return self._get_stream_info(_LIVE_STREAM_ENDPOINT, stream_id)

    def get_catchup_stream_info(self, stream_id: str) -> dict:
        """Get catchup stream info."""
        return self._get_stream_info(_CATCHUP_STREAM_ENDPOINT, stream_id)

    def get_streams(self) -> list:
        """Load stream data from Orange and convert it to JSON-STREAMS format.

        Channels the subscription does not include (detected from the
        packages intersection, no extra API call) are filtered out unless
        the "provider.show_not_included" setting is enabled.
        """
        channels = request_json(_CHANNELS_ENDPOINT, default={"channels": {}}).get("channels") or []
        channels.sort(key=lambda channel: channel["displayOrder"])

        account_packages = self._get_account_packages()
        hide_not_included = not get_addon_setting("provider.show_not_included", bool)
        if account_packages and hide_not_included:
            included = [c for c in channels if self._is_channel_included(c, account_packages)]
            excluded = len(channels) - len(included)
            if excluded:
                log(f"{excluded} channels not in subscription, hidden", xbmc.LOGINFO)
            channels = included

        log(f"{len(channels)} channels found", xbmc.LOGINFO)

        return to_json_streams(
            channels,
            {
                "id": lambda c: c["idEPG"],
                "name": lambda c: c["name"],
                "preset": lambda c: c["displayOrder"],
                "logo": lambda c: self._extract_logo(c["logos"]),
                "stream": lambda c: build_addon_url(f"/stream/live/{self._get_channel_live_id(c)}"),
                "group": lambda c: [
                    group_name for group_name in self.groups if int(c["idEPG"]) in self.groups[group_name]
                ],
            },
        )

    def _get_account_packages(self) -> Optional[set]:
        """Return the subscription package codes, or None if unknown.

        The packages are fetched once per session in _refresh_session_data
        (from the same init-rights call that provides the tv_token), so this
        costs no extra request unless the stored session predates the
        packages field (then a single refresh is performed; afterwards the
        packages are persisted and no further refresh happens).
        """
        session_data = get_addon_setting("provider.session_data", dict)
        packages = session_data.get("packages") or []
        previous = session_data.get("packages_previous") or []

        if not packages:
            try:
                session_data = self._refresh_session_data(self._get_session(), datetime.now(timezone.utc))
                packages = session_data.get("packages") or []
            except StreamRequestException:
                return None

        # Notify when new subscription packages appear (subscription change,
        # trial period activated, etc.) — only once per new package.
        if previous and packages:
            new_packages = set(packages) - set(previous)
            if new_packages:
                self._notify_new_packages(new_packages)

        session_data["packages_previous"] = packages
        set_addon_setting("provider.session_data", dict(session_data))

        return set(packages) if packages else None

    @staticmethod
    def _notify_new_packages(new_packages: set) -> None:
        """Show a Kodi notification listing newly available packages."""
        import xbmcgui

        names = ", ".join(sorted(new_packages))
        log(f"new subscription packages detected: {names}", xbmc.LOGINFO)
        xbmcgui.Dialog().notification(
            "Orange TV",
            f"Nouvelles chaînes disponibles !\n{names}",
            xbmcgui.NOTIFICATION_INFO,
            6000,
        )

    def _is_channel_included(self, channel: dict, account_packages: set) -> bool:
        """Return True when the channel is part of the subscription.

        A channel lists the packages that grant access to it; it is included
        when any of them intersects the account packages. Channels without a
        packages field (or with only PI_WHITELIST) are kept.
        """
        required = {p for p in (channel.get("packages") or []) if p != "PI_WHITELIST"}
        return not required or bool(required & account_packages)

    def get_epg(self) -> dict:
        """Load EPG data from Orange and convert it to JSON-EPG format."""
        past_days_to_display = get_global_setting("epg.pastdaystodisplay", int)
        future_days_to_display = get_global_setting("epg.futuredaystodisplay", int)

        start_day = datetime.combine(date.today() - timedelta(days=past_days_to_display), datetime.min.time())
        days_to_display = past_days_to_display + future_days_to_display

        programs = self._get_programs(start_day, days_to_display, self.chunks_per_day, self.mco)
        log(f"{len(programs)} EPG entries found", xbmc.LOGINFO)

        epg = {}

        for program in programs:
            channel_id = str(program.get("channelId", ""))
            if not channel_id:
                continue
            if channel_id not in epg:
                epg[channel_id] = []

            if program["programType"] != "EPISODE":
                title = program["title"]
                subtitle = None
                episode = None
            else:
                title = program["season"]["serie"]["title"]
                subtitle = program["title"]
                season_number = program["season"]["number"]
                episode_number = program.get("episodeNumber", None)
                episode = f"S{season_number}E{episode_number}"

            image = None
            if isinstance(program["covers"], list):
                for cover in program["covers"]:
                    if cover["format"] == "RATIO_16_9":
                        image = cover["url"]

            start = datetime.fromtimestamp(program["diffusionDate"]).astimezone().replace(microsecond=0).isoformat()
            stop = datetime.fromtimestamp(program["diffusionDate"] + program["duration"]).astimezone().replace(microsecond=0).isoformat()  # noqa: E501

            epg[channel_id].append(
                {
                    "start": start,
                    "stop": stop,
                    "title": title,
                    "subtitle": subtitle,
                    "episode": episode,
                    "description": program["synopsis"],
                    "genre": program["genre"] if program["genreDetailed"] is None else program["genreDetailed"],
                    "image": image,
                }
            )

        return epg

    def get_catchup_items(self, levels: List[str]) -> list:
        """Return a list of directory items for the specified levels."""
        if levels and levels[0] == "genre" and len(levels) >= 2:
            genre = levels[1]
            return self.get_genre_flat_items(genre)
        if levels and levels[0] == "channels":
            return self._get_catchup_channels()

        item_getters = [
            self._get_catchup_channels,
            self._get_catchup_categories,
            self._get_catchup_articles,
            self._get_catchup_videos,
        ]
        return dispatch_by_depth(item_getters, levels)

    def get_category_name(self, levels: List[str]) -> Optional[str]:
        """Return breadcrumb category name for given navigation levels."""
        if not levels:
            return "Replay"
        if levels[0] == "channels":
            return "Chaînes"
        if levels[0] == "genre":
            if len(levels) >= 2:
                genre_map = {
                    "films": "Films",
                    "series": "Séries",
                    "documentaires": "Documentaires",
                }
                return genre_map.get(levels[1].lower(), levels[1].title())
            return "Genres"

        channel_id = levels[0]
        try:
            channel = self._load_catchup_channel_data(channel_id)
        except Exception:
            channel = {}

        ch_name = channel.get("name") or channel.get("label") or channel_id
        ch_name = str(ch_name).upper()

        if len(levels) == 1:
            return ch_name

        category_id = levels[1]
        categories = channel.get("categories") or []
        cat_name = ""
        for c in categories:
            if isinstance(c, dict) and str(c.get("id")) == str(category_id):
                raw_name = str(c.get("name") or "")
                cat_name = (raw_name[0].upper() + raw_name[1:]) if raw_name else ""
                break

        if not cat_name and category_id == "all":
            cat_name = "Tous les programmes"
        elif not cat_name:
            cat_name = category_id.replace("_", " ").title()

        if len(levels) == 2:
            return f"{ch_name} > {cat_name}"

        article_id = levels[2]
        articles = channel.get("articles") or []
        art_title = ""
        for a in articles:
            if isinstance(a, dict) and str(a.get("id")) == str(article_id):
                art_title = str(a.get("title") or a.get("longTitle") or "")
                break
        if not art_title:
            art_title = article_id.replace("_", " ").title()

        return f"{ch_name} > {cat_name} > {art_title}"

    @use_router_cache("genre_categories", expire_sec=2 * 60 * 60)
    def _find_genre_categories(self, genre: str) -> list:
        """Find matching channel categories for a given genre across all catchup channels."""
        genre_keywords = {
            "films": ("film", "cinéma", "cinema"),
            "series": ("série", "serie", "fiction"),
            "documentaires": ("documentaire", "doc", "découverte", "decouverte", "magazine"),
        }
        keywords = genre_keywords.get(genre, ())
        if not keywords:
            return []

        channels = self._load_catchup_channels()
        account_packages = self._get_account_packages()
        show_not_included = get_addon_setting("provider.show_not_included", bool)

        matching = []
        for channel in channels:
            if not isinstance(channel, dict) or not channel.get("id"):
                continue
            if account_packages and not show_not_included and not self._is_channel_included(channel, account_packages):
                continue

            ch_id = str(channel["id"])
            ch_name = str(channel.get("name") or "").upper()
            logos = channel.get("logos") if isinstance(channel.get("logos"), dict) else {}
            ch_art = {"thumb": logos.get("ref_millenials_partner_white_logo", "")}

            ch_data = self._load_catchup_channel_data(ch_id)
            categories = ch_data.get("categories") or []
            if not isinstance(categories, list):
                continue

            for cat in categories:
                if not isinstance(cat, dict) or not cat.get("id"):
                    continue
                cat_name = str(cat.get("name") or "")
                cat_lower = cat_name.lower()
                if any(kw in cat_lower for kw in keywords):
                    matching.append({
                        "channel_id": ch_id,
                        "channel_name": ch_name,
                        "category_id": str(cat["id"]),
                        "category_name": cat_name,
                        "art": ch_art,
                    })

        return matching

    def get_genre_categories(self, genre: str) -> list:
        """Return directory items for a genre: flat link + channel category subfolders."""
        type_map = {"films": "movies", "series": "tvshows", "documentaires": "videos"}
        icon_map = {"films": "🎬", "series": "📺", "documentaires": "🌍"}
        content_type = type_map.get(genre, "videos")
        icon = icon_map.get(genre, "📁")

        matching = self._find_genre_categories(genre)
        items = [
            {
                "is_folder": True,
                "label": f"{icon} Tous les {genre} (à plat)",
                "path": build_addon_url(f"/catchup/genre/{genre}/all"),
                "content_type": content_type,
            }
        ]

        for m in matching:
            items.append({
                "is_folder": True,
                "label": f"{m['channel_name']} — {m['category_name']}",
                "path": build_addon_url(f"/catchup/{m['channel_id']}/{m['category_id']}"),
                "content_type": content_type,
                "art": m.get("art", {}),
                "context_menu": [
                    (
                        "🔍 Rechercher dans cette chaîne...",
                        f"Container.Update({build_addon_url('/search/' + str(m['channel_id']))})",
                    ),
                ],
            })

        return items

    @use_router_cache("genre_flat_items", expire_sec=60 * 60)
    def get_genre_flat_items(self, genre: str) -> list:
        """Return all articles across channels for this genre as a flat directory list."""
        matching = self._find_genre_categories(genre)
        all_items = []
        for m in matching:
            ch_id = m["channel_id"]
            cat_id = m["category_id"]
            articles = self._load_catchup_category_articles(ch_id, cat_id)
            formatted = self._format_catchup_articles(ch_id, cat_id, articles)
            all_items.extend(formatted)
        return all_items

    def search_genre(self, genre: str, query: str) -> list:
        """Search articles in a specific genre matching query."""
        if not query:
            return []
        items = self.get_genre_flat_items(genre)
        query_lower = query.lower().strip()
        matched = []
        for item in items:
            label = str(item.get("label") or "").lower()
            info = item.get("info") or {}
            title = str(info.get("title") or "").lower()
            plot = str(info.get("plot") or "").lower()
            if query_lower in label or query_lower in title or query_lower in plot:
                matched.append(item)
        return matched

    @use_router_cache("catchup_channels", expire_sec=2 * 60 * 60)
    def _load_catchup_channels(self) -> list:
        """Fetch raw catchup channels from Orange API."""
        return request_json(_CATCHUP_CHANNELS_ENDPOINT, default=[])

    @use_router_cache("catchup_channel_data", expire_sec=2 * 60 * 60)
    def _load_catchup_channel_data(self, channel_id: str) -> dict:
        """Fetch raw catchup channel categories and articles from Orange API."""
        url = f"https://rp-ott-mediation-tv.woopic.com/api-gw/catchup/v4/applications/PC/channels/{channel_id}"
        channel = request_json(url, default={})
        if isinstance(channel, list):
            channel = channel[0] if channel else {}
        return channel if isinstance(channel, dict) else {}

    def _get_catchup_channels(self) -> list:
        """Load available catchup channels.

        Channels the subscription does not include (detected from the
        packages field, same mechanism as live) are hidden — this avoids
        showing replay folders for premium channels the user cannot watch.
        """
        channels = self._load_catchup_channels()
        account_packages = self._get_account_packages()
        show_not_included = get_addon_setting("provider.show_not_included", bool)

        result = []
        hidden = 0
        for channel in channels:
            if account_packages and not show_not_included and not self._is_channel_included(channel, account_packages):
                hidden += 1
                continue
            ch_id = channel["id"]
            logos = channel.get("logos") if isinstance(channel.get("logos"), dict) else {}
            thumb = logos.get("ref_millenials_partner_white_logo", "")
            result.append(
                {
                    "is_folder": True,
                    "label": str(channel["name"]).upper(),
                    "path": build_addon_url(f"/catchup/{ch_id}"),
                    "art": {"thumb": thumb},
                    "context_menu": [
                        (
                            "🔍 Rechercher dans cette chaîne...",
                            f"Container.Update({build_addon_url(f'/search/{ch_id}')})",
                        ),
                        (
                            "📁 Ajouter les replays aux sources Kodi",
                            f"RunPlugin({build_addon_url('/library/sources/add')})",
                        ),
                    ],
                }
            )

        if hidden:
            log(f"{hidden} catchup channels not in subscription, hidden", xbmc.LOGINFO)

        return result

    def _get_catchup_categories(self, channel_id: str) -> list:
        """Return a list of catchup categories for the specified channel id."""
        channel = self._load_catchup_channel_data(channel_id)
        categories = channel.get("categories") or []
        if not isinstance(categories, list):
            categories = []
        result = []
        for category in categories:
            if not isinstance(category, dict) or not category.get("id"):
                continue
            name = str(category.get("name") or "")
            label = (name[0].upper() + name[1:]) if name else "Autres"
            result.append(
                {
                    "is_folder": True,
                    "label": label,
                    "path": build_addon_url(f"/catchup/{channel_id}/{category['id']}"),
                    "context_menu": [
                        (
                            "🔍 Rechercher dans cette chaîne...",
                            f"Container.Update({build_addon_url(f'/search/{channel_id}')})",
                        ),
                    ],
                }
            )
        if result:
            return result

        # Fallback for channels without categories (articles attached directly to channel)
        articles = channel.get("articles") or []
        if isinstance(articles, list) and articles:
            return self._format_catchup_articles(channel_id, "all", articles)

        return []

    def _build_catchup_video_item(self, video: dict, export_levels: list = None) -> dict:
        """Build a Kodi list item dict for a playable catchup video."""
        covers = video.get("covers") if isinstance(video.get("covers"), dict) else {}
        poster = covers.get("ref_16_9") or covers.get("ref_immersion") or ""
        thumb = covers.get("ref_immersion") or covers.get("ref_16_9") or ""

        duration_raw = video.get("duration")
        try:
            duration_sec = int(duration_raw) * 60 if duration_raw is not None else None
        except (TypeError, ValueError):
            duration_sec = None

        broadcast_raw = video.get("broadcastDate")
        premiered = ""
        if broadcast_raw:
            try:
                premiered = datetime.fromtimestamp(int(broadcast_raw) / 1000).strftime("%Y-%m-%d")
            except (TypeError, ValueError, OSError, OverflowError):
                premiered = ""

        genres = video.get("genres")
        if not isinstance(genres, list):
            genres = [str(genres)] if genres else []

        plot = video.get("longSummary") or video.get("shortSummary") or video.get("pitch") or ""

        title = video.get("longTitle") or video.get("title") or "Vidéo"
        stream_path = build_addon_url(f"/stream/catchup/{video['id']}?{urlencode({'title': title})}")

        season_num = video.get("seasonNumber")
        episode_num = video.get("episodeNumber")
        if not season_num:
            m_se = re.search(r"\bS(\d{1,2})\s*E(\d{1,3})\b", title, re.IGNORECASE)
            if m_se:
                season_num = int(m_se.group(1))
                episode_num = int(m_se.group(2))
            else:
                m_ep = re.search(r"\b(?:Ep|Episode|Épisode)\s*(\d{1,3})\b", title, re.IGNORECASE)
                if m_ep:
                    episode_num = int(m_ep.group(1))
                    season_num = 1
        elif isinstance(season_num, str) and season_num.isdigit():
            season_num = int(season_num)

        if isinstance(episode_num, str) and episode_num.isdigit():
            episode_num = int(episode_num)

        item = {
            "is_folder": False,
            "label": str(video.get("title") or "Vidéo"),
            "path": stream_path,
            "art": {
                "poster": poster,
                "thumb": thumb,
            },
            "info": {
                "title": title,
                "mediatype": "episode" if (season_num or episode_num) else "video",
                "duration": duration_sec,
                "genres": genres,
                "plot": plot,
                "premiered": premiered,
                "year": self._get_video_year(video),
                "season": season_num,
                "episode": episode_num,
            },
        }

        # Export .strm désactivé temporairement (en attente d'une source locale dédiée)
        # if export_levels:
        #     levels_str = "/".join(export_levels)
        #     item["context_menu"] = [("📥 Exporter ce replay", build_addon_url(f"/library/export/{levels_str}"))]

        trailer = video.get("trailer")
        if isinstance(trailer, str) and trailer:
            item["info"]["trailer"] = trailer

        cast = video.get("artists")
        if isinstance(cast, list) and cast:
            item["info"]["cast"] = [a for a in cast if isinstance(a, str)]
        elif isinstance(cast, dict):
            actors = []
            for role_artists in cast.values():
                if isinstance(role_artists, list):
                    for a in role_artists:
                        if isinstance(a, dict):
                            fn = a.get("firstName", "")
                            ln = a.get("lastName", "")
                            full = f"{fn} {ln}".strip()
                            if full:
                                actors.append(full)
                        elif isinstance(a, str) and a:
                            actors.append(a)
            if actors:
                item["info"]["cast"] = actors

        country = video.get("productionCountry")
        if isinstance(country, str) and country:
            item["info"]["country"] = [country]

        return item

    def _format_catchup_articles(self, channel_id: str, category_id: str, articles: list) -> list:
        """Format raw articles into playable items or group folders."""
        result = []
        for article in articles:
            if not isinstance(article, dict) or not article.get("id"):
                continue

            if article.get("articleType") == "VIDEO":
                result.append(self._build_catchup_video_item(article, [channel_id, category_id, article["id"]]))
            else:
                covers = article.get("covers") if isinstance(article.get("covers"), dict) else {}
                poster = covers.get("ref_16_9") or covers.get("ref_immersion") or ""
                raw_title = str(article.get("title") or "Sans titre")
                clean_name, extracted_year = clean_library_title(raw_title)
                result.append(
                    {
                        "is_folder": True,
                        "label": raw_title,
                        "path": build_addon_url(f"/catchup/{channel_id}/{category_id}/{article['id']}"),
                        "art": {"poster": poster},
                        "content_type": "tvshows",
                        "info": {
                            "title": clean_name or raw_title,
                            "mediatype": "tvshow",
                            "year": extracted_year,
                        },
                    }
                )
        return result

    @use_router_cache("catchup_category_articles", expire_sec=60 * 60)
    def _load_catchup_category_articles(self, channel_id: str, category_id: str) -> list:
        """Fetch raw articles for a given channel and category from Orange API."""
        if category_id == "all":
            channel = self._load_catchup_channel_data(channel_id)
            articles = channel.get("articles") or []
        else:
            url = _CATCHUP_ARTICLES_ENDPOINT.format(channel_id=channel_id, category_id=category_id)
            res = request_json(url, default={"articles": []})
            articles = res.get("articles") if isinstance(res, dict) else []
        return articles if isinstance(articles, list) else []

    @use_router_cache("catchup_group_videos", expire_sec=60 * 60)
    def _load_catchup_group_videos(self, article_id: str) -> list:
        """Fetch raw videos for a given group/article from Orange API."""
        url = _CATCHUP_VIDEOS_ENDPOINT.format(group_id=article_id)
        res = request_json(url, default={"videos": []})
        videos = res.get("videos") if isinstance(res, dict) else []
        if not videos:
            single_url = _CATCHUP_SINGLE_VIDEO_ENDPOINT.format(video_id=article_id)
            single = request_json(single_url, default={})
            if isinstance(single, dict) and single.get("id"):
                videos = [single]
        return videos if isinstance(videos, list) else []

    def _get_catchup_articles(self, channel_id: str, category_id: str) -> list:
        """Return a list of catchup groups or standalone videos for the specified channel and category."""
        articles = self._load_catchup_category_articles(channel_id, category_id)
        return self._format_catchup_articles(channel_id, category_id, articles)

    def _get_catchup_videos(self, channel_id: str, category_id: str, article_id: str) -> list:
        """Return a list of catchup videos for the specified channel id and article id."""
        videos = self._load_catchup_group_videos(article_id)
        levels = [channel_id, category_id, article_id]
        return [
            self._build_catchup_video_item(video, levels)
            for video in videos
            if isinstance(video, dict) and video.get("id")
        ]

    def search_channel_catchup(self, channel_id: str, query: str) -> list:
        """Search catchup articles in a channel matching query."""
        if not query:
            return []
        channel = self._load_catchup_channel_data(channel_id)
        categories = channel.get("categories") or []
        fallback_articles = channel.get("articles") or []

        all_articles = []
        if isinstance(categories, list) and categories:
            for cat in categories:
                if not isinstance(cat, dict) or not cat.get("id"):
                    continue
                cat_id = cat["id"]
                arts = self._load_catchup_category_articles(channel_id, cat_id)
                for a in arts:
                    if isinstance(a, dict):
                        a_copy = dict(a)
                        a_copy["_category_id"] = cat_id
                        all_articles.append(a_copy)
        elif isinstance(fallback_articles, list):
            for a in fallback_articles:
                if isinstance(a, dict):
                    a_copy = dict(a)
                    a_copy["_category_id"] = "all"
                    all_articles.append(a_copy)

        query_lower = query.lower().strip()
        matched = []
        seen_ids = set()
        for art in all_articles:
            aid = art.get("id")
            if not aid or aid in seen_ids:
                continue
            title = str(art.get("title") or "").lower()
            long_title = str(art.get("longTitle") or "").lower()
            summary = str(art.get("longSummary") or art.get("shortSummary") or "").lower()
            if query_lower in title or query_lower in long_title or query_lower in summary:
                seen_ids.add(aid)
                matched.append(art)

        formatted_items = []
        for art in matched:
            cat_id = art.get("_category_id", "all")
            formatted = self._format_catchup_articles(channel_id, cat_id, [art])
            formatted_items.extend(formatted)
        return formatted_items

    def _get_video_year(self, video: dict) -> int:
        """Return the production year of a video, falling back to its broadcast year."""
        production_date = video.get("productionDate")
        if production_date:
            try:
                return int(production_date)
            except (TypeError, ValueError):
                pass

        broadcast_date = video.get("broadcastDate")
        if broadcast_date:
            try:
                return datetime.fromtimestamp(int(broadcast_date) / 1000).year
            except (TypeError, ValueError, OSError, OverflowError):
                pass

        return 0

    def _get_session(self) -> Session:
        """Return the shared HTTP session (reused across calls).

        Reusing a session avoids churning TCP/TLS handshakes, which reads as
        scanning to the provider proxy.
        """
        if self._session is None:
            session = Session()
            session.headers = {
                "Accept": "application/xhtml+xml,application/xml",
                "Content-Type": "application/json",
                "User-Agent": get_random_ua(),
            }
            self._session = session
        return self._session

    def _get_stream_info(self, stream_endpoint: str, stream_id: str) -> dict:
        """Load stream info from Orange."""
        stream_endpoint_url = stream_endpoint.format(stream_id=stream_id)
        now = datetime.now(timezone.utc)
        session_data = get_addon_setting("provider.session_data", dict)

        session = self._get_session()

        if self._is_session_data_valid(session_data, now):
            try:
                stream_info = self._request_stream_info(stream_endpoint_url, session_data)
            except StreamRequestException:
                # Do not retry while the provider is rate-limiting us: the
                # backoff would fail anyway and only adds to the hammering.
                if network_backoff_active():
                    raise

                if get_addon_setting("provider.use_credentials", bool):
                    self._login(session)

                session_data = self._refresh_session_data(session, now)
                stream_info = self._request_stream_info(stream_endpoint_url, session_data)
            return stream_info

        if network_backoff_active():
            raise AuthenticationRequired("Cannot load stream data (network backoff active)")

        if get_addon_setting("provider.use_credentials", bool):
            self._login(session)

        session_data = self._refresh_session_data(session, now)
        stream_info = self._request_stream_info(stream_endpoint_url, session_data)

        return stream_info

    def _is_session_data_valid(self, session_data: dict, at: datetime = None) -> bool:
        """Check if session data is valid."""
        if not session_data.get("tv_token") or not session_data.get("wassup"):
            return False

        if at is None:
            at = datetime.now(timezone.utc)

        if not session_data.get("tv_token_expires") or at.timestamp() > session_data.get("tv_token_expires"):
            return False

        try:
            decoded_wassup = bytes.fromhex(session_data.get("wassup")).decode()
            xwvd = re.search(r"\|X_WASSUP_VALID_DATE=(.*?)\|", decoded_wassup).group(1)
            wassup_expires_at = datetime(*(strptime(xwvd, "%Y%m%d%H%M%S")[0:6])).replace(tzinfo=timezone.utc)
            return wassup_expires_at > at
        except (TypeError, AttributeError):
            return False

    def _refresh_session_data(self, session: Session, now: datetime) -> dict:
        """Fetch session data from Orange services."""
        try:
            request("GET", _HOMEPAGE_URL, session=session)
            response = request("GET", _INIT_RIGHTS_ENDPOINT, session=session, headers={"Accept": "application/json"})
            rights = response.json()
            session_data = {
                "tv_token": rights["tv_token"],
                "tv_token_expires": self._get_tv_token_expiry(rights["tv_token"], now),
                "wassup": session.cookies.get("wassup"),
                "packages": rights.get("packages") or [],
            }
        except RequestException as e:
            raise AuthenticationRequired("Cannot initiate new session (request failed)") from e
        except KeyError as e:
            raise AuthenticationRequired("Cannot initiate new session (tv token not found)") from e
        except JSONDecodeError as e:
            raise StreamDataDecodeError("Cannot initiate new session (tv token not loaded)") from e

        set_addon_setting("provider.session_data", dict(session_data))
        return session_data

    def _get_tv_token_expiry(self, tv_token: str, now: datetime) -> float:
        """Extract the tv_token expiry timestamp from its JWT payload."""
        try:
            _, payload, _ = tv_token.split(".")
            payload += "=" * (-len(payload) % 4)
            return json.loads(base64.urlsafe_b64decode(payload))["exp"]
        except (ValueError, KeyError, json.JSONDecodeError):
            return now.timestamp() + 30 * 60

    def _request_stream_info(self, stream_endpoint_url: str, session_data: dict) -> dict:
        """Load stream data from Orange."""
        try:
            headers = {
                "tv_token": f"Bearer {session_data.get('tv_token')}",
                "Cookie": f"wassup={session_data.get('wassup')}",
            }
            res = request("GET", stream_endpoint_url, headers=headers)
            stream = res.json()
        except RequestException as e:
            if e.response is not None and e.response.status_code == 403:
                raise StreamNotIncluded() from e
            else:
                raise AuthenticationRequired("Cannot load stream data") from e
        except JSONDecodeError as e:
            raise StreamDataDecodeError() from e

        return self._format_stream_info(stream, session_data)

    def _format_stream_info(self, stream: dict, session_data: dict) -> dict:
        """Compute stream info."""
        protectionData = stream.get("protectionData") or stream.get("protectionDatas")
        path = stream.get("streamURL") or stream.get("url")

        license_server_url = _LICENSE_ENDPOINT if stream.get("url") is None else ""

        for system in protectionData or []:
            if system.get("keySystem") == get_drm():
                license_server_url += system.get("laUrl")

        browser_ua = (
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
            "(KHTML, like Gecko) Chrome/123.0.0.0 Safari/537.36"
        )
        headers = {
            "User-Agent": browser_ua,
            "Referer": "https://chaines-tv.orange.fr/",
        }

        lic_headers = {
            "tv_token": f"Bearer {session_data.get('tv_token')}",
            "User-Agent": browser_ua,
            "Content-Type": "",
            "Cookie": f"wassup={session_data.get('wassup')}",
        }
        encoded_lic_headers = urlencode(lic_headers)
        license_key = "|".join(
            [
                license_server_url,
                encoded_lic_headers,
                "R{SSM}",
                "",
            ]
        )

        drm_config = {
            "license_type": get_drm(),
            "license_key": license_key,
        }
        if license_server_url:
            drm_config["drm_legacy"] = f"{get_drm()}|{license_server_url}|{encoded_lic_headers}"

        stream_info = {
            "path": path,
            "protocol": "mpd",
            "mime_type": "application/dash+xml",
            "headers": headers,
            "drm_config": drm_config,
        }

        log(stream_info, xbmc.LOGDEBUG)
        return stream_info

    def _login(self, session: Session):
        """Login to Orange."""
        try:
            data = json.dumps({})
            request("POST", f"{_LOGIN_URL}/api/access", data=data, session=session)
        except RequestException:
            log("Error while authenticating (init)", xbmc.LOGWARNING)
            return

        try:
            data = json.dumps({"login": get_addon_setting("provider.username"), "loginOrigin": "input"})
            request("POST", f"{_LOGIN_URL}/api/login", data=data, session=session)
        except RequestException:
            log("Error while authenticating (login)", xbmc.LOGWARNING)
            return

        try:
            data = json.dumps({"password": get_addon_setting("provider.password"), "remember": True})
            request("POST", f"{_LOGIN_URL}/api/password", data=data, session=session)
        except RequestException:
            log("Error while authenticating (password)", xbmc.LOGWARNING)

        if "wassup" not in session.cookies:
            log("Error while authenticating (wassup not found)", xbmc.LOGWARNING)

    def _get_channel_live_id(self, channel: dict) -> str:
        """Get live id for given channel."""
        return channel["technicalChannels"]["live"][0]["liveTargetURLRelativePath"]

    def _extract_logo(self, logos: list, definition_type: str = "mobileAppliDark") -> str:
        for logo in logos:
            if logo["definitionType"] == definition_type:
                return _STREAM_LOGO_URL.format(path=logo["listLogos"][0]["path"])

        return None

    def _get_programs(self, start_day: datetime, days_to_display: int, chunks_per_day: int, mco: str = "OFR") -> list:
        """Return the programs for today (default) or the specified period."""
        programs = []
        start_day_timestamp = start_day.timestamp()
        chunk_duration = 24 * 60 * 60 / chunks_per_day

        for chunk in range(0, days_to_display * chunks_per_day):
            period_start = (start_day_timestamp + chunk_duration * chunk) * 1000
            period_end = (start_day_timestamp + chunk_duration * (chunk + 1)) * 1000

            try:
                period = f"{int(period_start)},{int(period_end)}"
            except ValueError:
                period = "today"

            url = _PROGRAMS_ENDPOINT.format(period=period, mco=mco)
            programs.extend(request_json(url, default=[]))

        return programs
