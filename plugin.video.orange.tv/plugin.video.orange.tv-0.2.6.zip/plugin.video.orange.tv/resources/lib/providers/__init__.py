"""List all available providers and return the provider selected by the user."""

import xbmc
from tv_common.abstract_provider import AbstractProvider
from tv_common.exceptions import StreamRequestException
from tv_common.utils.kodi import get_addon_setting, log

from .fr import OrangeProvider
from .fr.orange_config import GROUPS

# Provider factory: territory key -> OrangeProvider instance factory.
# mco comes from the settings provider.country/name mapping to a territory code.
_PROVIDER_TERRITORIES = {
    "France.Orange": "OFR",
    "France.Orange Caraïbe": "OCA",
    "France.Orange Réunion": "ORE",
}

_PROVIDER_COUNTRY = get_addon_setting("provider.country")
_PROVIDER_NAME = get_addon_setting("provider.name")
_PROVIDER_KEY = f"{_PROVIDER_COUNTRY}.{_PROVIDER_NAME}"
_PROVIDER_MCO = _PROVIDER_TERRITORIES.get(_PROVIDER_KEY)

if _PROVIDER_MCO is None:
    log(f"Cannot instanciate provider: {_PROVIDER_KEY}", xbmc.LOGERROR)


def get_provider() -> AbstractProvider:
    """Return the selected provider."""
    if _PROVIDER_MCO is None:
        raise StreamRequestException(f"No provider selected (current: {_PROVIDER_KEY})")
    return OrangeProvider(_PROVIDER_MCO, GROUPS.get(_PROVIDER_MCO))
