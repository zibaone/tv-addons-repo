"""Orange provider, parameterized by territory (mco) and channel groups."""

from typing import Dict, List, Optional

from lib.providers.abstract_orange_provider import AbstractOrangeProvider


class OrangeProvider(AbstractOrangeProvider):
    """Orange provider for a given territory (mco) and channel groups."""

    def __init__(self, mco: str, groups: Optional[Dict[str, List[int]]] = None):
        """Initialize Orange provider.

        Args:
            mco: Orange market code, e.g. "OFR" (France), "OCA" (Caraïbe), "ORE" (Réunion).
            groups: channel groups (name -> list of channel EPG ids).

        """
        self.mco = mco
        self.name = f"orange_{mco.lower()}"
        self.groups = groups or {}
