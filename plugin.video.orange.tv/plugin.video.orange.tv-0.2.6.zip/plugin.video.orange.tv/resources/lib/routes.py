"""Addon routes."""

import xbmc
import xbmcplugin
from tv_common.managers import CatchupManager, IPTVManager, StreamManager
from tv_common.utils.kodi import build_addon_url, log
from tv_common.utils.library import export_catchup_items, notify_export

from lib.providers import get_provider
from lib.router import router


@router.route("/")
def index():
    """Display catchup service index."""
    log("Display catchup index", xbmc.LOGINFO)
    CatchupManager(get_provider(), router.handle).build_directory()


@router.route("/catchup/<path:levels>")
def catchup_directory(levels: str):
    """Display catchup service directory."""
    log(f"Display catchup directory {levels}", xbmc.LOGINFO)
    CatchupManager(get_provider(), router.handle).build_directory(levels)


@router.route("/search/<channel_id>")
@router.route("/search")
def search_channel(channel_id: str = ""):
    """Search catchup programs in a specific channel or selected channel."""
    import xbmcgui

    provider = get_provider()

    if not channel_id:
        channels = provider._get_catchup_channels()
        if not channels:
            xbmcplugin.endOfDirectory(router.handle)
            return
        labels = [c["label"] for c in channels]
        idx = xbmcgui.Dialog().select("Choisir la chaîne pour la recherche replay", labels)
        if idx < 0:
            xbmcplugin.endOfDirectory(router.handle)
            return
        chosen_path = channels[idx]["path"]
        channel_id = chosen_path.rstrip("/").split("/")[-1]

    dialog = xbmcgui.Dialog()
    query = dialog.input("Rechercher dans les replays")
    if not query:
        xbmcplugin.endOfDirectory(router.handle)
        return

    log(f"Searching catchup on channel {channel_id} for {query}", xbmc.LOGINFO)
    items = provider.search_channel_catchup(channel_id, query)
    CatchupManager(provider, router.handle).render_items(
        items, content_type="videos", category_name=f"Recherche: {query}"
    )


@router.route("/search/genre/<genre>")
def search_genre(genre: str):
    """Search items in a specific genre."""
    import xbmcgui

    dialog = xbmcgui.Dialog()
    query = dialog.input(f"Rechercher dans les {genre}")
    if not query:
        xbmcplugin.endOfDirectory(router.handle)
        return

    provider = get_provider()
    items = provider.search_genre(genre, query)
    type_map = {"films": "movies", "series": "tvshows", "documentaires": "videos"}
    content_type = type_map.get(genre, "videos")
    CatchupManager(provider, router.handle).render_items(
        items, content_type=content_type, category_name=f"Recherche: {query}"
    )


@router.route("/library/sources/sync")
@router.route("/library/sources/add/<source_type>")
@router.route("/library/sources/add")
def add_library_sources(source_type: str = "all"):
    """Add Orange TV replay sources to Kodi's sources.xml."""
    from tv_common.utils.sources import sync_sources_from_mode

    def _get_sources(mode_idx: int):
        sources = []
        include_movies = source_type in ("films", "movies", "all")
        include_series = source_type in ("series", "tvshows", "all")
        include_docs = source_type in ("documentaires", "docs", "all")
        include_channels = source_type in ("channels",)

        if mode_idx == 0:  # Navigation
            if include_movies:
                sources.append({
                    "name": "Orange TV - Films",
                    "path": build_addon_url("/catchup/genre/films/all"),
                })
            if include_series:
                sources.append({
                    "name": "Orange TV - Séries",
                    "path": build_addon_url("/catchup/genre/series/all"),
                })
            if include_docs:
                sources.append({
                    "name": "Orange TV - Documentaires",
                    "path": build_addon_url("/catchup/genre/documentaires/all"),
                })
            if include_channels:
                sources.append({
                    "name": "Orange TV - Replay (Par chaînes)",
                    "path": build_addon_url("/catchup/channels"),
                })
        elif mode_idx == 1:  # Médiathèque
            if include_movies:
                sources.append({
                    "name": "Orange TV - Médiathèque Films",
                    "path": build_addon_url("/library/movies"),
                })
            if include_series:
                sources.append({
                    "name": "Orange TV - Médiathèque Séries",
                    "path": build_addon_url("/library/tvshows"),
                })
        elif mode_idx == 2:  # Développeur (Les deux)
            if include_movies:
                sources.append({
                    "name": "Orange TV - Films (Navigation)",
                    "path": build_addon_url("/catchup/genre/films/all"),
                })
                sources.append({
                    "name": "Orange TV - Médiathèque Films",
                    "path": build_addon_url("/library/movies"),
                })
            if include_series:
                sources.append({
                    "name": "Orange TV - Séries (Navigation)",
                    "path": build_addon_url("/catchup/genre/series/all"),
                })
                sources.append({
                    "name": "Orange TV - Médiathèque Séries",
                    "path": build_addon_url("/library/tvshows"),
                })
            if include_docs:
                sources.append({
                    "name": "Orange TV - Documentaires",
                    "path": build_addon_url("/catchup/genre/documentaires/all"),
                })
            if include_channels:
                sources.append({
                    "name": "Orange TV - Replay (Par chaînes)",
                    "path": build_addon_url("/catchup/channels"),
                })
        return sources

    sync_sources_from_mode(
        addon_id="plugin.video.orange.tv",
        addon_name="Orange TV",
        get_sources_fn=_get_sources,
        is_disabled_fn=lambda mode: mode == 3,
        mode_names=["Navigation", "Médiathèque", "Développeur", "Désactivé"],
    )




@router.route("/stream/live/<stream_id>")
def stream_live(stream_id: str):
    """Load live stream for the required channel id."""
    log(f"Loading live stream {stream_id}", xbmc.LOGINFO)
    StreamManager(get_provider(), router.handle, router.args).load_live_stream(stream_id)


@router.route("/stream/catchup/<stream_id>")
def stream_catchup(stream_id: str):
    """Load catchup stream for the required video id."""
    log(f"Loading catchup stream {stream_id}", xbmc.LOGINFO)
    StreamManager(get_provider(), router.handle, router.args).load_catchup_stream(stream_id)


@router.route("/library/movies")
def library_movies():
    """Flat movie list for Kodi library scrapers."""
    log("Display library movies", xbmc.LOGINFO)
    CatchupManager(get_provider(), router.handle).build_directory("genre/films/all")


@router.route("/library/tvshows")
def library_tvshows():
    """Flat TV show list for Kodi library scrapers."""
    log("Display library tvshows", xbmc.LOGINFO)
    CatchupManager(get_provider(), router.handle).build_directory("genre/series/all")


@router.route("/library/export/<path:levels>")
def library_export(levels: str):
    """Export the given catchup level to the Kodi video library as .strm files."""
    log(f"Exporting catchup {levels} to library", xbmc.LOGINFO)
    level_list = levels.split("/") if levels else []
    directory = level_list[-1] if level_list else "library"
    count = export_catchup_items(get_provider(), level_list, directory)
    notify_export(count, directory)
    xbmcplugin.endOfDirectory(router.handle)


@router.route("/iptv/channels")
def iptv_channels():
    """Return JSON-STREAMS formatted data for all live channels."""
    log("Loading channels for IPTV Manager", xbmc.LOGINFO)
    port = int(router.args.get("port")[0])
    IPTVManager(port, get_provider()).send_channels()


@router.route("/iptv/epg")
def iptv_epg():
    """Return JSON-EPG formatted data for all live channel EPG data."""
    log("Loading EPG for IPTV Manager", xbmc.LOGINFO)
    port = int(router.args.get("port")[0])
    IPTVManager(port, get_provider()).send_epg()