"""Rakuten lib package."""
