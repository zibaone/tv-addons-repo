"""Rakuten provider selection."""

from tv_common.abstract_provider import AbstractProvider

from .rakuten_provider import RakutenProvider

_PROVIDER = RakutenProvider()


def get_provider() -> AbstractProvider:
    """Return the Rakuten provider."""
    return _PROVIDER
