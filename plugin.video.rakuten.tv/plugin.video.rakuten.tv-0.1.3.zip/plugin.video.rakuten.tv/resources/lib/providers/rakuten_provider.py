"""Rakuten TV Free Provider."""

import time
import urllib.parse
from typing import Dict, List, Optional, Union

import requests
import xbmc
from tv_common.abstract_provider import AbstractProvider
from tv_common.utils.cache import use_router_cache
from tv_common.utils.kodi import build_addon_url, get_addon_setting, log
from tv_common.utils.routing import dispatch_by_depth, to_json_streams

GIZMO_BASE = "https://gizmo.rakuten.tv/v3"
# FR classification — discovered via rakuten-m3u-generator (es=5, fr=23, it=36)
CLASSIFICATION_ID = 23
LOCALE = "fr"
MARKET_CODE = "fr"
DEVICE_IDENTIFIER = "web"
CHROME_USER_AGENT = (
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/125.0.0.0 Safari/537.36"
)


class RakutenProvider(AbstractProvider):
    """Provider for Rakuten TV Free FAST channels (FR)."""

    name = "rakuten"

    def __init__(self):
        """Initialize provider with a requests session."""
        self.session = requests.Session()
        self.session.headers.update(
            {
                "Origin": "https://rakuten.tv",
                "Referer": "https://rakuten.tv/",
                "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36",
                "Accept": "application/json",
            }
        )
        self.args: Dict[str, list] = {}

    def set_args(self, args: Dict[str, list]) -> None:
        """Store router query args for catchup stream resolution."""
        self.args = args or {}

    # -- AbstractProvider -------------------------------------------------

    def get_live_stream_info(self, stream_id: str) -> dict:
        """Return HLS clear stream info for a FAST channel."""
        url = self._resolve_hls(stream_id, content_type="live_channels", language="FRA")
        if not url:
            # fallback without language assumption
            url = self._resolve_hls(stream_id, content_type="live_channels", language="ENG")
        title = self.args.get("title", [None])[0] if self.args else None
        return {
            "path": url or "",
            "protocol": "hls",
            "mime_type": "application/vnd.apple.mpegurl",
            "title": title,
            "info": {"title": title} if title else {},
        }

    def get_catchup_stream_info(self, stream_id: str) -> dict:
        """Return DASH Widevine or HLS stream for AVOD / catchup content."""
        title = self.args.get("title", [None])[0] if self.args else None
        # Try Widevine DASH first for AVOD movies
        drm_stream = self._resolve_dash_widevine(stream_id)
        if drm_stream:
            if title:
                drm_stream["title"] = title
                drm_stream.setdefault("info", {})["title"] = title
            return drm_stream

        # Fallback to clear HLS (for live channels or clear streams)
        for ct in ("movies", "live_channels"):
            lang = self.args.get("audio_language", [None])[0] if self.args else None
            lang = lang or "FRA"
            url = self._resolve_hls(stream_id, content_type=ct, language=lang)
            if url:
                return {
                    "path": url,
                    "protocol": "hls",
                    "mime_type": "application/vnd.apple.mpegurl",
                    "title": title,
                    "info": {"title": title} if title else {},
                }
        return {
            "path": "",
            "protocol": "hls",
            "mime_type": "application/vnd.apple.mpegurl",
        }

    def _resolve_dash_widevine(self, content_id: str) -> Union[dict, None]:
        """Resolve Widevine DASH stream and license server for Rakuten AVOD movie."""
        m_data = self._api_get(f"/movies/{content_id}", {}) or {}
        streams = (
            m_data.get("data", {})
            .get("view_options", {})
            .get("private", {})
            .get("streams", [])
        )
        if not streams:
            return None

        available_pairs = []
        for s in streams:
            audios = [a["id"] for a in s.get("audio_languages", []) if isinstance(a, dict) and "id" in a]
            subs = [sub["id"] for sub in s.get("subtitle_languages", []) if isinstance(sub, dict) and "id" in sub]
            for a in audios:
                for sub in subs:
                    available_pairs.append((a, sub))

        requested_lang = self.args.get("audio_language", [None])[0] if self.args else None
        pair = None
        targets = []
        if requested_lang:
            targets.extend([(requested_lang, "MIS"), (requested_lang, "FRA")])
        targets.extend([("FRA", "MIS"), ("FRA", "FRA"), ("ENG", "FRA"), ("ENG", "MIS")])

        for target_a, target_s in targets:
            if (target_a, target_s) in available_pairs:
                pair = (target_a, target_s)
                break
        if not pair and available_pairs:
            pair = available_pairs[0]

        if not pair:
            return None

        audio_lang, sub_lang = pair
        # Determine device profile: 0 = Auto, 1 = Android, 2 = Web
        profile_setting = 0
        try:
            profile_setting = get_addon_setting("playback.device_profile", int)
        except Exception:
            profile_setting = 0

        if profile_setting == 1:
            is_android = True
        elif profile_setting == 2:
            is_android = False
        else:
            is_android = False
            if hasattr(xbmc, "getCondVisibility"):
                try:
                    is_android = bool(xbmc.getCondVisibility("System.Platform.Android"))
                except Exception:
                    is_android = False

        device_id = "android" if is_android else "web"
        player_name = "android:DASH-CENC" if is_android else "web:DASH-CENC:WIDEVINE"
        video_quality = "HD" if is_android else "FHD"

        headers = {
            "Origin": "https://rakuten.tv",
            "Referer": "https://rakuten.tv/",
            "User-Agent": CHROME_USER_AGENT,
        }
        params = {
            "classification_id": CLASSIFICATION_ID,
            "device_identifier": device_id,
            "device_stream_audio_quality": "2.0",
            "device_stream_hdr_type": "NONE",
            "device_stream_video_quality": video_quality,
            "disable_dash_legacy_packages": False,
            "locale": LOCALE,
            "market_code": MARKET_CODE,
        }
        payload = {
            "audio_language": audio_lang,
            "audio_quality": "2.0",
            "classification_id": CLASSIFICATION_ID,
            "content_id": content_id,
            "content_type": "movies",
            "device_serial": "not implemented",
            "player": player_name,
            "strict_video_quality": False,
            "subtitle_language": sub_lang,
            "video_type": "stream",
        }
        url = f"{GIZMO_BASE}/avod/streamings"
        try:
            resp = self.session.post(url, headers=headers, params=params, json=payload, timeout=15)
            if resp.status_code == 200:
                data = resp.json()
                infos = data.get("data", {}).get("stream_infos", [])
                if infos:
                    mpd_url = infos[0].get("url", "")
                    license_url = infos[0].get("license_url", "")
                    import urllib.parse

                    lic_headers = {
                        "User-Agent": CHROME_USER_AGENT,
                        "Origin": "https://rakuten.tv",
                        "Referer": "https://rakuten.tv/",
                        "Content-Type": "application/octet-stream",
                    }
                    encoded_lic_headers = urllib.parse.urlencode(lic_headers)
                    license_key = f"{license_url}|{encoded_lic_headers}|R{{SSM}}|"
                    return {
                        "path": mpd_url,
                        "protocol": "mpd",
                        "mime_type": "application/dash+xml",
                        "headers": {
                            "Origin": "https://rakuten.tv",
                            "Referer": "https://rakuten.tv/",
                            "User-Agent": CHROME_USER_AGENT,
                        },
                        "drm_config": {
                            "license_type": "com.widevine.alpha",
                            "license_key": license_key,
                        },
                    }
        except Exception as e:
            log(f"rakuten Widevine resolve failed for {content_id}: {e}", xbmc.LOGWARNING)
        return None

    def get_streams(self) -> list:
        """Return JSON-STREAMS for all FAST channels grouped by category."""
        categories, channels = self._load_channels_and_categories()
        cat_map = self._category_map(categories)
        # Build group per channel; channels not in any category -> Autres
        return to_json_streams(
            channels,
            {
                "id": lambda c: c.get("id"),
                "name": lambda c: c.get("title", ""),
                "preset": lambda c: str(c.get("channel_number", "")),
                "logo": lambda c: c.get("images", {}).get("artwork", "")
                or c.get("images", {}).get("artwork_negative", ""),
                "stream": lambda c: build_addon_url(f"/stream/live/{c.get('id')}"),
                "group": lambda c: [cat_map.get(c.get("id"), "Autres")],
            },
        )

    def get_epg(self) -> Union[str, dict]:
        """Return JSON-EPG (channel_id -> programmes). Best-effort per-channel fetch."""
        # Rakuten does not expose a bulk EPG; we try per-channel short EPG with bounded time.
        epg: Dict[str, list] = {}
        try:
            _, channels = self._load_channels_and_categories()
        except Exception as e:
            log(f"rakuten get_epg: cannot load channels: {e}", xbmc.LOGWARNING)
            return epg

        # Limit to avoid Kodi timeout (IPTV Manager calls this via socket, 6h cache).
        max_fetch_sec = 8.0
        start = time.monotonic()
        for ch in channels:
            if time.monotonic() - start >= max_fetch_sec:
                break
            cid = ch.get("id")
            if not cid:
                continue
            programs = self._fetch_channel_epg(cid)
            if programs:
                epg[cid] = programs
        return epg

    def get_catchup_items(self, levels: List[str]) -> list:
        """Dispatch VOD navigation by URL depth."""
        getters = [
            self._get_catchup_0,
            self._get_catchup_1,
            self._get_catchup_2,
            self._get_catchup_3,
        ]
        return dispatch_by_depth(getters, levels)

    def get_category_name(self, levels: List[str]) -> Optional[str]:
        """Return breadcrumb category name for given navigation levels."""
        if not levels:
            return "Accueil"
        type_map = {"movies": "Films", "live": "Direct", "genres": "Genres"}
        base = type_map.get(levels[0], levels[0].title())
        if len(levels) == 1:
            return base
        return f"{base} > {levels[1].replace('_', ' ').title()}"

    # -- Catchup levels ---------------------------------------------------

    def _get_catchup_0(self) -> list:
        """Root: FAST channels + Films gratuits (AVOD) (always hierarchical)."""
        return [
            {
                "is_folder": True,
                "label": "Chaînes FAST",
                "path": build_addon_url("/catchup/fast"),
                "content_type": "videos",
            },
            {
                "is_folder": True,
                "label": "Films gratuits (AVOD)",
                "path": build_addon_url("/catchup/avod"),
                "content_type": "movies",
                "context_menu": [
                    ("🔍 Rechercher un film gratuit...", f"Container.Update({build_addon_url('/search')})"),
                    ("🎬 Tous les films (à plat)", f"Container.Update({build_addon_url('/library/movies')})"),
                    ("📁 Ajouter aux sources Kodi", f"RunPlugin({build_addon_url('/library/sources/add')})"),
                ],
            },
        ]

    @use_router_cache("catchup_1", expire_sec=6 * 60 * 60)
    def _get_catchup_1(self, kind: str) -> list:
        """Categories for FAST or AVOD."""
        if kind == "fast":
            categories, channels = self._load_channels_and_categories()
            ch_ids = {ch.get("id") for ch in channels}
            items = []
            for cat in categories:
                if ch_ids:
                    cat_channels = [cid for cid in cat.get("live_channels", []) if cid in ch_ids]
                    if not cat_channels:
                        continue
                    label = f"{cat.get('name', 'Sans nom')} ({len(cat_channels)})"
                else:
                    label = cat.get("name", "Sans nom")
                items.append(
                    {
                        "is_folder": True,
                        "label": label,
                        "path": build_addon_url(f"/catchup/fast/{cat.get('id')}"),
                        "content_type": "videos",
                    }
                )
            return items
        if kind == "avod":
            lists = self._load_avod_lists()
            items = []
            for avod_list in lists:
                lid = avod_list.get("id")
                if not lid:
                    continue
                raw_name = str(avod_list.get("name") or "Sans titre")
                label = raw_name.replace("GRATUIT | ", "").replace("GRATUIT", "").strip()
                items.append(
                    {
                        "is_folder": True,
                        "label": label,
                        "path": build_addon_url(f"/catchup/avod/{lid}"),
                        "content_type": "movies",
                        "context_menu": [
                            (
                                "🔍 Rechercher un film gratuit...",
                                f"Container.Update({build_addon_url('/search')})",
                            ),
                        ],
                    }
                )
            if not items:
                items.append(
                    {
                        "is_folder": True,
                        "label": "Tous les films gratuits",
                        "path": build_addon_url("/catchup/avod/free-all-movies"),
                        "content_type": "movies",
                    }
                )
            return items
        return []

    @use_router_cache("catchup_2", expire_sec=6 * 60 * 60)
    def _get_catchup_2(self, kind: str, group_id: str) -> list:
        """Items inside a category (or page 1 of AVOD)."""
        if kind == "fast":
            categories, channels = self._load_channels_and_categories()
            # Resolve category id -> channel ids
            cat = next((c for c in categories if str(c.get("id")) == str(group_id)), None)
            allowed = set(cat.get("live_channels", [])) if cat else set()
            filtered = [ch for ch in channels if ch.get("id") in allowed] if allowed else []
            items = []
            for ch in filtered:
                cid = ch.get("id")
                images = ch.get("images") if isinstance(ch.get("images"), dict) else {}
                thumb = images.get("artwork", "") or images.get("snapshot", "")
                items.append(
                    {
                        "is_folder": False,
                        "label": ch.get("title", cid),
                        "path": build_addon_url(f"/stream/live/{cid}"),
                        "art": {"thumb": thumb, "poster": thumb},
                        "info": {
                            "title": ch.get("title", ""),
                            "mediatype": "video",
                            "plot": "",
                        },
                    }
                )
            return items
        if kind == "avod":
            return self._get_catchup_avod_movies(group_id, page=1)
        return []

    @use_router_cache("catchup_3", expire_sec=6 * 60 * 60)
    def _get_catchup_3(self, kind: str, group_id: str, page_str: str) -> list:
        """Page N of an AVOD category."""
        if kind == "avod":
            try:
                page = int(page_str)
            except (ValueError, TypeError):
                page = 1
            return self._get_catchup_avod_movies(group_id, page=page)
        return []

    def _get_catchup_avod_movies(self, list_id: str, page: int = 1) -> list:
        """Return movie list items for a specific AVOD list with pagination."""
        if list_id == "all":
            list_id = "free-all-movies"
        res = self._load_avod_list_contents(list_id, page)
        movies = res.get("data", []) if isinstance(res.get("data"), list) else []
        meta = res.get("meta", {}).get("pagination", {})
        total_pages = meta.get("total_pages", 1)

        items = []
        for m in movies:
            mid = m.get("id")
            if not mid:
                continue
            title = str(m.get("title") or mid)
            images = m.get("images") if isinstance(m.get("images"), dict) else {}
            thumb = images.get("artwork") or images.get("snapshot") or ""
            plot = m.get("short_plot") or m.get("plot") or ""
            year = m.get("year")
            duration = m.get("duration")
            genres = [g.get("name") for g in m.get("genres", []) if isinstance(g, dict) and "name" in g]

            items.append(
                {
                    "is_folder": False,
                    "label": title,
                    "path": build_addon_url(f"/stream/catchup/{mid}?{urllib.parse.urlencode({'title': title})}"),
                    "content_type": "movies",
                    "art": {"thumb": thumb, "poster": thumb},
                    "info": {
                        "title": title,
                        "mediatype": "movie",
                        "plot": plot,
                        "year": int(year) if year and str(year).isdigit() else None,
                        "duration": int(duration) * 60 if duration else None,
                        "genres": genres,
                    },
                }
            )

        if page < total_pages:
            items.append(
                {
                    "is_folder": True,
                    "label": f"Page suivante ({page + 1}/{total_pages}) »",
                    "path": build_addon_url(f"/catchup/avod/{list_id}/{page + 1}"),
                    "content_type": "movies",
                    "art": {},
                    "info": {"title": f"Page {page + 1}"},
                }
            )

        return items

    def get_library_movies(self) -> list:
        """Return all free AVOD movies formatted for the Kodi video library scanner."""
        res = self._load_avod_list_contents("free-all-movies", 1)
        total_pages = res.get("meta", {}).get("pagination", {}).get("total_pages", 1)
        all_movies = list(res.get("data", [])) if isinstance(res.get("data"), list) else []

        for p in range(2, min(total_pages + 1, 10)):
            p_res = self._load_avod_list_contents("free-all-movies", p)
            if isinstance(p_res.get("data"), list):
                all_movies.extend(p_res["data"])

        items = []
        seen_ids = set()
        for m in all_movies:
            mid = m.get("id")
            if not mid or mid in seen_ids:
                continue
            seen_ids.add(mid)
            title = str(m.get("title") or mid)
            images = m.get("images") if isinstance(m.get("images"), dict) else {}
            thumb = images.get("artwork") or images.get("snapshot") or ""
            plot = m.get("short_plot") or m.get("plot") or ""
            year = m.get("year")
            duration = m.get("duration")
            genres = [g.get("name") for g in m.get("genres", []) if isinstance(g, dict) and "name" in g]

            items.append(
                {
                    "is_folder": False,
                    "label": title,
                    "path": build_addon_url(f"/stream/catchup/{mid}?{urllib.parse.urlencode({'title': title})}"),
                    "content_type": "movies",
                    "art": {"thumb": thumb, "poster": thumb},
                    "info": {
                        "title": title,
                        "mediatype": "movie",
                        "plot": plot,
                        "year": int(year) if year and str(year).isdigit() else None,
                        "duration": int(duration) * 60 if duration else None,
                        "genres": genres,
                    },
                }
            )
        return items

    def search_movies(self, query: str) -> list:
        """Search free AVOD movies by keyword."""
        all_movies = self.get_library_movies()
        q = query.lower().strip()
        return [
            m
            for m in all_movies
            if q in m.get("label", "").lower() or q in m.get("info", {}).get("plot", "").lower()
        ]

    # -- Internal helpers -------------------------------------------------

    @use_router_cache("channels", expire_sec=6 * 60 * 60)
    def _load_channels_and_categories(self):
        """Fetch and return (categories, channels). Cached 6h."""
        categories = self._api_get("/live_channel_categories", {}) or {}
        cat_data = categories.get("data", []) if isinstance(categories, dict) else []
        channels_raw = self._api_get("/live_channels", {}) or {}
        ch_data = channels_raw.get("data", []) if isinstance(channels_raw, dict) else []
        return cat_data, ch_data

    @use_router_cache("avod_lists", expire_sec=6 * 60 * 60)
    def _load_avod_lists(self) -> list:
        """Fetch AVOD lists from /gardens/avod-fast."""
        data = self._api_get("/gardens/avod-fast", {"user_status": "visitor"}) or {}
        if isinstance(data, dict) and "data" in data:
            return data["data"].get("lists", [])
        return []

    @use_router_cache("avod_list_contents", expire_sec=6 * 60 * 60)
    def _load_avod_list_contents(self, list_id: str, page: int = 1) -> dict:
        """Fetch contents of an AVOD list with pagination."""
        params = {
            "user_status": "visitor",
            "page": page,
            "per_page": 50,
        }
        data = self._api_get(f"/lists/{list_id}/contents", params) or {}
        return data if isinstance(data, dict) else {}

    def _load_avod_movies(self) -> list:
        """Legacy helper returning sample movies from free-all-movies."""
        res = self._load_avod_list_contents("free-all-movies", 1)
        return res.get("data", []) if isinstance(res.get("data"), list) else []

    def _category_map(self, categories: list) -> Dict[str, str]:
        """Map channel id -> category name."""
        mapping: Dict[str, str] = {}
        for cat in categories:
            name = cat.get("name", "Autres")
            for cid in cat.get("live_channels", []) or []:
                mapping[cid] = name
        return mapping

    def _api_get(self, path: str, extra_params: dict) -> Union[dict, None]:
        """GET gizmo endpoint with base query params."""
        params = {
            "classification_id": CLASSIFICATION_ID,
            "device_identifier": DEVICE_IDENTIFIER,
            "locale": LOCALE,
            "market_code": MARKET_CODE,
        }
        params.update(extra_params)
        url = f"{GIZMO_BASE}{path}"
        try:
            resp = self.session.get(url, params=params, timeout=15)
            resp.raise_for_status()
            return resp.json()
        except Exception as e:
            log(f"rakuten GET {path} failed: {e}", xbmc.LOGWARNING)
            return None

    def _resolve_hls(self, content_id: str, content_type: str, language: str) -> str:
        """POST /avod/streamings and return HLS url."""
        headers = {
            "Origin": "https://rakuten.tv",
            "Referer": "https://rakuten.tv/",
            "User-Agent": "Mozilla/5.0 (X11; Linux x86_64; rv:98.0) Gecko/20100101 Firefox/98.0",
        }
        params = {
            "classification_id": CLASSIFICATION_ID,
            "device_identifier": DEVICE_IDENTIFIER,
            "device_stream_audio_quality": "2.0",
            "device_stream_hdr_type": "NONE",
            "device_stream_video_quality": "FHD",
            "disable_dash_legacy_packages": False,
            "locale": LOCALE,
            "market_code": MARKET_CODE,
        }
        payload = {
            "audio_language": language,
            "audio_quality": "2.0",
            "classification_id": CLASSIFICATION_ID,
            "content_id": content_id,
            "content_type": content_type,
            "device_serial": "not implemented",
            "player": "web:HLS-NONE:NONE",
            "strict_video_quality": False,
            "subtitle_language": "MIS",
            "video_type": "stream",
        }
        url = f"{GIZMO_BASE}/avod/streamings"
        langs_to_try = [language] if language else []
        for fallback in ("ENG", "FRA"):
            if fallback not in langs_to_try:
                langs_to_try.append(fallback)

        for lang in langs_to_try:
            payload["audio_language"] = lang
            try:
                resp = self.session.post(url, headers=headers, params=params, json=payload, timeout=15)
                if resp.status_code == 200:
                    data = resp.json()
                    infos = data.get("data", {}).get("stream_infos", [])
                    if infos:
                        return infos[0].get("url", "")
                elif resp.status_code == 400 and "subtitle_language" in resp.text:
                    continue
                else:
                    resp.raise_for_status()
            except Exception as e:
                log(f"rakuten HLS resolve {content_id} ({content_type}, {lang}) failed: {e}", xbmc.LOGWARNING)
        return ""

    def _fetch_channel_epg(self, channel_id: str) -> list:
        """Fetch per-channel EPG if available. Returns JSON-EPG programmes."""
        # Try undocumented endpoint variations; fall back to empty.
        for path in [f"/live_channels/{channel_id}/epg", f"/live_channels/{channel_id}"]:
            data = self._api_get(path, {})
            if not data or "data" not in data:
                continue
            # If the endpoint returns schedules
            payload = data.get("data", {})
            # Look for programmes nested
            if isinstance(payload, dict) and "epg" in payload:
                return self._normalize_epg(payload["epg"], channel_id)
            if isinstance(payload, dict) and "schedules" in payload:
                return self._normalize_epg(payload["schedules"], channel_id)
        return []

    def _normalize_epg(self, raw_programs: list, channel_id: str) -> list:
        """Normalize raw programmes to JSON-EPG format."""
        out = []
        for p in raw_programs or []:
            start = p.get("start_at") or p.get("start") or p.get("start_time") or ""
            stop = p.get("end_at") or p.get("stop") or p.get("end_time") or ""
            title = p.get("title") or p.get("name") or ""
            desc = p.get("description") or p.get("plot") or p.get("short_plot") or ""
            # Ensure ISO format if timestamps
            out.append({"start": str(start), "stop": str(stop), "title": title, "description": desc})
        return out
