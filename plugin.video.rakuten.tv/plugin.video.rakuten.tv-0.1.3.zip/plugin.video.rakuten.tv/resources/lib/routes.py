"""Addon routes."""

import xbmc
from tv_common.managers import CatchupManager, IPTVManager, StreamManager
from tv_common.utils.kodi import log

from lib.providers import get_provider
from lib.router import router


@router.route("/")
def index():
    """Display catchup service index."""
    log("Display catchup index", xbmc.LOGINFO)
    CatchupManager(get_provider(), router.handle).build_directory()


@router.route("/library/sources/sync")
@router.route("/library/sources/add")
def add_library_sources():
    """Add or synchronize Rakuten TV sources in Kodi's sources.xml."""
    from tv_common.utils.kodi import build_addon_url
    from tv_common.utils.sources import sync_sources_from_mode

    def _get_sources(mode_idx: int):
        sources = []
        if mode_idx == 0:  # Navigation
            sources.append({
                "name": "Rakuten TV - Films Gratuits",
                "path": build_addon_url("/catchup/avod"),
            })
        elif mode_idx == 1:  # Médiathèque
            sources.append({
                "name": "Rakuten TV - Médiathèque Films",
                "path": build_addon_url("/library/movies"),
            })
        elif mode_idx == 2:  # Développeur (Les deux)
            sources.append({
                "name": "Rakuten TV - Films Gratuits (Navigation)",
                "path": build_addon_url("/catchup/avod"),
            })
            sources.append({
                "name": "Rakuten TV - Médiathèque Films",
                "path": build_addon_url("/library/movies"),
            })
        return sources

    sync_sources_from_mode(
        addon_id="plugin.video.rakuten.tv",
        addon_name="Rakuten TV",
        get_sources_fn=_get_sources,
        is_disabled_fn=lambda mode: mode == 3,
        mode_names=["Navigation", "Médiathèque", "Développeur", "Désactivé"],
    )



@router.route("/library/sources")
def library_sources():
    """Display dedicated source folders for Kodi video library scanning."""
    from tv_common.utils.kodi import build_addon_url

    items = [
        {
            "is_folder": False,
            "label": "➕ Ajouter automatiquement la source à Kodi",
            "path": build_addon_url("/library/sources/add"),
        },
        {
            "is_folder": True,
            "label": "🎬 Films gratuits (pour Médiathèque Kodi)",
            "path": build_addon_url("/library/movies"),
            "content_type": "movies",
        },
    ]
    CatchupManager(get_provider(), router.handle).render_items(
        items, content_type="videos", category_name="Sources Médiathèque Kodi"
    )


@router.route("/library/movies")
def library_movies():
    """Return all free AVOD movies in a single batch formatted for Kodi library scraping."""
    log("Building library movies directory for Kodi scraper", xbmc.LOGINFO)
    provider = get_provider()
    items = provider.get_library_movies()
    CatchupManager(provider, router.handle).render_items(
        items, content_type="movies", category_name="Films gratuits Rakuten"
    )


@router.route("/search")
def search_movies():
    """Search free AVOD movies by keyword."""
    import xbmcgui
    import xbmcplugin

    query_args = router.args.get("query", [])
    query = query_args[0] if query_args else ""

    if not query:
        dialog = xbmcgui.Dialog()
        query = dialog.input("Rechercher un film gratuit")
        if not query:
            xbmcplugin.endOfDirectory(router.handle)
            return

    log(f"Searching Rakuten movies for: {query}", xbmc.LOGINFO)
    provider = get_provider()
    items = provider.search_movies(query)
    CatchupManager(provider, router.handle).render_items(
        items, content_type="movies", category_name=f"Recherche: {query}"
    )


@router.route("/catchup/<path:levels>")
def catchup_directory(levels: str):
    """Display catchup service directory."""
    log(f"Display catchup directory {levels}", xbmc.LOGINFO)
    CatchupManager(get_provider(), router.handle).build_directory(levels)


@router.route("/stream/live/<stream_id>")
def stream_live(stream_id: str):
    """Load live stream for the required channel id."""
    log(f"Loading live stream {stream_id}", xbmc.LOGINFO)
    provider = get_provider()
    provider.set_args(router.args)
    StreamManager(provider, router.handle, router.args).load_live_stream(stream_id)


@router.route("/stream/catchup/<stream_id>")
def stream_catchup(stream_id: str):
    """Load catchup stream for the required video id."""
    log(f"Loading catchup stream {stream_id}", xbmc.LOGINFO)
    provider = get_provider()
    provider.set_args(router.args)
    StreamManager(provider, router.handle, router.args).load_catchup_stream(stream_id)


@router.route("/iptv/channels")
def iptv_channels():
    """Return JSON-STREAMS formatted data for all live channels."""
    log("Loading channels for IPTV Manager", xbmc.LOGINFO)
    port = int(router.args.get("port")[0])
    IPTVManager(port, get_provider()).send_channels()


@router.route("/iptv/epg")
def iptv_epg():
    """Return JSON-EPG formatted data for all live channel EPG data."""
    log("Loading EPG for IPTV Manager", xbmc.LOGINFO)
    port = int(router.args.get("port")[0])
    IPTVManager(port, get_provider()).send_epg()
